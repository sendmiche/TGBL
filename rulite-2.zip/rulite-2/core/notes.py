"""Текст, который публикуется вместе с релизом.

Пользователь может держать несколько вариантов текста и отмечать, какие из них
участвуют в ротации: при каждом релизе берётся случайный из отмеченных. Внутри
текста работают подстановки {{имя}} и условные блоки {{#имя}}…{{/имя}}.
"""

from __future__ import annotations

import random
import re
import uuid
from datetime import datetime
from typing import Any

SECTION = re.compile(r"\{\{([#^])([a-z0-9_]+)\}\}\s*(.*?)\s*\{\{/\2\}\}\n?", re.S)
VARIABLE = re.compile(r"\{\{([a-z0-9_]+)\}\}")

MAX_TABLE_ROWS = 250

# Описание переменных для подсказки в интерфейсе.
VARIABLES: dict[str, str] = {
    "tag": "тег релиза, например 201020250951",
    "date": "дата и время выпуска",
    "geosite_size": "размер geosite.dat, например 3.5 МБ",
    "geoip_size": "размер geoip.dat",
    "total_size": "суммарный размер обоих файлов",
    "geosite_entries": "сколько записей осталось в geosite.dat",
    "geoip_entries": "сколько записей осталось в geoip.dat",
    "geosite_count": "сколько категорий в geosite.dat",
    "geoip_count": "сколько категорий в geoip.dat",
    "geosite_url": "прямая ссылка на geosite.dat",
    "geoip_url": "прямая ссылка на geoip.dat",
    "release_url": "ссылка на страницу релиза",
    "geosite_sha256": "контрольная сумма geosite.dat",
    "geoip_sha256": "контрольная сумма geoip.dat",
    "repo": "репозиторий в виде user/repo",
    "service": "название сервиса: GitHub или GitVerse",
    "categories_table": "таблица категорий в две колонки",
    "geosite_categories": "список категорий geosite через запятую",
    "geoip_categories": "список категорий geoip через запятую",
    "source_url": "адрес исходного репозитория с правилами",
}

CONDITIONS: dict[str, str] = {
    "latest_links": "ссылки «всегда последний релиз» доступны (GitHub)",
    "has_geosite": "в релизе есть geosite.dat",
    "has_geoip": "в релизе есть geoip.dat",
}

DEFAULT_TEXT = """## ❤️ RULITE — geosite.dat и geoip.dat для России

⚡ Автоматическая сборка облегчённых файлов `geosite.dat` и `geoip.dat` в течение \
часа после выхода релиза [runetfreedom/russia-v2ray-rules-dat]({{source_url}}) — \
только если файлы действительно изменились.

🧠 Основано на:

* [@v2fly/domain-list-community](https://github.com/v2fly/domain-list-community)
* [Antifilter](https://antifilter.network/)
* [re:filter](https://github.com/1andrevich/Re-filter-lists)

🧪 В файлах оставлены только актуальные категории:

* `geosite.dat` — {{geosite_size}}
* `geoip.dat` — {{geoip_size}}

✅ Отлично подходит для пользователей Happ на iOS

### 📄 Ссылки

{{#latest_links}}
Всегда последняя версия:

* [`geoip.dat`]({{geoip_url}})
* [`geosite.dat`]({{geosite_url}})
{{/latest_links}}
{{^latest_links}}
* [`geoip.dat`]({{geoip_url}})
* [`geosite.dat`]({{geosite_url}})
{{/latest_links}}

### 📋 Категории

{{categories_table}}

---

✍️ Сделано с ❤️
"""


def source_page(url: str) -> str:
    """Из ссылки на сырой файл делает ссылку на сам репозиторий."""
    text = (url or "").strip()
    if "raw.githubusercontent.com/" in text:
        parts = text.split("raw.githubusercontent.com/", 1)[1].split("/")
        if len(parts) >= 2:
            return f"https://github.com/{parts[0]}/{parts[1]}"
    if "/raw/" in text:
        return text.split("/raw/", 1)[0]
    return text


def new_note(title: str = "Текст релиза", text: str = "") -> dict[str, Any]:
    return {
        "id": uuid.uuid4().hex[:8],
        "title": title,
        "text": text or DEFAULT_TEXT,
        "enabled": True,
    }


def default_notes() -> list[dict[str, Any]]:
    return [new_note("Основной текст", DEFAULT_TEXT)]


def pick(notes: list[dict[str, Any]]) -> str:
    """Случайный текст из отмеченных. Если ни одного — встроенный по умолчанию."""
    enabled = [n["text"] for n in notes if n.get("enabled") and (n.get("text") or "").strip()]
    if not enabled:
        return DEFAULT_TEXT
    return random.choice(enabled)


# --------------------------------------------------------------------------
# Подстановка
# --------------------------------------------------------------------------

def render(template: str, context: dict[str, Any]) -> tuple[str, list[str]]:
    """Возвращает готовый текст и список неизвестных переменных."""
    text = template or ""

    # Условные блоки, с поддержкой вложенности.
    for _ in range(10):
        replaced = SECTION.sub(lambda m: _section(m, context), text)
        if replaced == text:
            break
        text = replaced

    unknown: list[str] = []

    def substitute(match: re.Match) -> str:
        name = match.group(1)
        if name in context:
            return str(context[name])
        if name not in unknown:
            unknown.append(name)
        return ""

    text = VARIABLE.sub(substitute, text)
    # Убираем пустые строки, оставшиеся от вырезанных блоков.
    text = re.sub(r"\n{3,}", "\n\n", text).strip()
    return text, unknown


def _section(match: re.Match, context: dict[str, Any]) -> str:
    kind, name, body = match.group(1), match.group(2), match.group(3)
    truthy = bool(context.get(name))
    show = truthy if kind == "#" else not truthy
    return f"{body}\n" if show else ""


def human_size(size: int) -> str:
    if size >= 1048576:
        return f"{size / 1048576:.2f} МБ"
    if size >= 1024:
        return f"{size / 1024:.1f} КБ"
    return f"{size} Б"


def categories_table(geosite: list[str], geoip: list[str]) -> str:
    """Таблица категорий в две колонки — как в разметке GitHub и GitVerse."""
    if not geosite and not geoip:
        return "_Категории не выбраны._"

    left = [f"`geosite:{code}`" for code in geosite]
    right = [f"`geoip:{code}`" for code in geoip]
    rows = max(len(left), len(right))
    note = ""

    if rows > MAX_TABLE_ROWS:
        note = (
            f"\n\n_Показаны первые {MAX_TABLE_ROWS} строк из {rows}._"
        )
        rows = MAX_TABLE_ROWS

    lines = ["| 🌍 geosite.dat | 🌐 geoip.dat |", "|---|---|"]
    for index in range(rows):
        cell_left = left[index] if index < len(left) else ""
        cell_right = right[index] if index < len(right) else ""
        lines.append(f"| {cell_left} | {cell_right} |")
    return "\n".join(lines) + note


def build_context(
    tag: str,
    files: list[dict[str, Any]],
    urls: dict[str, str],
    *,
    repo: str = "",
    service: str = "",
    release_url: str = "",
    latest_links: bool = False,
    source_url: str = "",
) -> dict[str, Any]:
    by_kind = {item["kind"]: item for item in files}
    geosite = by_kind.get("geosite") or {}
    geoip = by_kind.get("geoip") or {}

    context: dict[str, Any] = {
        "tag": tag,
        "date": datetime.now().strftime("%d.%m.%Y %H:%M"),
        "repo": repo,
        "service": service,
        "release_url": release_url,
        "source_url": source_url,
        "latest_links": latest_links,
        "has_geosite": bool(geosite),
        "has_geoip": bool(geoip),
        "geosite_size": human_size(geosite.get("size", 0)),
        "geoip_size": human_size(geoip.get("size", 0)),
        "total_size": human_size(geosite.get("size", 0) + geoip.get("size", 0)),
        "geosite_entries": f"{geosite.get('entries', 0):,}".replace(",", " "),
        "geoip_entries": f"{geoip.get('entries', 0):,}".replace(",", " "),
        "geosite_count": geosite.get("categories", 0),
        "geoip_count": geoip.get("categories", 0),
        "geosite_sha256": geosite.get("sha256", ""),
        "geoip_sha256": geoip.get("sha256", ""),
        "geosite_url": urls.get("geosite", ""),
        "geoip_url": urls.get("geoip", ""),
        "categories_table": categories_table(
            geosite.get("codes") or [], geoip.get("codes") or []
        ),
        "geosite_categories": ", ".join(geosite.get("codes") or []),
        "geoip_categories": ", ".join(geoip.get("codes") or []),
    }
    return context
