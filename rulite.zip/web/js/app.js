/* ❤️ RULITE — панель управления. Все данные приходят из REST API бэкенда. */

const state = {
    type: 'geosite',
    page: 1,
    limit: 10,
    query: '',
    total: 0,
    totalPages: 1,
    counts: new Map(),          // code -> количество записей (для текущего типа)
    selection: {},              // type -> {disabled: Set, excluded: Map<code, Set>}
    jobTimer: null,
    searchTimeout: null,
    estimateTimeout: null,
    watching: null,
    totals: {categories: 0, entries: 0},
    settings: null,
    custom: {geosite: [], geoip: []},
    customHelp: {},
    codeCache: {},
    editing: null,
    catalogue: {geosite: [], geoip: []},
    counts2: {geosite: new Map(), geoip: new Map()},
    notes: {geosite: {categories: {}, records: {}}, geoip: {categories: {}, records: {}}},
    trayQuery: '',
    trayShown: 80,
    noteCtx: null,
    dragCode: null,
    moveCtx: null
};

const MARK_COLORS = [
    ['', 'без метки'],
    ['red', 'красная'],
    ['amber', 'жёлтая'],
    ['green', 'зелёная'],
    ['blue', 'синяя'],
    ['violet', 'фиолетовая']
];
const TRAY_STEP = 80;

const ENTRY_PAGE = 200;

/* ---------------------------------------------------------------- утилиты */

async function api(path, options = {}) {
    const response = await fetch(path, {
        headers: {'Content-Type': 'application/json'},
        ...options
    });
    if (response.status === 401) {
        location.href = '/login';
        throw new Error('unauthorized');
    }
    if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        throw new Error(data.detail || `Ошибка ${response.status}`);
    }
    return response.status === 204 ? null : response.json();
}

function escapeHtml(text) {
    return String(text).replace(/[&<>"']/g, ch => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[ch]));
}

function highlightText(text, query) {
    const safe = escapeHtml(text);
    if (!query) return safe;
    const escaped = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return safe.replace(new RegExp(`(${escaped})`, 'gi'), '<span class="highlight">$1</span>');
}

function formatNumber(value) {
    return new Intl.NumberFormat('ru-RU').format(value || 0);
}

function formatDate(iso) {
    if (!iso) return '';
    const date = new Date(iso);
    return Number.isNaN(date.getTime()) ? '' : date.toLocaleString('ru-RU');
}

function showError(message) {
    const box = document.getElementById('errorMessage');
    box.textContent = message;
    box.classList.remove('hidden');
}

function hideError() {
    document.getElementById('errorMessage').classList.add('hidden');
}

/* ------------------------------------------------------------------ тема */

const savedTheme = localStorage.getItem('theme')
    || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
document.documentElement.classList.toggle('dark', savedTheme === 'dark');

document.getElementById('themeToggle').addEventListener('click', () => {
    document.documentElement.classList.toggle('dark');
    localStorage.setItem('theme',
        document.documentElement.classList.contains('dark') ? 'dark' : 'light');
});

/* -------------------------------------------------------------- выбор */

function selectionFor(type) {
    return state.selection[type];
}

async function loadSelection(type) {
    const data = await api(`/api/selection?type=${type}`);
    state.selection[type] = {
        disabled: new Set(data.disabled_categories),
        excluded: new Map(Object.entries(data.excluded).map(([k, v]) => [k, new Set(v)]))
    };
}

function categoryState(code, count) {
    const sel = selectionFor(state.type);
    if (count === undefined) count = state.counts2[state.type].get(code);
    if (sel.disabled.has(code)) return 'none';
    const excluded = sel.excluded.get(code);
    if (!excluded || excluded.size === 0) return 'all';
    if (count && excluded.size >= count) return 'none';
    return 'partial';
}

function setCategoryChecked(code, checked) {
    const sel = selectionFor(state.type);
    sel.excluded.delete(code);
    if (checked) {
        sel.disabled.delete(code);
    } else {
        sel.disabled.add(code);
    }
}

function setEntryChecked(code, key, checked) {
    const sel = selectionFor(state.type);
    if (sel.disabled.has(code)) return;
    let excluded = sel.excluded.get(code);
    if (checked) {
        if (excluded) {
            excluded.delete(key);
            if (excluded.size === 0) sel.excluded.delete(code);
        }
    } else {
        if (!excluded) {
            excluded = new Set();
            sel.excluded.set(code, excluded);
        }
        excluded.add(key);
    }
}

function selectionPayload(type) {
    const sel = state.selection[type];
    const excluded = {};
    sel.excluded.forEach((set, code) => {
        if (set.size) excluded[code] = Array.from(set);
    });
    return {
        type,
        disabled_categories: Array.from(sel.disabled),
        excluded
    };
}

/* ---------------------------------------------------------- рендер списка */

async function renderCategories() {
    const list = document.getElementById('categoryList');
    list.innerHTML = '<li class="list-placeholder">Загружаю…</li>';

    let data;
    try {
        const params = new URLSearchParams({
            type: state.type,
            page: state.page,
            limit: state.limit,
            q: state.query
        });
        data = await api(`/api/categories?${params}`);
        hideError();
    } catch (err) {
        list.innerHTML = '';
        showError(err.message);
        return;
    }

    state.total = data.total;
    state.totalPages = Math.max(1, Math.ceil(data.total / state.limit));
    state.totals = data.totals;
    scheduleEstimate();

    list.innerHTML = '';
    if (!data.items.length) {
        list.innerHTML = '<li class="list-placeholder">Ничего не найдено</li>';
        updatePagination();
        return;
    }

    const fragment = document.createDocumentFragment();
    data.items.forEach(item => {
        state.counts.set(item.code, item.count);
        fragment.appendChild(buildCategoryNode(item));
    });
    list.appendChild(fragment);
    updatePagination();
}

function buildCategoryNode(item) {
    const li = document.createElement('li');
    li.className = 'category-item' + (item.isNew ? ' category-new' : '');
    li.dataset.code = item.code;

    const header = document.createElement('div');
    header.className = 'category-header';
    header.draggable = true;
    header.addEventListener('dragstart', e => {
        state.dragCode = item.code;
        e.dataTransfer.setData('text/plain', item.code);
        e.dataTransfer.effectAllowed = 'copy';
        li.classList.add('dragging');
        document.body.classList.add('dragging-now');
    });
    header.addEventListener('dragend', () => {
        state.dragCode = null;
        li.classList.remove('dragging');
        document.body.classList.remove('dragging-now');
        document.querySelectorAll('.drop-hot')
            .forEach(node => node.classList.remove('drop-hot'));
    });

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.className = 'category-checkbox';
    applyCheckboxState(checkbox, categoryState(item.code, item.count));

    const title = document.createElement('h3');
    title.innerHTML = `
        <svg class="icon chevron" viewBox="0 0 24 24" width="20" height="20" stroke="currentColor"
             stroke-width="2" fill="none">
            <polyline points="9 18 15 12 9 6"></polyline>
        </svg>
        <span class="category-code">${highlightText(item.code, state.query)}</span>
        <span class="category-count">${formatNumber(item.count)} записей</span>
        ${item.isNew ? '<span class="badge-new">новая</span>' : ''}
    `;

    const label = document.createElement('label');
    label.className = 'category-toggle';
    label.appendChild(checkbox);
    header.append(label, title);

    const note = noteFor('category', item.code);
    const dot = markNode(note);
    if (dot) title.insertBefore(dot, title.firstChild);

    const used = originMap().get(item.code) || [];
    if (used.length) {
        const badge = document.createElement('span');
        const hard = used.some(u => u.hard);
        badge.className = 'moved-badge' + (hard ? ' moved-hard' : '');
        badge.textContent = `${hard ? '⇢' : '→'} ${used.map(u => u.code).join(', ')}`;
        badge.title = hard
            ? 'Категория целиком перенесена в свою и в файл отдельно не попадёт'
            : 'Записи скопированы в свою категорию';
        title.appendChild(badge);
    }

    const tools = document.createElement('div');
    tools.className = 'row-tools';

    const move = document.createElement('button');
    move.type = 'button';
    move.className = 'icon-action tiny';
    move.title = 'Добавить в свою категорию';
    move.innerHTML = `
        <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor"
             stroke-width="1.9" fill="none" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 5v14M5 12h14"></path>
        </svg>`;
    move.addEventListener('click', e => {
        e.stopPropagation();
        openMove(item.code);
    });

    tools.append(move, noteButton('category', item.code, `${state.type}:${item.code}`));
    header.appendChild(tools);

    const content = document.createElement('div');
    content.className = 'category-content hidden';
    li.append(header, content);

    if (note && note.note) {
        const line = document.createElement('div');
        line.className = 'note-line';
        line.textContent = note.note;
        li.insertBefore(line, content);
    }

    checkbox.addEventListener('click', e => e.stopPropagation());
    checkbox.addEventListener('change', () => {
        setCategoryChecked(item.code, checkbox.checked);
        applyCheckboxState(checkbox, categoryState(item.code, item.count));
        content.innerHTML = '';
        delete content.dataset.loaded;
        if (!content.classList.contains('hidden')) loadEntries(li, content, 0);
        scheduleEstimate();
    });

    title.addEventListener('click', () => toggleCategory(li, header, content));

    return li;
}

function applyCheckboxState(checkbox, value) {
    checkbox.checked = value !== 'none';
    checkbox.indeterminate = value === 'partial';
}

function toggleCategory(li, header, content) {
    const hidden = content.classList.toggle('hidden');
    header.querySelector('.chevron').style.transform = hidden ? '' : 'rotate(90deg)';
    if (!hidden && !content.dataset.loaded) {
        loadEntries(li, content, 0);
    }
}

async function loadEntries(li, content, offset) {
    const code = li.dataset.code;
    const disabled = selectionFor(state.type).disabled.has(code);

    if (offset === 0) {
        content.innerHTML = '<div class="entry-placeholder">Загружаю записи…</div>';
    }

    let data;
    try {
        const params = new URLSearchParams({
            type: state.type,
            offset,
            limit: ENTRY_PAGE,
            q: state.query
        });
        data = await api(`/api/categories/${encodeURIComponent(code)}/entries?${params}`);
    } catch (err) {
        content.innerHTML = `<div class="entry-placeholder">${escapeHtml(err.message)}</div>`;
        return;
    }

    if (offset === 0) {
        content.innerHTML = '';
        content.dataset.loaded = '1';
        const full = state.counts.get(code) || state.counts2[state.type].get(code);
        if (state.query && full && data.total < full) {
            const filtered = document.createElement('div');
            filtered.className = 'entry-notice';
            filtered.textContent =
                `Показаны только совпадающие с поиском записи: ${formatNumber(data.total)} из ${formatNumber(full)}`;
            content.appendChild(filtered);
        }
        if (disabled) {
            const notice = document.createElement('div');
            notice.className = 'entry-notice';
            notice.textContent = 'Категория выключена целиком. Включите её, чтобы выбирать записи по отдельности.';
            content.appendChild(notice);
        }
    }

    let ul = content.querySelector('.entry-list');
    if (!ul) {
        ul = document.createElement('ul');
        ul.className = 'entry-list';
        content.appendChild(ul);
    }

    const excluded = selectionFor(state.type).excluded.get(code);
    const fragment = document.createDocumentFragment();

    data.items.forEach(entry => {
        const item = document.createElement('li');
        item.className = 'entry-item';

        const box = document.createElement('input');
        box.type = 'checkbox';
        box.className = 'entry-checkbox';
        box.checked = !disabled && !(excluded && excluded.has(entry.key));
        box.disabled = disabled;
        box.addEventListener('change', () => {
            setEntryChecked(code, entry.key, box.checked);
            refreshCategoryCheckbox(li, code);
        });

        const type = document.createElement('span');
        type.className = `entry-type ${entry.typeClass}`;
        type.textContent = entry.type;

        const value = document.createElement('span');
        value.className = 'entry-value';
        value.innerHTML = highlightText(entry.value, state.query);

        item.append(box, type, value);

        const note = noteFor('record', entry.key);
        const dot = markNode(note);
        if (dot) item.insertBefore(dot, item.firstChild);
        item.appendChild(locateButton(entry.key, code));
        item.appendChild(noteButton('record', entry.key, entry.key));

        fragment.appendChild(item);

        if (note && note.note) {
            const line = document.createElement('li');
            line.className = 'entry-note';
            line.textContent = note.note;
            fragment.appendChild(line);
        }
    });

    ul.appendChild(fragment);

    const oldMore = content.querySelector('.load-more');
    if (oldMore) oldMore.remove();

    const shown = offset + data.items.length;
    if (shown < data.total) {
        const more = document.createElement('button');
        more.className = 'load-more';
        more.type = 'button';
        more.textContent = `Показать ещё (осталось ${formatNumber(data.total - shown)})`;
        more.addEventListener('click', () => loadEntries(li, content, shown));
        content.appendChild(more);
    }
}

function refreshCategoryCheckbox(li, code) {
    const checkbox = li.querySelector('.category-checkbox');
    applyCheckboxState(checkbox, categoryState(code, state.counts.get(code)));
    scheduleEstimate();
}

function updatePagination() {
    const start = state.total === 0 ? 0 : ((state.page - 1) * state.limit) + 1;
    const end = Math.min(state.page * state.limit, state.total);
    const info = `${start}–${end} из ${formatNumber(state.total)}`;

    ['Top', 'Bottom'].forEach(pos => {
        document.getElementById(`paginationInfo${pos}`).textContent = info;
        document.getElementById(`prevPage${pos}`).disabled = state.page <= 1;
        document.getElementById(`nextPage${pos}`).disabled = state.page >= state.totalPages;
    });
}

/* ------------------------------------------------------------- управление */

document.querySelectorAll('input[name="fileType"]').forEach(input => {
    input.addEventListener('change', async e => {
        state.type = e.target.value;
        state.page = 1;
        state.counts.clear();
        document.getElementById('contentTitle').textContent =
            state.type === 'geosite' ? 'Содержимое GeoSite' : 'Содержимое GeoIP';
        state.trayShown = TRAY_STEP;
        await Promise.all([
            loadCatalogue(state.type),
            loadAnnotations(state.type),
            loadCustom(state.type)
        ]);
        await renderCategories();
    });
});

document.getElementById('itemsPerPage').addEventListener('change', e => {
    state.limit = parseInt(e.target.value, 10);
    state.page = 1;
    renderCategories();
});

document.getElementById('searchInput').addEventListener('input', e => {
    clearTimeout(state.searchTimeout);
    state.searchTimeout = setTimeout(() => {
        state.query = e.target.value.trim();
        state.page = 1;
        renderCategories();
    }, 350);
});

['Top', 'Bottom'].forEach(pos => {
    document.getElementById(`prevPage${pos}`).addEventListener('click', () => {
        if (state.page > 1) {
            state.page--;
            renderCategories();
        }
    });
    document.getElementById(`nextPage${pos}`).addEventListener('click', () => {
        if (state.page < state.totalPages) {
            state.page++;
            renderCategories();
        }
    });
});

document.getElementById('expandAll').addEventListener('click', () => {
    document.querySelectorAll('.category-item').forEach(li => {
        const header = li.querySelector('.category-header');
        const content = li.querySelector('.category-content');
        if (content.classList.contains('hidden')) {
            toggleCategory(li, header, content);
        }
    });
});

document.getElementById('collapseAll').addEventListener('click', () => {
    document.querySelectorAll('.category-item').forEach(li => {
        const content = li.querySelector('.category-content');
        content.classList.add('hidden');
        li.querySelector('.chevron').style.transform = '';
    });
});

document.getElementById('selectAll').addEventListener('click', async () => {
    const sel = selectionFor(state.type);
    sel.disabled.clear();
    sel.excluded.clear();
    await renderCategories();
});

document.getElementById('deselectAll').addEventListener('click', async () => {
    if (!confirm('Снять выбор со всех категорий этого файла?')) return;
    if (!state.catalogue[state.type].length) await loadCatalogue(state.type);
    const sel = selectionFor(state.type);
    sel.excluded.clear();
    state.catalogue[state.type].forEach(item => sel.disabled.add(item.code));
    await renderCategories();
});

document.getElementById('logoutButton').addEventListener('click', async () => {
    await api('/api/auth/logout', {method: 'POST'});
    location.href = '/login';
});

/* --------------------------------------------------------------- задачи */

function renderJob(job) {
    const panel = document.getElementById('jobPanel');
    const bar = document.getElementById('jobBar');
    const close = document.getElementById('jobClose');

    panel.classList.remove('hidden');
    panel.classList.toggle('job-done', job.status === 'done');
    panel.classList.toggle('job-failed', job.status === 'error');

    document.getElementById('jobStep').textContent =
        job.status === 'error' ? (job.error || 'Задача завершилась с ошибкой') : job.step;
    document.getElementById('jobPercent').textContent = `${job.progress}%`;
    bar.style.width = `${job.progress}%`;
    document.getElementById('jobLog').textContent =
        job.lines.map(line => `${line.time.slice(11, 19)}  ${line.message}`).join('\n');

    close.classList.toggle('hidden', job.status === 'running');
}

document.getElementById('jobClose').addEventListener('click', () => {
    document.getElementById('jobPanel').classList.add('hidden');
});

async function watchJob(jobId) {
    if (state.watching === jobId) return;
    state.watching = jobId;
    clearInterval(state.jobTimer);
    state.jobTimer = null;

    const stop = () => {
        clearInterval(state.jobTimer);
        state.jobTimer = null;
        state.watching = null;
    };

    const tick = async () => {
        let job;
        try {
            job = await api(`/api/jobs/${jobId}`);
        } catch (err) {
            stop();
            return;
        }
        renderJob(job);
        if (job.status === 'running') return;

        stop();
        document.getElementById('buildButton').disabled = false;
        document.getElementById('refreshButton').disabled = false;
        if (job.status === 'error') {
            showError(job.error || 'Задача завершилась с ошибкой');
        } else {
            hideError();
        }
        await loadSelection('geosite');
        await loadSelection('geoip');
        await loadStatus();
        await Promise.all([
            loadCatalogue(state.type),
            loadAnnotations(state.type),
            loadCustom(state.type)
        ]);
        await renderCategories();
    };

    await tick();
    if (state.watching === jobId && !state.jobTimer) {
        state.jobTimer = setInterval(tick, 1500);
    }
}

document.getElementById('buildButton').addEventListener('click', async () => {
    const button = document.getElementById('buildButton');
    button.disabled = true;
    try {
        const payload = {
            selections: [selectionPayload('geosite'), selectionPayload('geoip')],
            publish: true
        };
        const {jobId} = await api('/api/build', {
            method: 'POST',
            body: JSON.stringify(payload)
        });
        watchJob(jobId);
    } catch (err) {
        showError(err.message);
        button.disabled = false;
    }
});

document.getElementById('refreshButton').addEventListener('click', async () => {
    const button = document.getElementById('refreshButton');
    button.disabled = true;
    try {
        const {jobId} = await api('/api/refresh', {method: 'POST'});
        watchJob(jobId);
    } catch (err) {
        showError(err.message);
        button.disabled = false;
    }
});

/* ------------------------------------------------ сворачиваемый блок */

const actionsCard = document.querySelector('.actions-card');

if (localStorage.getItem('rulite.details') === 'off') {
    actionsCard.classList.add('collapsed');
}

document.getElementById('detailsToggle').addEventListener('click', () => {
    const collapsed = actionsCard.classList.toggle('collapsed');
    localStorage.setItem('rulite.details', collapsed ? 'off' : 'on');
});

/* ------------------------------------------------ каталог и заметки */

async function loadCatalogue(type) {
    try {
        const data = await api(`/api/catalogue?type=${type}`);
        state.catalogue[type] = data.items;
        state.counts2[type] = new Map(data.items.map(i => [i.code, i.count]));
    } catch (err) {
        state.catalogue[type] = [];
    }
    if (type === state.type) renderTray();
}

async function loadAnnotations(type) {
    try {
        const data = await api(`/api/annotations?type=${type}`);
        state.notes[type] = {categories: data.categories, records: data.records};
    } catch (err) {
        state.notes[type] = {categories: {}, records: {}};
    }
}

function noteFor(scope, key) {
    return state.notes[state.type][scope === 'category' ? 'categories' : 'records'][key];
}

function markNode(entry) {
    if (!entry || !entry.color) return null;
    const dot = document.createElement('span');
    dot.className = `mark mark-${entry.color}`;
    dot.title = 'Метка';
    return dot;
}

function locateButton(key, currentCode) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'icon-action tiny';
    button.title = 'В каких ещё категориях встречается';
    button.innerHTML = `
        <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor"
             stroke-width="1.9" fill="none" stroke-linecap="round">
            <circle cx="11" cy="11" r="6.5"></circle>
            <line x1="20.5" y1="20.5" x2="16" y2="16"></line>
        </svg>`;

    button.addEventListener('click', async e => {
        e.stopPropagation();
        const row = button.closest('.entry-item');
        const existing = row.nextElementSibling;
        if (existing && existing.classList.contains('entry-where')) {
            existing.remove();
            return;
        }

        const line = document.createElement('li');
        line.className = 'entry-where';
        line.textContent = 'Ищу по всем категориям…';
        row.after(line);

        try {
            const data = await api(
                `/api/locate?type=${state.type}&key=${encodeURIComponent(key)}`);
            const others = data.categories.filter(c => c !== currentCode);
            line.textContent = others.length
                ? `Встречается также в: ${others.join(', ')}`
                : 'Больше нигде не встречается';
        } catch (err) {
            line.textContent = err.message;
        }
    });
    return button;
}

function noteButton(scope, key, label) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'icon-action tiny note-button';
    const entry = noteFor(scope, key);
    if (entry && entry.note) button.classList.add('has-note');
    button.title = entry && entry.note ? entry.note : 'Заметка';
    button.innerHTML = `
        <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor"
             stroke-width="1.9" fill="none" stroke-linecap="round" stroke-linejoin="round">
            <path d="M4 5.5h16M4 12h16M4 18.5h10"></path>
        </svg>`;
    button.addEventListener('click', e => {
        e.stopPropagation();
        openNote(scope, key, label, button.closest('.category-item, .entry-item, .tray-source'));
    });
    return button;
}

/* --- окно заметки --- */

const noteModal = document.getElementById('noteModal');

function openNote(scope, key, label, node) {
    const entry = noteFor(scope, key) || {note: '', color: ''};
    state.noteCtx = {scope, key, color: entry.color || '', node: node || null};

    document.getElementById('noteTitle').textContent =
        scope === 'category' ? 'Заметка к категории' : 'Заметка к записи';
    document.getElementById('noteTarget').textContent = label || key;
    document.getElementById('noteText').value = entry.note || '';
    renderSwatches();
    noteModal.classList.remove('hidden');
    document.getElementById('noteText').focus();
}

function renderSwatches() {
    const box = document.getElementById('noteColors');
    box.innerHTML = '';
    MARK_COLORS.forEach(([value, title]) => {
        const swatch = document.createElement('button');
        swatch.type = 'button';
        swatch.className = 'swatch' + (state.noteCtx.color === value ? ' selected' : '');
        swatch.title = title;
        if (value) swatch.classList.add(`mark-${value}`);
        swatch.addEventListener('click', () => {
            state.noteCtx.color = value;
            renderSwatches();
        });
        box.appendChild(swatch);
    });
}

async function storeNote(note, color) {
    const {scope, key} = state.noteCtx;
    const bucket = scope === 'category' ? 'categories' : 'records';
    try {
        const data = await api('/api/annotations', {
            method: 'POST',
            body: JSON.stringify({type: state.type, scope, key, note, color})
        });
        if (data.entry) {
            state.notes[state.type][bucket][key] = data.entry;
        } else {
            delete state.notes[state.type][bucket][key];
        }
    } catch (err) {
        showError(err.message);
        return;
    }
    noteModal.classList.add('hidden');
    refreshNoteVisual();
    renderTray();
}

function refreshNoteVisual() {
    const {scope, key, node} = state.noteCtx;
    const entry = noteFor(scope, key);

    if (node && node.classList.contains('tray-source')) {
        return;  // панель состава перерисуется целиком следом
    }

    document.querySelectorAll('.mark').forEach(dot => {
        if (node && node.contains(dot)) dot.remove();
    });

    if (node) {
        const dot = markNode(entry);
        const anchor = node.classList.contains('category-item')
            ? node.querySelector('.category-header h3')
            : node;
        if (dot && anchor) anchor.insertBefore(dot, anchor.firstChild);

        const button = node.querySelector('.note-button');
        if (button) {
            button.classList.toggle('has-note', Boolean(entry && entry.note));
            button.title = entry && entry.note ? entry.note : 'Заметка';
        }

        const isCategory = node.classList.contains('category-item');
        const lineClass = isCategory ? 'note-line' : 'entry-note';
        const existing = isCategory
            ? node.querySelector(':scope > .note-line')
            : (node.nextElementSibling && node.nextElementSibling.classList.contains('entry-note')
                ? node.nextElementSibling : null);
        if (existing) existing.remove();

        if (entry && entry.note) {
            const line = document.createElement(isCategory ? 'div' : 'li');
            line.className = lineClass;
            line.textContent = entry.note;
            if (isCategory) {
                node.insertBefore(line, node.querySelector('.category-content'));
            } else {
                node.after(line);
            }
        }
    }
}

document.getElementById('noteSave').addEventListener('click', () => {
    storeNote(document.getElementById('noteText').value, state.noteCtx.color);
});
document.getElementById('noteClear').addEventListener('click', () => storeNote('', ''));
document.getElementById('closeNote').addEventListener('click', () => {
    noteModal.classList.add('hidden');
});

/* --------------------------------------------------- панель состава */

function customFor(type) {
    return state.custom[type] || [];
}

function originMap() {
    const map = new Map();
    customFor(state.type).forEach(item => {
        if (!item.enabled) return;
        item.sources.forEach(code => {
            if (!map.has(code)) map.set(code, []);
            map.get(code).push({code: item.code, hard: item.replace_sources});
        });
    });
    return map;
}

function selectedSources() {
    const sel = selectionFor(state.type);
    const origins = originMap();
    const result = [];
    state.catalogue[state.type].forEach(item => {
        if (sel.disabled.has(item.code)) return;
        const excluded = sel.excluded.get(item.code);
        const gone = excluded ? excluded.size : 0;
        if (item.count && gone >= item.count) return;
        const moved = (origins.get(item.code) || []).filter(o => o.hard);
        if (moved.length) return;   // категория переехала в свою целиком
        result.push({...item, excluded: gone, usedIn: origins.get(item.code) || []});
    });
    return result;
}

function renderTray() {
    if (!state.catalogue[state.type].length) return;
    renderTrayCustom();
    renderTraySources();
}

function renderTrayCustom() {
    const box = document.getElementById('trayCustom');
    box.innerHTML = '';
    const items = customFor(state.type);

    if (!items.length) {
        const empty = document.createElement('p');
        empty.className = 'tray-empty';
        empty.textContent = 'Пока ни одной. Соберите свою из существующих категорий.';
        box.appendChild(empty);
        return;
    }

    items.forEach((item, index) => {
        const row = document.createElement('div');
        row.className = 'tray-custom' + (item.enabled ? '' : ' custom-off');
        row.dataset.index = index;

        const head = document.createElement('div');
        head.className = 'tray-custom-head';

        const box2 = document.createElement('input');
        box2.type = 'checkbox';
        box2.checked = item.enabled;
        box2.title = 'Включить в сборку';
        box2.addEventListener('change', async () => {
            item.enabled = box2.checked;
            await saveCustomList();
        });

        const code = document.createElement('span');
        code.className = 'tray-custom-code';
        code.textContent = `${state.type}:${item.code}`;

        const stat = document.createElement('span');
        stat.className = 'tray-custom-stat';
        const stats = item.stats || {entries: 0, manual: 0};
        stat.textContent = stats.entries ? `${formatNumber(stats.entries)} зап.` : '…';

        const edit = document.createElement('button');
        edit.type = 'button';
        edit.className = 'icon-action tiny';
        edit.title = 'Изменить';
        edit.innerHTML = `
            <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor"
                 stroke-width="1.9" fill="none" stroke-linecap="round" stroke-linejoin="round">
                <path d="M4 20h4l10-10-4-4L4 16v4z"></path>
            </svg>`;
        edit.addEventListener('click', () => openCustomEditor(index));

        head.append(box2, code, stat, edit);
        row.appendChild(head);

        const origins = document.createElement('div');
        origins.className = 'origin-list';

        const label = document.createElement('span');
        label.className = 'origin-label';
        label.textContent = item.replace_sources
            ? 'Перенесено целиком из:'
            : 'Скопировано из:';

        if (item.sources.length) {
            origins.appendChild(label);
            item.sources.forEach(source => {
                const line = document.createElement('div');
                line.className = 'origin';

                const name = document.createElement('span');
                name.className = 'origin-code';
                name.textContent = `${state.type}:${source}`;

                const count = document.createElement('span');
                count.className = 'origin-count';
                count.textContent = formatNumber(state.counts2[state.type].get(source) || 0);

                const drop = document.createElement('button');
                drop.type = 'button';
                drop.className = 'origin-drop';
                drop.textContent = '×';
                drop.title = 'Убрать источник';
                drop.addEventListener('click', async () => {
                    item.sources = item.sources.filter(s => s !== source);
                    if (!item.sources.length && !(item.entries || '').trim()) {
                        showError('У категории не осталось содержимого — удалите её целиком.');
                        item.sources.push(source);
                        return;
                    }
                    await saveCustomList();
                });

                line.append(name, count, drop);
                origins.appendChild(line);
            });
        }

        if ((item.entries || '').trim()) {
            const own = document.createElement('div');
            own.className = 'origin-own';
            own.textContent = `собственных записей: ${formatNumber(stats.manual)}`;
            origins.appendChild(own);
        }

        if (origins.childNodes.length) row.appendChild(origins);

        makeDropTarget(row, code => addSourceToCustom(index, code));
        box.appendChild(row);
    });
}

function renderTraySources() {
    const box = document.getElementById('traySources');
    const more = document.getElementById('trayMore');
    box.innerHTML = '';

    const all = selectedSources();
    const query = state.trayQuery.toLowerCase();
    const items = query ? all.filter(i => i.code.toLowerCase().includes(query)) : all;

    const totalEntries = all.reduce((sum, i) => sum + (i.count - i.excluded), 0);
    document.getElementById('traySourceCount').textContent =
        `${formatNumber(all.length)} шт.`;
    document.getElementById('trayTotal').textContent =
        `${formatNumber(all.length + customFor(state.type).filter(c => c.enabled).length)}`
        + ` категорий · ${formatNumber(totalEntries)} записей из источника`;

    if (!items.length) {
        const empty = document.createElement('p');
        empty.className = 'tray-empty';
        empty.textContent = query ? 'Ничего не найдено' : 'Ни одной категории не выбрано';
        box.appendChild(empty);
        more.classList.add('hidden');
        return;
    }

    const shown = items.slice(0, state.trayShown);
    const fragment = document.createDocumentFragment();

    shown.forEach(item => {
        const row = document.createElement('div');
        row.className = 'tray-source';

        const note = noteFor('category', item.code);
        const dot = markNode(note);
        if (dot) row.appendChild(dot);

        const code = document.createElement('span');
        code.className = 'tray-custom-code';
        code.textContent = item.code;
        if (note && note.note) code.title = note.note;

        const count = document.createElement('span');
        count.className = 'tray-source-count';
        count.textContent = item.excluded
            ? `${formatNumber(item.count - item.excluded)} из ${formatNumber(item.count)}`
            : formatNumber(item.count);

        row.append(code, count);

        if (item.usedIn.length) {
            const badge = document.createElement('span');
            badge.className = 'moved-badge';
            badge.textContent = `→ ${item.usedIn.map(u => u.code).join(', ')}`;
            badge.title = 'Записи также скопированы в свою категорию';
            row.appendChild(badge);
        }

        row.appendChild(noteButton('category', item.code, `${state.type}:${item.code}`));

        const remove = document.createElement('button');
        remove.type = 'button';
        remove.className = 'icon-action tiny';
        remove.title = 'Убрать из сборки';
        remove.innerHTML = `
            <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor"
                 stroke-width="2" fill="none" stroke-linecap="round">
                <path d="M6 6l12 12M18 6L6 18"></path>
            </svg>`;
        remove.addEventListener('click', async () => {
            setCategoryChecked(item.code, false);
            scheduleEstimate();
            renderTray();
            await renderCategories();
        });
        row.appendChild(remove);

        fragment.appendChild(row);
    });

    box.appendChild(fragment);

    if (items.length > shown.length) {
        more.classList.remove('hidden');
        more.textContent = `Показать ещё (осталось ${formatNumber(items.length - shown.length)})`;
    } else {
        more.classList.add('hidden');
    }
}

document.getElementById('trayMore').addEventListener('click', () => {
    state.trayShown += TRAY_STEP;
    renderTraySources();
});

document.getElementById('traySearch').addEventListener('input', e => {
    state.trayQuery = e.target.value;
    state.trayShown = TRAY_STEP;
    renderTraySources();
});

document.getElementById('trayCollapse').addEventListener('click', e => {
    e.currentTarget.closest('.tray-card').classList.toggle('collapsed');
});

document.getElementById('trayAddCustom').addEventListener('click', () => openCustomEditor(null));

/* --- перетаскивание --- */

function makeDropTarget(node, handler) {
    // Safari отдаёт содержимое переноса только в drop, поэтому разрешаем
    // приём по факту самого перетаскивания, а не по прочитанным данным.
    const allow = e => {
        e.preventDefault();
        e.stopPropagation();
        if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
        node.classList.add('drop-hot');
    };

    node.addEventListener('dragenter', allow);
    node.addEventListener('dragover', allow);
    node.addEventListener('dragleave', e => {
        if (!node.contains(e.relatedTarget)) node.classList.remove('drop-hot');
    });
    node.addEventListener('drop', e => {
        e.preventDefault();
        e.stopPropagation();
        node.classList.remove('drop-hot');
        let code = '';
        try {
            code = e.dataTransfer.getData('text/plain');
        } catch (err) {
            code = '';
        }
        code = code || state.dragCode;
        if (code) handler(code);
    });
}

async function addSourceToCustom(index, code) {
    const item = customFor(state.type)[index];
    if (!item || item.sources.includes(code)) return;
    item.sources.push(code);
    try {
        await saveCustomList();
        await renderCategories();
    } catch (err) {
        item.sources = item.sources.filter(s => s !== code);
        showError(err.message);
    }
}

makeDropTarget(document.getElementById('dropNew'), code => {
    openCustomEditor(null);
    state.editing.sources = [code];
    renderChips();
    document.getElementById('customCode').value = code.replace(/[^a-z0-9._-]/gi, '-');
    updateCodePreview();
});

/* --- «добавить в свою» без мыши --- */

const moveModal = document.getElementById('moveModal');

function openMove(code) {
    state.moveCtx = code;
    document.getElementById('moveTarget').textContent = `${state.type}:${code}`;
    const list = document.getElementById('moveList');
    list.innerHTML = '';

    customFor(state.type).forEach((item, index) => {
        const option = document.createElement('button');
        option.type = 'button';
        option.className = 'move-option';
        option.innerHTML = `<code>${escapeHtml(item.code)}</code>`;
        if (item.sources.includes(code)) {
            option.disabled = true;
            option.innerHTML += ' <span class="tray-source-count">уже добавлена</span>';
        }
        option.addEventListener('click', async () => {
            moveModal.classList.add('hidden');
            await addSourceToCustom(index, code);
        });
        list.appendChild(option);
    });

    const fresh = document.createElement('button');
    fresh.type = 'button';
    fresh.className = 'move-option';
    fresh.textContent = '+ Создать новую из этой категории';
    fresh.addEventListener('click', () => {
        moveModal.classList.add('hidden');
        openCustomEditor(null);
        state.editing.sources = [code];
        renderChips();
        document.getElementById('customCode').value = code.replace(/[^a-z0-9._-]/gi, '-');
        updateCodePreview();
    });
    list.appendChild(fresh);

    moveModal.classList.remove('hidden');
}

document.getElementById('closeMove').addEventListener('click', () => {
    moveModal.classList.add('hidden');
});

/* ----------------------------------------------------- свои категории */

const customModal = document.getElementById('customModal');

async function loadCustom(type) {
    try {
        const data = await api(`/api/custom?type=${type}`);
        state.custom[type] = data.items;
        state.customHelp[type] = data.help;
    } catch (err) {
        state.custom[type] = [];
    }
    if (type === state.type) renderTray();
}

async function saveCustomList() {
    const payload = {
        type: state.type,
        items: state.custom[state.type].map(item => ({
            id: item.id,
            code: item.code,
            enabled: item.enabled,
            sources: item.sources,
            entries: item.entries,
            replace_sources: item.replace_sources
        }))
    };
    const data = await api('/api/custom', {
        method: 'POST',
        body: JSON.stringify(payload)
    });
    state.custom[state.type] = data.items;
    renderTray();
    scheduleEstimate();
    return data;
}

async function categoryCodes(type) {
    if (!state.catalogue[type].length) await loadCatalogue(type);
    state.codeCache[type] = state.catalogue[type].map(i => i.code);
    return state.codeCache[type];
}

function openCustomEditor(index) {
    const type = state.type;
    const existing = index === null ? null : state.custom[type][index];
    state.editing = {
        index,
        sources: existing ? [...existing.sources] : []
    };

    document.getElementById('customTitle').textContent = existing
        ? 'Изменить категорию'
        : 'Новая категория';
    document.getElementById('customCode').value = existing ? existing.code : '';
    document.getElementById('customEntries').value = existing ? existing.entries : '';
    document.getElementById('customReplace').checked = existing
        ? existing.replace_sources : false;
    document.getElementById('deleteCustom').classList.toggle('hidden', !existing);
    document.getElementById('customError').classList.add('hidden');
    document.getElementById('customSourceInput').value = '';

    const help = document.getElementById('customHelp');
    help.innerHTML = '';
    const pre = document.createElement('pre');
    pre.textContent = state.customHelp[type] || '';
    help.appendChild(pre);

    updateCodePreview();
    renderChips();

    categoryCodes(type).then(codes => {
        const datalist = document.getElementById('customCodes');
        datalist.innerHTML = '';
        codes.forEach(code => {
            const option = document.createElement('option');
            option.value = code;
            datalist.appendChild(option);
        });
    }).catch(() => {});

    customModal.classList.remove('hidden');
    document.getElementById('customCode').focus();
}

function updateCodePreview() {
    const value = document.getElementById('customCode').value.trim() || 'my-list';
    document.getElementById('customCodePreview').textContent = `${state.type}:${value}`;
}

function renderChips() {
    const box = document.getElementById('customSources');
    box.innerHTML = '';
    state.editing.sources.forEach((code, index) => {
        const chip = document.createElement('span');
        chip.className = 'chip';
        chip.append(document.createTextNode(code));

        const remove = document.createElement('button');
        remove.type = 'button';
        remove.textContent = '×';
        remove.title = 'Убрать';
        remove.addEventListener('click', () => {
            state.editing.sources.splice(index, 1);
            renderChips();
        });

        chip.appendChild(remove);
        box.appendChild(chip);
    });
}

function addSource() {
    const input = document.getElementById('customSourceInput');
    const value = input.value.trim();
    if (!value) return;
    const codes = state.codeCache[state.type] || [];
    if (codes.length && !codes.includes(value)) {
        customError(`Категории «${value}» нет в исходном файле`);
        return;
    }
    if (!state.editing.sources.includes(value)) {
        state.editing.sources.push(value);
        renderChips();
    }
    input.value = '';
    input.focus();
    document.getElementById('customError').classList.add('hidden');
}

function customError(message) {
    const box = document.getElementById('customError');
    box.textContent = message;
    box.classList.remove('hidden');
}

document.getElementById('customCode').addEventListener('input', updateCodePreview);
document.getElementById('customSourceAdd').addEventListener('click', addSource);
document.getElementById('customSourceInput').addEventListener('keydown', e => {
    if (e.key === 'Enter') {
        e.preventDefault();
        addSource();
    }
});

document.getElementById('closeCustom').addEventListener('click', () => {
    customModal.classList.add('hidden');
});

document.getElementById('deleteCustom').addEventListener('click', async () => {
    if (state.editing.index === null) return;
    const backup = [...state.custom[state.type]];
    state.custom[state.type].splice(state.editing.index, 1);
    try {
        await saveCustomList();
        customModal.classList.add('hidden');
    } catch (err) {
        state.custom[state.type] = backup;
        customError(err.message);
    }
});

document.getElementById('saveCustom').addEventListener('click', async () => {
    const button = document.getElementById('saveCustom');
    const draft = {
        id: state.editing.index === null
            ? null : state.custom[state.type][state.editing.index].id,
        code: document.getElementById('customCode').value.trim(),
        enabled: state.editing.index === null
            ? true : state.custom[state.type][state.editing.index].enabled,
        sources: state.editing.sources,
        entries: document.getElementById('customEntries').value,
        replace_sources: document.getElementById('customReplace').checked
    };

    const backup = state.custom[state.type].map(item => ({...item}));
    if (state.editing.index === null) {
        state.custom[state.type].push(draft);
    } else {
        state.custom[state.type][state.editing.index] = draft;
    }

    button.disabled = true;
    try {
        await saveCustomList();
        customModal.classList.add('hidden');
    } catch (err) {
        state.custom[state.type] = backup;
        customError(err.message);
    }
    button.disabled = false;
});

/* ------------------------------------------------------- оценка размера */

function formatBytes(bytes) {
    if (!bytes) return '0 Б';
    const units = ['Б', 'КБ', 'МБ', 'ГБ'];
    let value = bytes;
    let unit = 0;
    while (value >= 1024 && unit < units.length - 1) {
        value /= 1024;
        unit++;
    }
    return `${value.toFixed(value >= 100 || unit === 0 ? 0 : 1)} ${units[unit]}`;
}

function scheduleEstimate() {
    renderTray();
    clearTimeout(state.estimateTimeout);
    state.estimateTimeout = setTimeout(updateEstimate, 250);
}

async function updateEstimate() {
    const type = state.type;
    const sizeEl = document.getElementById('sizeEstimate');
    const metaEl = document.getElementById('sizeMeta');

    document.getElementById('categoryTotal').textContent =
        `из ${formatNumber(state.totals.categories)}`;
    document.getElementById('entryTotal').textContent =
        `из ${formatNumber(state.totals.entries)}`;

    let data;
    try {
        data = await api('/api/estimate', {
            method: 'POST',
            body: JSON.stringify(selectionPayload(type))
        });
    } catch (err) {
        sizeEl.textContent = '—';
        metaEl.textContent = '';
        return;
    }
    if (type !== state.type) return;  // пользователь успел переключить файл

    document.getElementById('categoryCount').textContent =
        formatNumber(data.selectedCategories);
    document.getElementById('entryCount').textContent =
        formatNumber(data.selectedEntries);
    sizeEl.textContent = formatBytes(data.bytes);

    const removed = data.removedEntries;
    metaEl.textContent = removed
        ? `отброшено записей: ${formatNumber(removed)}`
        : 'отброшенных записей нет';
}

/* -------------------------------------------------------------- настройки */

const settingsModal = document.getElementById('settingsModal');

function openSettings() {
    settingsModal.classList.remove('hidden');
}

function closeSettings() {
    settingsModal.classList.add('hidden');
}

document.getElementById('settingsButton').addEventListener('click', async () => {
    try {
        state.settings = await api('/api/settings');
    } catch (err) {
        showError(err.message);
        return;
    }
    document.getElementById('sourceGeosite').value = state.settings.sources.geosite || '';
    document.getElementById('sourceGeoip').value = state.settings.sources.geoip || '';
    document.getElementById('sourceGeositeHint').textContent = '';
    document.getElementById('sourceGeoipHint').textContent = '';
    document.getElementById('timezone').value = state.settings.timezone;
    document.getElementById('intervalMinutes').value = state.settings.intervalMinutes;
    document.getElementById('autoPublish').checked = state.settings.autoPublish;

    document.getElementById('readmeEnabled').checked = state.settings.readme.enabled;
    document.getElementById('readmeText').value = state.settings.readme.text;

    const telegram = state.settings.telegram;
    document.getElementById('telegramEnabled').checked = telegram.enabled;
    document.getElementById('telegramChat').value = telegram.chatId || '';
    document.getElementById('telegramToken').value = '';
    document.getElementById('telegramToken').placeholder = telegram.hasToken
        ? 'сохранён — оставьте пустым'
        : 'получите у @BotFather';
    document.getElementById('telegramTokenHint').textContent = telegram.hasToken
        ? `Сохранён токен ${telegram.tokenMask}.`
        : '';
    document.getElementById('oldPassword').value = '';
    document.getElementById('newPassword').value = '';
    document.getElementById('passwordHint').textContent =
        'Смена пароля завершает все другие сессии.';
    document.getElementById('passwordHint').className = 'hint';

    settingsMessage(null, '');
    document.getElementById('notePreview').classList.add('hidden');
    lastFocusedNote = null;
    renderTargets();
    renderNotes();
    renderVariables();
    renderTelegramEvents();
    openTab('sources');
    openSettings();
});

document.getElementById('closeSettings').addEventListener('click', closeSettings);

// Клик мимо окна его не закрывает — только крестик или «Сохранить».
document.addEventListener('keydown', e => {
    if (e.key !== 'Escape') return;
    if (!noteModal.classList.contains('hidden')) {
        noteModal.classList.add('hidden');
    } else if (!moveModal.classList.contains('hidden')) {
        moveModal.classList.add('hidden');
    } else if (!customModal.classList.contains('hidden')) {
        customModal.classList.add('hidden');
    } else if (!settingsModal.classList.contains('hidden')) {
        closeSettings();
    }
});

/* --- репозитории публикации --- */

function renderTargets() {
    const list = document.getElementById('targetList');
    list.innerHTML = '';

    if (!state.settings.targets.length) {
        const empty = document.createElement('p');
        empty.className = 'hint';
        empty.textContent = 'Пока ни одного репозитория. Добавьте хотя бы один, ' +
            'чтобы готовые файлы публиковались автоматически.';
        list.appendChild(empty);
        return;
    }

    state.settings.targets.forEach((target, index) => {
        list.appendChild(buildTargetRow(target, index));
    });
}

function buildTargetRow(target, index) {
    const row = document.createElement('div');
    row.className = 'target-row';
    row.dataset.index = index;

    const head = document.createElement('div');
    head.className = 'target-head';

    const enabled = document.createElement('input');
    enabled.type = 'checkbox';
    enabled.checked = target.enabled;
    enabled.title = 'Публиковать сюда';
    enabled.addEventListener('change', () => {
        target.enabled = enabled.checked;
        row.classList.toggle('target-off', !enabled.checked);
    });

    const provider = document.createElement('select');
    state.settings.providers.forEach(item => {
        const option = document.createElement('option');
        option.value = item.id;
        option.textContent = item.title;
        provider.appendChild(option);
    });
    provider.value = target.provider;
    provider.addEventListener('change', () => {
        target.provider = provider.value;
    });

    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'icon-action tiny';
    remove.title = 'Удалить';
    remove.textContent = '×';
    remove.addEventListener('click', () => {
        state.settings.targets.splice(index, 1);
        renderTargets();
    });

    head.append(enabled, provider, remove);

    const repoField = document.createElement('label');
    repoField.className = 'field';
    repoField.innerHTML = '<span>Репозиторий</span>';
    const repo = document.createElement('input');
    repo.type = 'text';
    repo.placeholder = 'username/my-rules';
    repo.autocomplete = 'off';
    repo.value = target.repo;
    repo.addEventListener('input', () => {
        target.repo = repo.value;
    });
    repoField.appendChild(repo);

    const tokenField = document.createElement('label');
    tokenField.className = 'field';
    tokenField.innerHTML = '<span>Токен</span>';
    const token = document.createElement('input');
    token.type = 'password';
    token.placeholder = target.hasToken ? 'сохранён — оставьте пустым' : 'вставьте токен';
    token.autocomplete = 'off';
    token.addEventListener('input', () => {
        target.token = token.value;
    });
    tokenField.appendChild(token);

    const hint = document.createElement('small');
    hint.className = 'hint';
    hint.textContent = target.hasToken ? `Сохранён токен ${target.tokenMask}.` : '';
    tokenField.appendChild(hint);

    const test = document.createElement('button');
    test.type = 'button';
    test.className = 'button button-small';
    test.textContent = 'Проверить доступ';
    const testResult = document.createElement('small');
    testResult.className = 'hint';

    test.addEventListener('click', async () => {
        test.disabled = true;
        testResult.textContent = 'Проверяю…';
        testResult.className = 'hint';
        try {
            await saveSettings({silent: true});
            const saved = state.settings.targets[index];
            const info = await api('/api/settings/test-target', {
                method: 'POST',
                body: JSON.stringify({id: saved.id})
            });
            testResult.textContent = info.empty
                ? `${info.title}: доступ есть (${info.repo}). Репозиторий пуст — ` +
                  'первый коммит будет создан автоматически при публикации.'
                : `${info.title}: доступ есть (${info.repo})`;
            testResult.className = 'hint hint-ok';
        } catch (err) {
            testResult.textContent = err.message;
            testResult.className = 'hint hint-bad';
        }
        test.disabled = false;
    });

    row.classList.toggle('target-off', !target.enabled);
    row.append(head, repoField, tokenField, test, testResult);
    return row;
}

document.getElementById('addTarget').addEventListener('click', () => {
    state.settings.targets.push({
        id: null, provider: 'github', repo: '', token: '', enabled: true, hasToken: false
    });
    renderTargets();
});

/* --- источники --- */

document.querySelectorAll('[data-test-source]').forEach(button => {
    button.addEventListener('click', async () => {
        const kind = button.dataset.testSource;
        const input = document.getElementById(
            kind === 'geosite' ? 'sourceGeosite' : 'sourceGeoip');
        const hint = document.getElementById(
            kind === 'geosite' ? 'sourceGeositeHint' : 'sourceGeoipHint');
        button.disabled = true;
        hint.textContent = 'Проверяю…';
        hint.className = 'hint';
        try {
            const info = await api('/api/settings/test-source', {
                method: 'POST',
                body: JSON.stringify({url: input.value.trim()})
            });
            hint.textContent = info.size
                ? `Доступен, размер ${formatBytes(info.size)}`
                : 'Доступен';
            hint.className = 'hint hint-ok';
        } catch (err) {
            hint.textContent = err.message;
            hint.className = 'hint hint-bad';
        }
        button.disabled = false;
    });
});

document.getElementById('resetSources').addEventListener('click', () => {
    document.getElementById('sourceGeosite').value = state.settings.defaultSources.geosite;
    document.getElementById('sourceGeoip').value = state.settings.defaultSources.geoip;
});

/* --- вкладки --- */

document.getElementById('settingsTabs').addEventListener('click', e => {
    const tab = e.target.closest('.tab');
    if (!tab) return;
    document.querySelectorAll('#settingsTabs .tab').forEach(item => {
        item.classList.toggle('active', item === tab);
    });
    document.querySelectorAll('.tab-panel').forEach(panel => {
        panel.classList.toggle('hidden', panel.dataset.panel !== tab.dataset.tab);
    });
});

function openTab(name) {
    const tab = document.querySelector(`#settingsTabs .tab[data-tab="${name}"]`);
    if (tab) tab.click();
}

/* --- README репозитория --- */

document.getElementById('readmeText').addEventListener('focus', e => {
    lastFocusedNote = e.target;
});

document.getElementById('readmeReset').addEventListener('click', () => {
    document.getElementById('readmeText').value = state.settings.defaultReadmeText;
});

document.getElementById('readmePreviewButton').addEventListener('click', e => {
    showPreview(document.getElementById('readmeText').value, e.currentTarget);
});

/* --- тексты релиза --- */

let lastFocusedNote = null;

function renderNotes() {
    const list = document.getElementById('noteList');
    list.innerHTML = '';

    state.settings.releaseNotes.forEach((note, index) => {
        const row = document.createElement('div');
        row.className = 'note-row' + (note.enabled ? '' : ' note-off');

        const head = document.createElement('div');
        head.className = 'note-head';

        const enabled = document.createElement('input');
        enabled.type = 'checkbox';
        enabled.checked = note.enabled;
        enabled.title = 'Участвует в ротации';
        enabled.addEventListener('change', () => {
            note.enabled = enabled.checked;
            row.classList.toggle('note-off', !enabled.checked);
        });

        const title = document.createElement('input');
        title.type = 'text';
        title.value = note.title;
        title.placeholder = 'Название варианта';
        title.addEventListener('input', () => { note.title = title.value; });

        const remove = document.createElement('button');
        remove.type = 'button';
        remove.className = 'icon-action tiny';
        remove.title = 'Удалить';
        remove.textContent = '×';
        remove.addEventListener('click', () => {
            state.settings.releaseNotes.splice(index, 1);
            renderNotes();
        });

        head.append(enabled, title, remove);

        const area = document.createElement('textarea');
        area.value = note.text;
        area.spellcheck = false;
        area.addEventListener('input', () => { note.text = area.value; });
        area.addEventListener('focus', () => { lastFocusedNote = area; });

        const footer = document.createElement('div');
        footer.className = 'note-footer';

        const preview = document.createElement('button');
        preview.type = 'button';
        preview.className = 'button button-small';
        preview.textContent = 'Предпросмотр';
        preview.addEventListener('click', () => showPreview(note.text, preview));

        const reset = document.createElement('button');
        reset.type = 'button';
        reset.className = 'link';
        reset.textContent = 'Вернуть текст по умолчанию';
        reset.addEventListener('click', () => {
            note.text = state.settings.defaultNoteText;
            area.value = note.text;
        });

        footer.append(preview, reset);
        row.append(head, area, footer);
        list.appendChild(row);
    });

    if (!state.settings.releaseNotes.length) {
        const empty = document.createElement('p');
        empty.className = 'hint';
        empty.textContent = 'Ни одного текста. Без них будет использован встроенный.';
        list.appendChild(empty);
    }
}

function renderVariables() {
    ['variableList', 'readmeVariables'].forEach(renderVariablesInto);
}

function renderVariablesInto(boxId) {
    const box = document.getElementById(boxId);
    box.innerHTML = '';
    const groups = [
        [state.settings.noteVariables, '{{%s}}'],
        [state.settings.noteConditions, '{{#%s}}…{{/%s}}']
    ];
    groups.forEach(([source, pattern]) => {
        Object.entries(source || {}).forEach(([name, description]) => {
            const line = document.createElement('div');
            const token = pattern.includes('#')
                ? `{{#${name}}}…{{/${name}}}`
                : `{{${name}}}`;
            const code = document.createElement('code');
            code.textContent = token;
            code.title = 'Нажмите, чтобы вставить в текст';
            code.addEventListener('click', () => insertToken(token));
            line.append(code, document.createTextNode(` — ${description}`));
            box.appendChild(line);
        });
    });
}

function insertToken(token) {
    const area = (lastFocusedNote && lastFocusedNote.isConnected)
        ? lastFocusedNote
        : document.querySelector('#noteList textarea')
          || document.getElementById('readmeText');
    if (!area) return;
    const start = area.selectionStart ?? area.value.length;
    const end = area.selectionEnd ?? area.value.length;
    area.value = area.value.slice(0, start) + token + area.value.slice(end);
    area.dispatchEvent(new Event('input'));
    area.focus();
    area.selectionStart = area.selectionEnd = start + token.length;
}

async function showPreview(text, button) {
    const panel = document.getElementById('notePreview');
    const body = document.getElementById('previewBody');
    button.disabled = true;
    body.textContent = 'Собираю предпросмотр…';
    panel.classList.remove('hidden');
    try {
        const data = await api('/api/settings/preview-notes', {
            method: 'POST',
            body: JSON.stringify({text})
        });
        let result = data.body;
        if (data.sample) {
            result = '[данные условные: сборка ещё не запускалась]\n\n' + result;
        }
        if (data.unknown.length) {
            result += `\n\n[неизвестные подстановки: ${data.unknown.join(', ')}]`;
        }
        body.textContent = result;
    } catch (err) {
        body.textContent = err.message;
    }
    button.disabled = false;
    panel.scrollIntoView({block: 'nearest', behavior: 'smooth'});
}

document.getElementById('closePreview').addEventListener('click', () => {
    document.getElementById('notePreview').classList.add('hidden');
});

document.getElementById('addNote').addEventListener('click', () => {
    state.settings.releaseNotes.push({
        id: null,
        title: `Вариант ${state.settings.releaseNotes.length + 1}`,
        text: state.settings.defaultNoteText,
        enabled: true
    });
    renderNotes();
});

/* --- уведомления --- */

function renderTelegramEvents() {
    const grid = document.getElementById('telegramEvents');
    grid.innerHTML = '';
    Object.entries(state.settings.notifyEvents || {}).forEach(([key, title]) => {
        const label = document.createElement('label');
        label.className = 'check';

        const box = document.createElement('input');
        box.type = 'checkbox';
        box.checked = Boolean(state.settings.telegram.events[key]);
        box.addEventListener('change', () => {
            state.settings.telegram.events[key] = box.checked;
        });

        const text = document.createElement('span');
        text.textContent = title;

        label.append(box, text);
        grid.appendChild(label);
    });
}

document.getElementById('testTelegram').addEventListener('click', async () => {
    const button = document.getElementById('testTelegram');
    const hint = document.getElementById('telegramHint');
    button.disabled = true;
    hint.textContent = 'Отправляю сообщение…';
    hint.className = 'hint';
    try {
        await saveSettings({silent: true});
        const info = await api('/api/settings/test-telegram', {method: 'POST'});
        hint.textContent = `Бот @${info.bot} написал в «${info.chat}» — проверьте Telegram.`;
        hint.className = 'hint hint-ok';
    } catch (err) {
        hint.textContent = err.message;
        hint.className = 'hint hint-bad';
    }
    button.disabled = false;
});

/* --- смена пароля --- */

document.getElementById('changePassword').addEventListener('click', async () => {
    const button = document.getElementById('changePassword');
    const hint = document.getElementById('passwordHint');
    const oldValue = document.getElementById('oldPassword').value;
    const newValue = document.getElementById('newPassword').value;

    if (!oldValue || !newValue) {
        hint.textContent = 'Заполните оба поля.';
        hint.className = 'hint hint-bad';
        return;
    }
    if (newValue.length < 8) {
        hint.textContent = 'Новый пароль должен быть не короче 8 символов.';
        hint.className = 'hint hint-bad';
        return;
    }

    button.disabled = true;
    hint.textContent = 'Меняю пароль…';
    hint.className = 'hint';
    try {
        await api('/api/auth/password', {
            method: 'POST',
            body: JSON.stringify({old_password: oldValue, new_password: newValue})
        });
        document.getElementById('oldPassword').value = '';
        document.getElementById('newPassword').value = '';
        hint.textContent = 'Пароль изменён. Другие сессии завершены.';
        hint.className = 'hint hint-ok';
    } catch (err) {
        hint.textContent = err.message;
        hint.className = 'hint hint-bad';
    }
    button.disabled = false;
});

/* --- сохранение --- */

function settingsPayload() {
    return {
        sources: {
            geosite: document.getElementById('sourceGeosite').value.trim(),
            geoip: document.getElementById('sourceGeoip').value.trim()
        },
        auto_publish: document.getElementById('autoPublish').checked,
        readme: {
            enabled: document.getElementById('readmeEnabled').checked,
            text: document.getElementById('readmeText').value
        },
        release_notes: state.settings.releaseNotes.map(note => ({
            id: note.id,
            title: note.title,
            text: note.text,
            enabled: note.enabled
        })),
        telegram: {
            enabled: document.getElementById('telegramEnabled').checked,
            token: document.getElementById('telegramToken').value || null,
            chat_id: document.getElementById('telegramChat').value.trim(),
            events: state.settings.telegram.events
        },
        timezone: document.getElementById('timezone').value.trim() || 'Europe/Moscow',
        interval_minutes: parseInt(document.getElementById('intervalMinutes').value, 10) || 60,
        targets: state.settings.targets.map(t => ({
            id: t.id,
            provider: t.provider,
            repo: (t.repo || '').trim(),
            token: t.token || null,
            enabled: t.enabled
        }))
    };
}

function settingsMessage(ok, text) {
    const okBox = document.getElementById('settingsOk');
    const errBox = document.getElementById('settingsError');
    okBox.classList.toggle('hidden', ok !== true);
    errBox.classList.toggle('hidden', ok !== false);
    if (ok === true) okBox.textContent = text;
    if (ok === false) errBox.textContent = text;
}

async function saveSettings({silent = false} = {}) {
    const fresh = await api('/api/settings', {
        method: 'POST',
        body: JSON.stringify(settingsPayload())
    });
    // Переносим присвоенные сервером id, не подменяя объекты: на них уже
    // навешаны обработчики полей формы.
    fresh.targets.forEach((saved, index) => {
        const local = state.settings.targets[index];
        if (!local) return;
        local.id = saved.id;
        local.repo = saved.repo;
        local.hasToken = saved.hasToken;
        local.tokenMask = saved.tokenMask;
        local.token = '';
    });
    state.settings.sources = fresh.sources;
    state.settings.providers = fresh.providers;
    state.settings.defaultSources = fresh.defaultSources;
    state.settings.notifyEvents = fresh.notifyEvents;
    state.settings.readme = fresh.readme;
    state.settings.defaultReadmeText = fresh.defaultReadmeText;
    fresh.releaseNotes.forEach((saved, index) => {
        const local = state.settings.releaseNotes[index];
        if (local) local.id = saved.id;
    });
    state.settings.telegram.hasToken = fresh.telegram.hasToken;
    state.settings.telegram.tokenMask = fresh.telegram.tokenMask;
    state.settings.telegram.enabled = fresh.telegram.enabled;
    state.settings.telegram.chatId = fresh.telegram.chatId;
    if (!silent) renderTargets();
    return fresh;
}

document.getElementById('saveSettings').addEventListener('click', async () => {
    const button = document.getElementById('saveSettings');
    button.disabled = true;
    try {
        await saveSettings({silent: true});
        settingsMessage(null, '');
        closeSettings();
        loadStatus();
    } catch (err) {
        settingsMessage(false, err.message);
    }
    button.disabled = false;
});

/* ------------------------------------------------------------- состояние */

async function loadStatus() {
    let data;
    try {
        data = await api('/api/status');
    } catch (err) {
        return;
    }

    ['geosite', 'geoip'].forEach(kind => {
        const info = data.kinds[kind];
        const summary = document.getElementById(`${kind}Summary`);
        const updated = document.getElementById(`${kind}Updated`);
        if (info.totals) {
            summary.textContent =
                `${formatNumber(info.totals.categories)} категорий · ${formatNumber(info.totals.entries)} записей`;
        } else {
            summary.textContent = data.busy ? 'загружается…' : 'не загружен';
        }
        const parts = [];
        if (info.source && info.source.updated_at) {
            parts.push(`обновлён ${formatDate(info.source.updated_at)}`);
        }
        if (info.built) parts.push(`собран: ${formatBytes(info.built.size)}`);
        if (info.newCategories) parts.push(`новых категорий: ${info.newCategories}`);
        updated.textContent = parts.join(' · ');
        updated.title = parts.join(' · ');
        summary.title = summary.textContent;

        const link = document.getElementById(
            kind === 'geosite' ? 'downloadGeosite' : 'downloadGeoip');
        const ready = Boolean(info.built);
        link.classList.toggle('disabled', !ready);
        link.title = ready ? '' : 'Файл ещё не собран';
        if (ready) {
            link.href = `/api/download/${kind}`;
        } else {
            link.removeAttribute('href');
        }
    });

    const release = (data.releases || [])[0];
    const releaseEl = document.getElementById('lastRelease');
    const releaseMeta = document.getElementById('lastReleaseMeta');
    if (release) {
        const links = (release.targets || []).map(t =>
            `<a href="${escapeHtml(t.url)}" target="_blank" rel="noopener">${escapeHtml(t.title)}</a>`);
        releaseEl.innerHTML = escapeHtml(release.tag);
        releaseMeta.innerHTML = `${formatDate(release.at)}${links.length ? ' · ' + links.join(', ') : ''}`;
    } else {
        releaseEl.textContent = data.targetsReady ? 'ещё не создавался' : 'репозитории не настроены';
        releaseMeta.textContent = '';
    }

    const busy = Boolean(data.job && data.job.status === 'running');
    document.getElementById('buildButton').disabled = busy || !data.ready;
    document.getElementById('refreshButton').disabled = busy;
    if (data.job) {
        renderJob(data.job);
        if (busy) watchJob(data.job.id);
    }
}

/* ----------------------------------------------------------------- старт */

async function init() {
    try {
        await Promise.all([loadSelection('geosite'), loadSelection('geoip')]);
    } catch (err) {
        showError(err.message);
        return;
    }
    await loadStatus();
    await Promise.all([
        loadCatalogue(state.type),
        loadAnnotations(state.type),
        loadCustom(state.type)
    ]);
    await renderCategories();
    loadCustom(state.type === 'geosite' ? 'geoip' : 'geosite');
}

init();
