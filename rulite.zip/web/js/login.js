/* Экран входа и первичной регистрации администратора. Вынесен в отдельный
   файл: встроенные скрипты запрещены политикой безопасности (CSP). */

let mode = 'login';
const form = document.getElementById('authForm');
const subtitle = document.getElementById('authSubtitle');
const submit = document.getElementById('authSubmit');
const confirmField = document.getElementById('confirmField');
const hint = document.getElementById('authHint');
const errorBox = document.getElementById('authError');

function showError(text) {
    errorBox.textContent = text;
    errorBox.classList.remove('hidden');
}

function hideError() {
    errorBox.classList.add('hidden');
}

async function init() {
    try {
        const res = await fetch('/api/auth/state');
        const data = await res.json();
        if (data.authenticated) {
            location.href = '/';
            return;
        }
        mode = data.registered ? 'login' : 'register';
    } catch (err) {
        mode = 'login';
    }

    if (mode === 'register') {
        subtitle.textContent = 'Создайте учётную запись администратора';
        submit.textContent = 'Создать администратора';
        confirmField.classList.remove('hidden');
        document.getElementById('passwordConfirm').required = true;
        document.getElementById('password').autocomplete = 'new-password';
        hint.textContent = 'Пароль от 8 символов. Запомните его — восстановить пароль нельзя.';
    } else {
        subtitle.textContent = 'Вход в панель управления';
        submit.textContent = 'Войти';
    }
}

form.addEventListener('submit', async (e) => {
    e.preventDefault();
    hideError();

    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;

    if (mode === 'register' && password !== document.getElementById('passwordConfirm').value) {
        showError('Пароли не совпадают');
        return;
    }

    submit.disabled = true;
    try {
        const res = await fetch(`/api/auth/${mode}`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({username, password})
        });
        if (!res.ok) {
            const data = await res.json().catch(() => ({}));
            showError(data.detail || 'Не удалось выполнить вход');
            submit.disabled = false;
            return;
        }
        location.href = '/';
    } catch (err) {
        showError('Сервер недоступен');
        submit.disabled = false;
    }
});

init();
