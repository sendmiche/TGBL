#!/usr/bin/env bash
#
# Полная установка RULITE. По умолчанию — в Docker, с автозапуском
# после перезагрузки сервера. Данные хранятся отдельно от кода,
# поэтому повторный запуск скрипта обновляет проект, ничего не теряя.
#
#   sudo ./install.sh                  установка или обновление
#   sudo ./install.sh --host 0.0.0.0   слушать все интерфейсы, без вопросов
#   sudo ./install.sh --port 9000      другой порт
#   sudo ./install.sh --no-docker      без Docker, через systemd и venv
#   sudo ./install.sh --reset-admin    сбросить логин и пароль, настройки оставить
#   sudo ./install.sh --uninstall      убрать службу, данные оставить
#   sudo ./install.sh --purge          убрать вместе с данными
#
set -euo pipefail

HOST=""
PORT=12887
MODE=docker
ACTION=install

IMAGE=rulite:latest
CONTAINER=rulite
VOLUME=rulite-data
APP_DIR=/opt/rulite
DATA_DIR=/var/lib/rulite
SERVICE=rulite
RUN_USER=rulite
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

say()  { printf '\033[1;36m==>\033[0m %s\n' "$*"; }
ok()   { printf '\033[1;32m ✓\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m !\033[0m %s\n' "$*"; }
die()  { printf '\033[1;31m ✗\033[0m %s\n' "$*" >&2; exit 1; }

while [[ $# -gt 0 ]]; do
    case "$1" in
        --host) HOST="$2"; shift 2 ;;
        --reset-admin) ACTION=reset-admin; shift ;;
        --port) PORT="$2"; shift 2 ;;
        --no-docker) MODE=systemd; shift ;;
        --uninstall) ACTION=uninstall; shift ;;
        --purge) ACTION=purge; shift ;;
        -h|--help) sed -n '2,15p' "$0"; exit 0 ;;
        *) die "Неизвестный параметр: $1" ;;
    esac
done

[[ $EUID -eq 0 ]] || die "Запустите через sudo: sudo ./install.sh"
[[ -f "$SOURCE_DIR/main.py" ]] || die "main.py не найден рядом со скриптом"

# ==========================================================================
# Удаление
# ==========================================================================

if [[ "$ACTION" == reset-admin ]]; then
    removed=0
    if command -v docker >/dev/null && docker volume inspect "$VOLUME" >/dev/null 2>&1; then
        docker run --rm -v "$VOLUME:/data" alpine:3 \
            sh -c 'rm -f /data/admin.json' >/dev/null 2>&1 && removed=1
        docker restart "$CONTAINER" >/dev/null 2>&1 || true
    fi
    if [[ -f "$DATA_DIR/admin.json" ]]; then
        rm -f "$DATA_DIR/admin.json"
        systemctl restart "$SERVICE" >/dev/null 2>&1 || true
        removed=1
    fi
    if [[ $removed -eq 1 ]]; then
        ok "Учётная запись удалена. Откройте панель и создайте администратора заново."
        say "Источники, репозитории, тексты релиза и выбор категорий сохранены."
    else
        warn "Файл admin.json не найден — возможно, администратор ещё не создан."
    fi
    exit 0
fi

if [[ "$ACTION" != install ]]; then
    say "Останавливаю RULITE"
    if command -v docker >/dev/null && docker ps -a --format '{{.Names}}' | grep -qx "$CONTAINER"; then
        docker rm -f "$CONTAINER" >/dev/null 2>&1 || true
        ok "Контейнер удалён"
    fi
    if systemctl list-unit-files 2>/dev/null | grep -q "^${SERVICE}.service"; then
        systemctl disable --now "$SERVICE" >/dev/null 2>&1 || true
        rm -f "/etc/systemd/system/${SERVICE}.service"
        systemctl daemon-reload
        ok "Служба удалена"
    fi
    if [[ "$ACTION" == purge ]]; then
        docker volume rm "$VOLUME" >/dev/null 2>&1 || true
        rm -rf "$DATA_DIR"
        warn "Настройки и учётные данные удалены"
    else
        say "Настройки сохранены: том $VOLUME и каталог $DATA_DIR не тронуты"
    fi
    exit 0
fi

# ==========================================================================
# Установка в Docker
# ==========================================================================

install_docker() {
    if command -v docker >/dev/null && docker info >/dev/null 2>&1; then
        ok "Docker уже установлен"
        return
    fi

    if command -v docker >/dev/null; then
        say "Docker установлен, но не запущен — запускаю"
        systemctl enable --now docker || die "Не удалось запустить Docker"
        ok "Docker запущен"
        return
    fi

    say "Устанавливаю Docker (официальный скрипт get.docker.com)"
    if ! command -v curl >/dev/null; then
        if command -v apt-get >/dev/null; then
            apt-get update -qq && apt-get install -y -qq curl ca-certificates
        elif command -v dnf >/dev/null; then
            dnf install -y -q curl ca-certificates
        else
            die "Нет curl. Установите Docker вручную и запустите скрипт снова."
        fi
    fi

    curl -fsSL https://get.docker.com -o /tmp/get-docker.sh || die "Не удалось скачать установщик Docker"
    sh /tmp/get-docker.sh >/dev/null || die "Установка Docker не удалась"
    rm -f /tmp/get-docker.sh
    systemctl enable --now docker
    ok "Docker установлен"
}

run_docker() {
    install_docker

    say "Собираю образ $IMAGE"
    docker build -q -t "$IMAGE" "$SOURCE_DIR" >/dev/null || die "Не удалось собрать образ"
    ok "Образ готов"

    if ! docker volume inspect "$VOLUME" >/dev/null 2>&1; then
        docker volume create "$VOLUME" >/dev/null
        ok "Создан том $VOLUME для настроек и кэша"
    else
        ok "Том $VOLUME уже есть — настройки сохранятся"
    fi

    # Переносим настройки прошлой установки без Docker, если они остались.
    if [[ -f "$DATA_DIR/config.json" ]]; then
        if ! docker run --rm -v "$VOLUME:/data" "$IMAGE" \
             test -f /data/config.json 2>/dev/null; then
            say "Переношу настройки из $DATA_DIR в том Docker"
            docker run --rm -v "$VOLUME:/data" -v "$DATA_DIR:/old:ro" "$IMAGE" \
                sh -c 'cp -n /old/config.json /old/state.json /data/ 2>/dev/null || true' || true
            ok "Настройки перенесены"
        fi
    fi

    docker rm -f "$CONTAINER" >/dev/null 2>&1 || true

    say "Запускаю контейнер"
    docker run -d \
        --name "$CONTAINER" \
        --restart unless-stopped \
        -p "${HOST}:${PORT}:8080" \
        -v "$VOLUME:/data" \
        --memory 512m \
        --health-start-period 120s \
        "$IMAGE" >/dev/null || die "Не удалось запустить контейнер"

    sleep 4
    if [[ "$(docker inspect -f '{{.State.Running}}' "$CONTAINER" 2>/dev/null)" != "true" ]]; then
        docker logs --tail 30 "$CONTAINER" || true
        die "Контейнер не запустился"
    fi
    ok "Контейнер работает и будет подниматься после перезагрузки"

    echo
    echo "  Журнал:      docker logs -f $CONTAINER"
    echo "  Перезапуск:  docker restart $CONTAINER"
    echo "  Остановка:   docker stop $CONTAINER"
    echo "  Обновление:  sudo ./install.sh"
}

# ==========================================================================
# Установка без Docker (systemd + venv)
# ==========================================================================

run_systemd() {
    command -v python3 >/dev/null || die "Python 3 не установлен"
    local ok_version
    ok_version=$(python3 -c 'import sys; print(1 if sys.version_info >= (3,10) else 0)')
    [[ "$ok_version" == "1" ]] || die "Нужен Python 3.10 или новее (сейчас $(python3 -V))"

    if ! python3 -c 'import venv' 2>/dev/null; then
        say "Ставлю python3-venv"
        if command -v apt-get >/dev/null; then
            apt-get update -qq && apt-get install -y -qq python3-venv python3-pip
        elif command -v dnf >/dev/null; then
            dnf install -y -q python3-pip
        else
            die "Поставьте python3-venv вручную и запустите скрипт снова"
        fi
    fi

    id "$RUN_USER" >/dev/null 2>&1 || {
        say "Создаю системного пользователя $RUN_USER"
        useradd --system --no-create-home --shell /usr/sbin/nologin "$RUN_USER"
    }

    say "Копирую проект в $APP_DIR"
    mkdir -p "$APP_DIR" "$DATA_DIR"
    for item in main.py requirements.txt core proto web; do
        [[ -e "$SOURCE_DIR/$item" ]] || die "Не хватает $item в каталоге проекта"
        rm -rf "${APP_DIR:?}/$item"
        cp -r "$SOURCE_DIR/$item" "$APP_DIR/"
    done

    if [[ ! -x "$APP_DIR/.venv/bin/python" ]]; then
        say "Создаю виртуальное окружение"
        python3 -m venv "$APP_DIR/.venv"
    fi

    say "Устанавливаю зависимости"
    "$APP_DIR/.venv/bin/pip" install --quiet --upgrade pip
    "$APP_DIR/.venv/bin/pip" install --quiet -r "$APP_DIR/requirements.txt"

    chown -R "$RUN_USER:$RUN_USER" "$APP_DIR" "$DATA_DIR"
    chmod 700 "$DATA_DIR"

    say "Настраиваю автозапуск"
    cat > "/etc/systemd/system/${SERVICE}.service" <<UNIT
[Unit]
Description=RULITE - сборка и публикация гео-файлов маршрутизации
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=${RUN_USER}
Group=${RUN_USER}
WorkingDirectory=${APP_DIR}
Environment=RULITE_HOST=${HOST}
Environment=RULITE_PORT=${PORT}
Environment=RULITE_DATA=${DATA_DIR}
Environment=PYTHONUNBUFFERED=1
ExecStart=${APP_DIR}/.venv/bin/python ${APP_DIR}/main.py
Restart=always
RestartSec=10

# Файлы читаются через mmap, процессу хватает примерно 150 МБ.
MemoryMax=400M
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=${DATA_DIR}

[Install]
WantedBy=multi-user.target
UNIT

    systemctl daemon-reload
    systemctl enable "$SERVICE" >/dev/null
    systemctl restart "$SERVICE"

    sleep 3
    systemctl is-active --quiet "$SERVICE" || {
        journalctl -u "$SERVICE" -n 20 --no-pager || true
        die "Служба не запустилась"
    }
    ok "Служба работает и будет подниматься после перезагрузки"

    echo
    echo "  Журнал:      journalctl -u $SERVICE -f"
    echo "  Перезапуск:  systemctl restart $SERVICE"
    echo "  Настройки:   $DATA_DIR"
}

# ==========================================================================

choose_host() {
    if [[ -n "$HOST" ]]; then
        return
    fi
    if [[ ! -t 0 ]]; then
        HOST=127.0.0.1
        return
    fi

    echo
    echo "  На каком адресе слушать панель?"
    echo
    echo "    1) 127.0.0.1:${PORT}  — только с этой машины (по умолчанию)"
    echo "       Подходит, если Caddy или nginx стоят здесь же."
    echo
    echo "    2) 0.0.0.0:${PORT}    — со всех интерфейсов"
    echo "       Нужно, если прокси работает на другой машине или на хосте,"
    echo "       а RULITE — в контейнере Proxmox или в отдельной виртуалке."
    echo
    read -r -p "  Выбор [1]: " answer
    case "${answer:-1}" in
        2) HOST=0.0.0.0 ;;
        *) HOST=127.0.0.1 ;;
    esac
    echo
}

choose_host

echo
say "Установка RULITE (${MODE})"

if [[ "$MODE" == docker ]]; then
    run_docker
else
    run_systemd
fi

echo
ok "Готово. Панель: http://${HOST}:${PORT}"
if [[ "$HOST" == "127.0.0.1" ]]; then
    warn "Панель слушает только localhost — снаружи она недоступна."
    warn "Если прокси на другой машине, переустановите с --host 0.0.0.0"
else
    warn "Панель слушает все интерфейсы. Обязательно закройте порт ${PORT}"
    warn "в брандмауэре и пускайте трафик только через HTTPS-прокси."
fi
say "Откройте панель и создайте администратора при первом входе"
echo
