"""RULITE — фильтрация и публикация гео-файлов маршрутизации.

Запуск:  python main.py
"""

from __future__ import annotations

import argparse
import asyncio
import contextlib
import logging
import os
from typing import Any, Literal

import uvicorn
from fastapi import Depends, FastAPI, HTTPException, Query, Request, Response
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from core import auth, custom, geodata, notes, notify, publish
from core.config import (
    DEFAULT_SOURCES,
    KINDS,
    NOTIFY_EVENTS,
    WEB_DIR,
    mask_secret,
    parse_repo,
    new_target,
    store,
)
from core.worker import LOG_BUFFER, bootstrap, pipeline

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-7s %(name)s  %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("rulite")


@contextlib.asynccontextmanager
async def lifespan(app: FastAPI):
    await bootstrap()
    try:
        yield
    finally:
        pipeline.shutdown()


app = FastAPI(title="RULITE", docs_url=None, redoc_url=None, lifespan=lifespan)
SAFE_METHODS = {"GET", "HEAD", "OPTIONS"}

SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "Cross-Origin-Opener-Policy": "same-origin",
    "Content-Security-Policy": (
        "default-src 'self'; img-src 'self' data:; style-src 'self'; "
        "script-src 'self'; connect-src 'self'; frame-ancestors 'none'; "
        "base-uri 'none'; form-action 'self'"
    ),
}


@app.middleware("http")
async def guard(request: Request, call_next):
    """Заголовки безопасности и защита от межсайтовых запросов."""
    if request.method not in SAFE_METHODS:
        origin = request.headers.get("origin")
        if origin:
            host = request.headers.get("host", "")
            allowed = {f"http://{host}", f"https://{host}"}
            if origin not in allowed:
                return JSONResponse(
                    {"detail": "Запрос с постороннего сайта отклонён"}, status_code=403
                )

    response = await call_next(request)
    for header, value in SECURITY_HEADERS.items():
        response.headers.setdefault(header, value)
    if request.url.path.startswith("/api/"):
        response.headers.setdefault("Cache-Control", "no-store")
    return response


app.mount("/static/css", StaticFiles(directory=WEB_DIR / "css"), name="css")
app.mount("/static/js", StaticFiles(directory=WEB_DIR / "js"), name="js")


# --------------------------------------------------------------------------
# Авторизация
# --------------------------------------------------------------------------

def require_auth(request: Request) -> str:
    user = auth.read_session(request)
    if not user:
        raise HTTPException(status_code=401, detail="Требуется вход")
    return user


class Credentials(BaseModel):
    username: str = Field(min_length=3, max_length=64)
    password: str = Field(min_length=8, max_length=256)


def _client_ip(request: Request) -> str:
    return request.client.host if request.client else "unknown"


def _set_cookie(response: Response, token: str) -> None:
    response.set_cookie(
        auth.COOKIE_NAME,
        token,
        max_age=auth.SESSION_MAX_AGE,
        httponly=True,
        samesite="lax",
        path="/",
        secure=os.getenv("RULITE_HTTPS", "").lower() in ("1", "true", "yes"),
    )


@app.get("/", include_in_schema=False)
async def index(request: Request):
    if not store.has_admin or not auth.is_authenticated(request):
        return RedirectResponse("/login", status_code=302)
    return FileResponse(WEB_DIR / "index.html")


@app.get("/login", include_in_schema=False)
async def login_page(request: Request):
    if store.has_admin and auth.is_authenticated(request):
        return RedirectResponse("/", status_code=302)
    return FileResponse(WEB_DIR / "login.html")


@app.get("/api/auth/state")
async def auth_state(request: Request):
    return {
        "registered": store.has_admin,
        "authenticated": auth.is_authenticated(request),
    }


@app.post("/api/auth/register")
async def register(payload: Credentials, response: Response):
    if store.has_admin:
        raise HTTPException(status_code=409, detail="Администратор уже создан")
    auth.register_admin(payload.username, payload.password)
    _set_cookie(response, auth.issue_session(payload.username))
    return {"ok": True}


@app.post("/api/auth/login")
async def login(payload: Credentials, request: Request, response: Response):
    ip = _client_ip(request)
    wait = auth.lockout_remaining(ip)
    if wait:
        raise HTTPException(
            status_code=429,
            detail=f"Слишком много попыток. Повторите через {wait // 60 + 1} мин.",
        )
    if not auth.check_credentials(payload.username, payload.password):
        auth.register_failure(ip)
        raise HTTPException(status_code=401, detail="Неверный логин или пароль")
    auth.clear_failures(ip)
    _set_cookie(response, auth.issue_session(payload.username))
    return {"ok": True}


class PasswordChange(BaseModel):
    old_password: str = Field(min_length=1, max_length=256)
    new_password: str = Field(min_length=8, max_length=256)


@app.post("/api/auth/password")
async def change_password(
    payload: PasswordChange, response: Response, user: str = Depends(require_auth)
):
    if payload.old_password == payload.new_password:
        raise HTTPException(status_code=400, detail="Новый пароль совпадает со старым")
    if not auth.change_password(payload.old_password, payload.new_password):
        raise HTTPException(status_code=401, detail="Текущий пароль указан неверно")
    # Секрет сессий сменился — выдаём новую cookie этому браузеру.
    _set_cookie(response, auth.issue_session(user))
    return {"ok": True}


@app.post("/api/auth/logout")
async def logout(response: Response):
    response.delete_cookie(auth.COOKIE_NAME, path="/")
    return {"ok": True}


# --------------------------------------------------------------------------
# Состояние
# --------------------------------------------------------------------------

def _build_files() -> dict[str, dict[str, Any]]:
    last = store.state.get("last_build") or {}
    return {item["kind"]: item for item in (last.get("files") or [])}


@app.get("/api/status")
async def status(_: str = Depends(require_auth)):
    job = pipeline.current or pipeline.last
    built = _build_files()
    return {
        "ready": geodata.geo.ready,
        "busy": pipeline.busy,
        "kinds": {
            kind: {
                "loaded": geodata.geo.loaded(kind),
                "totals": geodata.geo.totals(kind) if geodata.geo.loaded(kind) else None,
                "source": store.state["sources"].get(kind) or {},
                "url": store.source_url(kind),
                "newCategories": len(store.state["new_categories"].get(kind) or []),
                "built": built.get(kind),
            }
            for kind in KINDS
        },
        "lastBuild": store.state.get("last_build"),
        "releases": (store.state.get("releases") or [])[:5],
        "job": job.to_dict() if job else None,
        "targetsReady": len(store.targets(only_ready=True)),
    }


def _check_kind(kind: str) -> str:
    if kind not in KINDS:
        raise HTTPException(status_code=400, detail="Неизвестный тип файла")
    if not geodata.geo.loaded(kind):
        raise HTTPException(
            status_code=503,
            detail=f"Файл {kind}.dat ещё не загружен — дождитесь окончания загрузки",
        )
    return kind


@app.get("/api/categories")
async def categories(
    type: str = Query("geosite"),
    page: int = Query(1, ge=1),
    limit: int = Query(10, ge=1, le=500),
    q: str = Query(""),
    _: str = Depends(require_auth),
):
    kind = _check_kind(type)
    codes = await asyncio.to_thread(geodata.geo.categories, kind, q.strip())
    total = len(codes)
    start = (page - 1) * limit
    window = codes[start : start + limit]

    selection = store.selection(kind)
    disabled = set(selection["disabled_categories"])
    excluded = selection["excluded"]
    new_marks = set(store.state["new_categories"].get(kind) or [])

    items = []
    for code in window:
        count = geodata.geo.count(kind, code)
        excluded_count = len(excluded.get(code, ()))
        if code in disabled or (count and excluded_count >= count):
            cat_state = "none"
        elif excluded_count:
            cat_state = "partial"
        else:
            cat_state = "all"
        items.append(
            {
                "code": code,
                "count": count,
                "excludedCount": excluded_count,
                "state": cat_state,
                "isNew": code in new_marks,
            }
        )

    return {
        "items": items,
        "total": total,
        "page": page,
        "limit": limit,
        "totals": geodata.geo.totals(kind),
    }


@app.get("/api/categories/{code}/entries")
async def category_entries(
    code: str,
    type: str = Query("geosite"),
    offset: int = Query(0, ge=0),
    limit: int = Query(200, ge=1, le=1000),
    q: str = Query(""),
    _: str = Depends(require_auth),
):
    kind = _check_kind(type)
    if not geodata.geo.has_category(kind, code):
        raise HTTPException(status_code=404, detail="Категория не найдена")
    items, total = await asyncio.to_thread(
        geodata.geo.entries, kind, code, q.strip(), offset, limit
    )
    return {"items": items, "total": total, "offset": offset, "limit": limit}


# --------------------------------------------------------------------------
# Выбор категорий и оценка размера
# --------------------------------------------------------------------------

class SelectionPayload(BaseModel):
    type: str
    disabled_categories: list[str] = []
    excluded: dict[str, list[str]] = {}


@app.get("/api/selection")
async def get_selection(type: str = Query("geosite"), _: str = Depends(require_auth)):
    if type not in KINDS:
        raise HTTPException(status_code=400, detail="Неизвестный тип файла")
    selection = store.selection(type)
    return {
        "type": type,
        "disabled_categories": selection["disabled_categories"],
        "excluded": selection["excluded"],
        "newCategories": store.state["new_categories"].get(type) or [],
    }


def _apply_selection(payload: SelectionPayload) -> None:
    if payload.type not in KINDS:
        raise HTTPException(status_code=400, detail="Неизвестный тип файла")
    selection = store.selection(payload.type)
    selection["disabled_categories"] = sorted(set(payload.disabled_categories))
    selection["excluded"] = {
        code: sorted(set(keys)) for code, keys in payload.excluded.items() if keys
    }
    store.save_config()
    marked = set(store.state["new_categories"].get(payload.type) or [])
    geodata.clear_new_marks(
        payload.type, marked - set(selection["disabled_categories"])
    )


@app.post("/api/selection")
async def save_selection(payload: SelectionPayload, _: str = Depends(require_auth)):
    _apply_selection(payload)
    return {"ok": True}


@app.post("/api/estimate")
async def estimate(payload: SelectionPayload, _: str = Depends(require_auth)):
    """Точный размер будущего файла для переданного (ещё не сохранённого) выбора."""
    kind = _check_kind(payload.type)
    result = await asyncio.to_thread(
        geodata.geo.estimate,
        kind,
        {
            "disabled_categories": payload.disabled_categories,
            "excluded": payload.excluded,
        },
    )
    totals = geodata.geo.totals(kind)
    custom_entries = result.get("customEntries", 0)
    custom_categories = result.get("customCategories", 0)
    from_source = result["entries"] - custom_entries
    return {
        "type": kind,
        "bytes": result["bytes"],
        "sourceBytes": totals.get("sourceBytes", 0),
        "selectedEntries": result["entries"],
        "selectedCategories": result["categories"],
        "customEntries": custom_entries,
        "customCategories": custom_categories,
        "sourceEntries": from_source,
        "sourceCategories": result["categories"] - custom_categories,
        "totalEntries": totals["entries"],
        "totalCategories": totals["categories"],
        "removedEntries": totals["entries"] - from_source,
    }


# --------------------------------------------------------------------------
# Свои категории
# --------------------------------------------------------------------------

class CustomItem(BaseModel):
    id: str | None = None
    code: str = ""
    enabled: bool = True
    sources: list[str] = []
    entries: str = ""
    replace_sources: bool = False


class CustomPayload(BaseModel):
    type: str
    items: list[CustomItem] = []


def _custom_view(kind: str) -> list[dict[str, Any]]:
    result = []
    for item in store.custom(kind):
        stats = {"entries": 0, "bytes": 0, "manual": 0}
        try:
            stats = geodata.geo.custom_stats(kind, item)
        except Exception:  # noqa: BLE001
            pass
        result.append({**item, "stats": stats})
    return result


@app.get("/api/custom")
async def get_custom(type: str = Query("geosite"), _: str = Depends(require_auth)):
    kind = _check_kind(type)
    return {
        "type": kind,
        "items": _custom_view(kind),
        "help": custom.HELP_GEOSITE if kind == "geosite" else custom.HELP_GEOIP,
    }


@app.post("/api/custom")
async def save_custom(payload: CustomPayload, _: str = Depends(require_auth)):
    kind = _check_kind(payload.type)
    known = set(geodata.geo.all_codes(kind))
    try:
        items = custom.validate(
            kind, [item.model_dump() for item in payload.items], known
        )
    except custom.CustomError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    store.config.setdefault("custom", {})[kind] = items
    store.save_config()
    return {"type": kind, "items": _custom_view(kind)}


@app.get("/api/catalogue")
async def catalogue(type: str = Query("geosite"), _: str = Depends(require_auth)):
    """Весь список категорий с числом записей — для панели состава и подсказок."""
    kind = _check_kind(type)
    new_marks = set(store.state["new_categories"].get(kind) or [])

    def collect() -> list[dict[str, Any]]:
        return [
            {
                "code": code,
                "count": geodata.geo.count(kind, code),
                "isNew": code in new_marks,
            }
            for code in geodata.geo.order(kind)
        ]

    items = await asyncio.to_thread(collect)
    return {"type": kind, "items": items, "totals": geodata.geo.totals(kind)}


@app.get("/api/locate")
async def locate(
    type: str = Query("geosite"),
    key: str = Query(..., min_length=1, max_length=512),
    _: str = Depends(require_auth),
):
    """В каких категориях встречается конкретная запись."""
    kind = _check_kind(type)
    codes = await asyncio.to_thread(geodata.geo.locate, kind, key)
    return {"type": kind, "key": key, "categories": codes}


# --------------------------------------------------------------------------
# Заметки и цветовые метки
# --------------------------------------------------------------------------

COLORS = {"", "red", "amber", "green", "blue", "violet"}


class Annotation(BaseModel):
    type: str
    scope: Literal["category", "record"]
    key: str
    note: str = ""
    color: str = ""


@app.get("/api/annotations")
async def get_annotations(type: str = Query("geosite"), _: str = Depends(require_auth)):
    if type not in KINDS:
        raise HTTPException(status_code=400, detail="Неизвестный тип файла")
    block = store.annotations(type)
    return {"type": type, "categories": block["categories"], "records": block["records"]}


@app.post("/api/annotations")
async def set_annotation(payload: Annotation, _: str = Depends(require_auth)):
    if payload.type not in KINDS:
        raise HTTPException(status_code=400, detail="Неизвестный тип файла")
    if payload.color not in COLORS:
        raise HTTPException(status_code=400, detail="Неизвестный цвет метки")

    block = store.annotations(payload.type)
    bucket = block["categories" if payload.scope == "category" else "records"]
    note = payload.note.strip()[:2000]

    if not note and not payload.color:
        bucket.pop(payload.key, None)
    else:
        bucket[payload.key] = {"note": note, "color": payload.color}

    store.save_annotations()
    return {"ok": True, "entry": bucket.get(payload.key)}


# --------------------------------------------------------------------------
# Настройки
# --------------------------------------------------------------------------

class TargetPayload(BaseModel):
    id: str | None = None
    provider: Literal["github", "gitverse"] = "github"
    repo: str = ""
    token: str | None = None
    enabled: bool = True


class TelegramPayload(BaseModel):
    enabled: bool = False
    token: str | None = None
    chat_id: str = ""
    events: dict[str, bool] = {}


class NotePayload(BaseModel):
    id: str | None = None
    title: str = "Текст релиза"
    text: str = ""
    enabled: bool = True


class ReadmePayload(BaseModel):
    enabled: bool = True
    text: str = ""


class SettingsPayload(BaseModel):
    readme: ReadmePayload | None = None
    release_notes: list[NotePayload] | None = None
    telegram: TelegramPayload | None = None
    sources: dict[str, str] = {}
    auto_publish: bool = True
    timezone: str = "Europe/Moscow"
    interval_minutes: int = Field(60, ge=5, le=1440)
    targets: list[TargetPayload] = []


def _settings_dict() -> dict[str, Any]:
    changed = False
    if not store.release_notes():
        store.config["release_notes"] = notes.default_notes()
        changed = True
    if not store.readme().get("text"):
        store.readme()["text"] = notes.DEFAULT_README
        changed = True
    if changed:
        store.save_config()
    telegram = store.telegram()
    return {
        "telegram": {
            "enabled": bool(telegram.get("enabled")),
            "chatId": telegram.get("chat_id", ""),
            "hasToken": bool(telegram.get("token")),
            "tokenMask": mask_secret(telegram.get("token", "")),
            "events": telegram.get("events", {}),
        },
        "notifyEvents": NOTIFY_EVENTS,
        "sources": {kind: store.source_url(kind) for kind in KINDS},
        "defaultSources": DEFAULT_SOURCES,
        "autoPublish": (store.config.get("publish") or {}).get("auto", True),
        "timezone": (store.config.get("publish") or {}).get("timezone", "Europe/Moscow"),
        "intervalMinutes": store.config["schedule"].get("interval_minutes", 60),
        "providers": [
            {"id": key, "title": value["title"]}
            for key, value in publish.PROVIDERS.items()
        ],
        "releaseNotes": [
            {
                "id": note["id"],
                "title": note.get("title", ""),
                "text": note.get("text", ""),
                "enabled": bool(note.get("enabled", True)),
            }
            for note in store.release_notes()
        ],
        "readme": {
            "enabled": bool(store.readme().get("enabled", True)),
            "text": store.readme().get("text", ""),
        },
        "defaultReadmeText": notes.DEFAULT_README,
        "noteVariables": notes.VARIABLES,
        "noteConditions": notes.CONDITIONS,
        "defaultNoteText": notes.DEFAULT_TEXT,
        "targets": [
            {
                "id": t["id"],
                "provider": t.get("provider", "github"),
                "repo": t.get("repo", ""),
                "enabled": bool(t.get("enabled", True)),
                "hasToken": bool(t.get("token")),
                "tokenMask": mask_secret(t.get("token", "")),
            }
            for t in store.targets()
        ],
    }


def _apply_settings(payload: SettingsPayload) -> dict[str, Any]:
    sources = store.config.setdefault("sources", {})
    for kind, url in (payload.sources or {}).items():
        if kind not in KINDS:
            continue
        url = (url or "").strip()
        if url and not url.startswith(("http://", "https://")):
            raise HTTPException(
                status_code=400, detail=f"Адрес {kind} должен начинаться с http(s)://"
            )
        sources[kind] = url or DEFAULT_SOURCES[kind]

    if payload.readme is not None:
        block = store.readme()
        block["enabled"] = payload.readme.enabled
        block["text"] = payload.readme.text

    if payload.release_notes is not None:
        collected = []
        for item in payload.release_notes:
            note = notes.new_note(item.title.strip() or "Текст релиза", item.text)
            if item.id:
                note["id"] = item.id
            note["enabled"] = item.enabled
            note["text"] = item.text
            collected.append(note)
        store.config["release_notes"] = collected

    existing = {t["id"]: t for t in store.targets()}
    updated: list[dict[str, Any]] = []
    for item in payload.targets:
        current = existing.get(item.id or "") or new_target(item.provider)
        # Из ссылки видно и площадку, и репозиторий — пользователю достаточно
        # вставить адрес из адресной строки браузера.
        detected, repo = publish.parse_repo(item.repo)
        current["provider"] = detected or item.provider
        current["repo"] = repo
        current["enabled"] = item.enabled
        if item.token:  # пустое поле = оставить прежний токен
            current["token"] = item.token.strip()
        if current["repo"] and current["repo"].count("/") != 1:
            raise HTTPException(
                status_code=400, detail="Репозиторий указывается как user/repo"
            )
        updated.append(current)
    store.config["targets"] = updated

    if payload.telegram is not None:
        telegram = store.telegram()
        telegram["enabled"] = payload.telegram.enabled
        telegram["chat_id"] = payload.telegram.chat_id.strip()
        if payload.telegram.token:  # пустое поле = оставить прежний токен
            telegram["token"] = payload.telegram.token.strip()
        for key in NOTIFY_EVENTS:
            if key in payload.telegram.events:
                telegram["events"][key] = bool(payload.telegram.events[key])

    store.config.setdefault("publish", {})["auto"] = payload.auto_publish
    store.config["publish"]["timezone"] = payload.timezone.strip() or "Europe/Moscow"
    store.config["schedule"]["interval_minutes"] = payload.interval_minutes
    store.save_config()
    pipeline.reschedule()
    return _settings_dict()


@app.get("/api/settings")
async def get_settings(_: str = Depends(require_auth)):
    return _settings_dict()


@app.post("/api/settings")
async def post_settings(payload: SettingsPayload, _: str = Depends(require_auth)):
    return _apply_settings(payload)


class NotePreview(BaseModel):
    text: str


@app.post("/api/settings/preview-notes")
async def preview_notes(payload: NotePreview, _: str = Depends(require_auth)):
    """Показывает, как текст будет выглядеть в релизе, с реальными данными."""
    last = store.state.get("last_build") or {}
    files = last.get("files") or []
    if not files:
        files = [
            {"kind": "geosite", "size": 3_670_016, "entries": 48210,
             "categories": 96, "sha256": "—", "codes": ["github", "telegram", "youtube"]},
            {"kind": "geoip", "size": 1_572_864, "entries": 12840,
             "categories": 14, "sha256": "—", "codes": ["ru", "telegram"]},
        ]

    targets = store.targets(only_ready=True) or [
        {"provider": "github", "repo": "user/repo", "token": "-", "enabled": True}
    ]
    target = targets[0]
    tag = pipeline.release_tag()
    urls, latest = publish.asset_links(target, tag)
    context = notes.build_context(
        tag, files, urls,
        repo=target["repo"],
        service=publish.provider_title(target["provider"]),
        release_url=f"{publish.PROVIDERS[target['provider']]['web']}"
                    f"/{target['repo']}/releases/tag/{tag}",
        latest_links=latest,
        source_url=notes.source_page(store.source_url("geosite")),
    )
    body, unknown = notes.render(payload.text or notes.DEFAULT_TEXT, context)
    return {"body": body, "unknown": unknown, "sample": not (last.get("files") or [])}


class TargetTest(BaseModel):
    id: str


@app.post("/api/settings/test-target")
async def test_target(payload: TargetTest, _: str = Depends(require_auth)):
    target = next((t for t in store.targets() if t["id"] == payload.id), None)
    if not target:
        raise HTTPException(status_code=404, detail="Репозиторий не найден в настройках")
    try:
        info = await publish.check_target(target)
    except publish.PublishError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=400, detail=f"Сервис недоступен: {exc}") from exc
    return {"ok": True, **info}


@app.post("/api/settings/test-telegram")
async def test_telegram(_: str = Depends(require_auth)):
    telegram = store.telegram()
    try:
        info = await notify.send_test(
            telegram.get("token", ""), str(telegram.get("chat_id", ""))
        )
    except notify.NotifyError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(
            status_code=400, detail=f"Telegram недоступен: {exc}"
        ) from exc
    return {"ok": True, **info}


class SourceTest(BaseModel):
    url: str


@app.post("/api/settings/test-source")
async def test_source(payload: SourceTest, _: str = Depends(require_auth)):
    url = payload.url.strip()
    if not url.startswith(("http://", "https://")):
        raise HTTPException(status_code=400, detail="Адрес должен начинаться с http(s)://")
    try:
        async with geodata.make_client() as client:
            meta = await geodata.probe_source(url, client)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=400, detail=f"Недоступен: {exc}") from exc
    return {"ok": True, "size": meta.get("size", 0)}


# --------------------------------------------------------------------------
# Запуск задач
# --------------------------------------------------------------------------

class BuildPayload(BaseModel):
    selections: list[SelectionPayload] = []
    settings: SettingsPayload | None = None
    publish: bool = True


@app.post("/api/build")
async def build(payload: BuildPayload, _: str = Depends(require_auth)):
    if not geodata.geo.ready:
        raise HTTPException(
            status_code=503,
            detail="Не все исходные файлы загружены: " + ", ".join(geodata.geo.missing()),
        )
    if pipeline.busy:
        raise HTTPException(status_code=409, detail="Задача уже выполняется")
    if payload.settings:
        _apply_settings(payload.settings)
    for selection in payload.selections:
        _apply_selection(selection)
    job = pipeline.start("Сборка по запросу", build=True, publish_release=payload.publish)
    return {"jobId": job.id}


@app.post("/api/refresh")
async def refresh(_: str = Depends(require_auth)):
    """Только проверка обновлений: качает, если источник реально изменился."""
    if pipeline.busy:
        raise HTTPException(status_code=409, detail="Задача уже выполняется")
    job = pipeline.start("Проверка обновлений", build=False, publish_release=False)
    return {"jobId": job.id}


@app.get("/api/jobs/{job_id}")
async def job_status(job_id: str, _: str = Depends(require_auth)):
    job = pipeline.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Задача не найдена")
    return job.to_dict()


@app.get("/api/logs")
async def logs(_: str = Depends(require_auth)):
    return {"lines": list(LOG_BUFFER)[-100:]}


@app.get("/api/download/{kind}")
async def download(kind: str, _: str = Depends(require_auth)):
    if kind not in KINDS:
        raise HTTPException(status_code=400, detail="Неизвестный тип файла")
    path = geodata.build_path(kind)
    if not path.exists():
        raise HTTPException(
            status_code=404,
            detail="Файл ещё не собран — нажмите «Сохранить настройки и собрать»",
        )
    return FileResponse(
        path, filename=f"{kind}.dat", media_type="application/octet-stream"
    )


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    return JSONResponse({"detail": exc.detail}, status_code=exc.status_code)


def parse_args() -> Any:
    parser = argparse.ArgumentParser(description="RULITE")
    parser.add_argument("--host", default=os.getenv("RULITE_HOST", "127.0.0.1"))
    parser.add_argument("--port", type=int, default=int(os.getenv("RULITE_PORT", 8080)))
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    print(f"\n  ❤️ RULITE  →  http://{args.host}:{args.port}\n")
    uvicorn.run(app, host=args.host, port=args.port, log_level="warning")
