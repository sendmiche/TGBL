"""Свои категории: объединение существующих и собственные списки записей.

Пользователь описывает записи в том же виде, в каком они показываются в панели:
`full:example.com`, `domain:vk.com`, `regex:^ads\\.`, `1.2.3.0/24`. Здесь эти
строки разбираются и превращаются в записи protobuf, которые попадают в
собираемый файл наравне с исходными.
"""

from __future__ import annotations

import ipaddress
import re
import uuid
from typing import Any

from . import dat

CODE_RE = re.compile(r"^[a-z0-9][a-z0-9._!-]{0,62}$")

# Как пользователь может назвать тип домена. Ключ слева — то, что он пишет.
DOMAIN_ALIASES = {
    "plain": 0,
    "keyword": 0,
    "regex": 1,
    "regexp": 1,
    "domain": 2,
    "root": 2,
    "rootdomain": 2,
    "full": 3,
    "exact": 3,
}

HELP_GEOSITE = (
    "По одной записи в строке:\n"
    "  example.com          — домен и все поддомены\n"
    "  domain:example.com   — то же самое, явно\n"
    "  full:example.com     — только сам домен\n"
    "  regex:^ads\\..*       — регулярное выражение\n"
    "  plain:tracker        — вхождение подстроки\n"
    "Строки, начинающиеся с #, пропускаются."
)

HELP_GEOIP = (
    "По одной записи в строке:\n"
    "  1.2.3.0/24           — подсеть\n"
    "  8.8.8.8              — отдельный адрес\n"
    "  2001:db8::/32        — IPv6\n"
    "Строки, начинающиеся с #, пропускаются."
)


class CustomError(ValueError):
    pass


def new_custom(kind: str) -> dict[str, Any]:
    return {
        "id": uuid.uuid4().hex[:8],
        "code": "",
        "enabled": True,
        "sources": [],
        "entries": "",
        "replace_sources": False,
    }


def normalize_code(code: str) -> str:
    text = (code or "").strip().lower().replace(" ", "-")
    if not text:
        raise CustomError("Укажите название категории")
    if not CODE_RE.match(text):
        raise CustomError(
            "В названии допустимы латиница, цифры, точка, дефис и подчёркивание"
        )
    return text


# --------------------------------------------------------------------------
# Разбор строк
# --------------------------------------------------------------------------

def parse_line(kind: str, line: str) -> tuple[str, bytes]:
    """Возвращает ключ записи и её содержимое в формате protobuf."""
    text = line.strip()
    if kind == "geosite":
        return _parse_domain(text)
    return _parse_cidr(text)


def _parse_domain(text: str) -> tuple[str, bytes]:
    kind_name, _, rest = text.partition(":")
    if rest and kind_name.lower() in DOMAIN_ALIASES:
        type_index = DOMAIN_ALIASES[kind_name.lower()]
        value = rest.strip()
    else:
        # Без префикса считаем, что это домен со всеми поддоменами —
        # так же, как это понимают Xray и v2ray.
        type_index = 2
        value = text

    if not value:
        raise CustomError("Пустое значение")
    if " " in value:
        raise CustomError(f"Пробел в значении: {value!r}")

    if type_index == 1:
        try:
            re.compile(value)
        except re.error as exc:
            raise CustomError(f"Ошибка в регулярном выражении {value!r}: {exc}") from exc
    elif type_index in (2, 3) and "." not in value:
        raise CustomError(f"Не похоже на домен: {value!r}")

    raw = value.encode("utf-8")
    key = f"{dat.TYPE_KEYS[type_index]}:{value}"
    return key, dat.encode_domain(type_index, raw)


def _parse_cidr(text: str) -> tuple[str, bytes]:
    try:
        network = ipaddress.ip_network(text, strict=False)
    except ValueError as exc:
        raise CustomError(f"Не похоже на адрес или подсеть: {text!r}") from exc
    packed = network.network_address.packed
    return f"{network}", dat.encode_cidr(packed, network.prefixlen)


def parse_entries(kind: str, text: str) -> tuple[list[tuple[str, bytes]], list[str]]:
    """Разбирает многострочный текст. Возвращает записи и список ошибок."""
    records: list[tuple[str, bytes]] = []
    errors: list[str] = []
    seen: set[str] = set()

    for number, line in enumerate((text or "").splitlines(), 1):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        try:
            key, payload = parse_line(kind, stripped)
        except CustomError as exc:
            errors.append(f"строка {number}: {exc}")
            continue
        if key in seen:
            continue
        seen.add(key)
        records.append((key, payload))

    return records, errors


def validate(
    kind: str,
    items: list[dict[str, Any]],
    known_codes: set[str],
) -> list[dict[str, Any]]:
    """Проверяет набор своих категорий и приводит его к хранимому виду."""
    result: list[dict[str, Any]] = []
    used: set[str] = set()

    for item in items:
        code = normalize_code(item.get("code", ""))
        if code in known_codes:
            raise CustomError(
                f"Категория «{code}» уже есть в исходном файле — выберите другое название"
            )
        if code in used:
            raise CustomError(f"Категория «{code}» указана дважды")
        used.add(code)

        sources = [s for s in (item.get("sources") or []) if s in known_codes]
        text = item.get("entries") or ""
        _records, errors = parse_entries(kind, text)
        if errors:
            raise CustomError(f"«{code}»: " + "; ".join(errors[:3]))
        if not sources and not _records:
            raise CustomError(
                f"«{code}»: нечего собирать — добавьте категории или свои записи"
            )

        result.append(
            {
                "id": item.get("id") or uuid.uuid4().hex[:8],
                "code": code,
                "enabled": bool(item.get("enabled", True)),
                "sources": sources,
                "entries": text,
                "replace_sources": bool(item.get("replace_sources", False)),
            }
        )

    return result
