"""Ядро RULITE."""
