"""Публикация релизов в GitHub и GitVerse.

Модуль сам приводит репозиторий в пригодное состояние: создаёт первый коммит
в пустом репозитории и подбирает свободный тег, если занят. Ошибки площадок
показываются дословно, а не угадываются по коду ответа.
"""

from __future__ import annotations

import asyncio
import base64
import logging
from pathlib import Path
from typing import Any, Callable

import httpx

from . import notes


log = logging.getLogger("rulite.publish")

MAX_TAG_ATTEMPTS = 20

# Какой формат загрузки ассетов сработал у сервиса в этом запуске.
_ASSET_FORMAT: dict[str, str] = {}

INIT_README = """# ❤️ RULITE

Репозиторий для автоматических релизов. Содержимое будет заполнено
после первой публикации.
"""


class PublishError(RuntimeError):
    pass


PROVIDERS: dict[str, dict[str, str]] = {
    "github": {
        "title": "GitHub",
        "api": "https://api.github.com",
        "accept": "application/vnd.github+json",
        "web": "https://github.com",
    },
    "gitverse": {
        "title": "GitVerse",
        "api": "https://api.gitverse.ru",
        "accept": "application/vnd.gitverse.object+json;version=1",
        "web": "https://gitverse.ru",
    },
}


HOSTS = {
    "github.com": "github",
    "www.github.com": "github",
    "gitverse.ru": "gitverse",
    "www.gitverse.ru": "gitverse",
}


def parse_repo(value: str) -> tuple[str | None, str]:
    """Приводит любую форму записи репозитория к виду ``user/repo``.

    Принимает ссылку из адресной строки, адрес для clone и короткую запись:
    ``https://github.com/user/repo``, ``git@github.com:user/repo.git``,
    ``github.com/user/repo/releases``, ``user/repo``. Если по адресу видно
    площадку, она возвращается первым элементом.
    """
    value = (value or "").strip()
    if not value:
        return None, ""

    if value.startswith("git@"):
        value = value[4:].replace(":", "/", 1)
    if "://" in value:
        value = value.split("://", 1)[1]
    value = value.split("?", 1)[0].split("#", 1)[0]

    parts = [part for part in value.split("/") if part]
    if not parts:
        return None, ""

    provider = HOSTS.get(parts[0].lower())
    if provider or ("." in parts[0] and len(parts) > 2):
        parts = parts[1:]

    parts = parts[:2]
    repo = "/".join(parts)
    if repo.endswith(".git"):
        repo = repo[:-4]
    return provider, repo


def provider_title(provider: str) -> str:
    return PROVIDERS.get(provider, {}).get("title", provider)


def _headers(target: dict[str, Any]) -> dict[str, str]:
    provider = PROVIDERS[target["provider"]]
    headers = {
        "Authorization": f"Bearer {target['token']}",
        "Accept": provider["accept"],
        "User-Agent": "RULITE",
    }
    if target["provider"] == "github":
        headers["X-GitHub-Api-Version"] = "2022-11-28"
    return headers


def _api(target: dict[str, Any]) -> str:
    return PROVIDERS[target["provider"]]["api"]


def _detail(response: httpx.Response) -> str:
    """Достаёт человекочитаемое пояснение из ответа площадки."""
    try:
        data = response.json()
    except ValueError:
        text = (response.text or "").strip()
        return text[:200] if text else f"код {response.status_code}"

    if isinstance(data, dict):
        parts = []
        message = data.get("message") or data.get("error") or data.get("detail")
        if message:
            parts.append(str(message))
        for item in data.get("errors") or []:
            if isinstance(item, dict):
                text = item.get("message") or item.get("code") or item.get("field")
                if text:
                    parts.append(str(text))
            elif item:
                parts.append(str(item))
        if parts:
            return f"{' — '.join(dict.fromkeys(parts))} (код {response.status_code})"
    if isinstance(data, list) and data:
        return f"{str(data[0])[:160]} (код {response.status_code})"
    return f"код {response.status_code}"


def asset_links(target: dict[str, Any], tag: str) -> tuple[dict[str, str], bool]:
    """Ссылки на файлы релиза и признак «ссылка всегда ведёт на последний»."""
    web = PROVIDERS[target["provider"]]["web"]
    repo = target["repo"]
    if target["provider"] == "github":
        base = f"{web}/{repo}/releases/latest/download"
        return {"geosite": f"{base}/geosite.dat", "geoip": f"{base}/geoip.dat"}, True
    page = f"{web}/{repo}/releases/tag/{tag}"
    return {"geosite": page, "geoip": page}, False


def render_body(
    template: str,
    target: dict[str, Any],
    tag: str,
    files: list[dict[str, Any]],
    source_url: str = "",
    urls: dict[str, str] | None = None,
    latest: bool | None = None,
) -> str:
    default_urls, default_latest = asset_links(target, tag)
    context = notes.build_context(
        tag,
        files,
        urls if urls is not None else default_urls,
        repo=target["repo"],
        service=provider_title(target["provider"]),
        release_url=f"{PROVIDERS[target['provider']]['web']}/{target['repo']}"
                    f"/releases/tag/{tag}",
        latest_links=default_latest if latest is None else latest,
        source_url=source_url,
    )
    body, _unknown = notes.render(template or notes.DEFAULT_TEXT, context)
    return body


def validate_target(target: dict[str, Any]) -> None:
    if target.get("provider") not in PROVIDERS:
        raise PublishError("Неизвестный сервис публикации")
    repo = (target.get("repo") or "").strip()
    if repo.count("/") != 1 or not all(repo.split("/")):
        raise PublishError("Репозиторий указывается как user/repo")
    if not target.get("token"):
        raise PublishError("Не указан токен")


# --------------------------------------------------------------------------
# Подготовка репозитория
# --------------------------------------------------------------------------

async def _repo_info(
    client: httpx.AsyncClient, target: dict[str, Any]
) -> dict[str, Any]:
    title = provider_title(target["provider"])
    response = await client.get(
        f"{_api(target)}/repos/{target['repo']}", follow_redirects=True
    )
    if response.status_code in (401, 403):
        raise PublishError(f"{title}: токен недействителен или не даёт доступа")
    if response.status_code == 404:
        raise PublishError(f"{title}: репозиторий не найден либо токен его не видит")
    if response.status_code >= 400:
        raise PublishError(f"{title}: {_detail(response)}")
    return response.json()


async def _is_empty(
    client: httpx.AsyncClient,
    target: dict[str, Any],
    info: dict[str, Any] | None = None,
) -> bool:
    """Есть ли в репозитории хотя бы один коммит.

    Сначала смотрим поле самого репозитория: у Gitea-совместимых сервисов,
    к которым относится GitVerse, оно есть и не врёт. Список коммитов —
    запасной путь для GitHub.
    """
    if info and isinstance(info.get("empty"), bool):
        return info["empty"]

    response = await client.get(
        f"{_api(target)}/repos/{target['repo']}/commits",
        params={"per_page": 1},
        follow_redirects=True,
    )
    if response.status_code in (404, 409):
        return True
    if response.status_code >= 400:
        return False  # не смогли выяснить — не мешаем публикации
    try:
        data = response.json()
    except ValueError:
        return False
    return isinstance(data, list) and not data


async def _create_first_commit(
    client: httpx.AsyncClient,
    target: dict[str, Any],
    branch: str | None,
    note: Callable[[str], None],
    text: str = "",
) -> None:
    title = provider_title(target["provider"])
    note(f"{title}: репозиторий пуст, создаю первый коммит")

    payload: dict[str, Any] = {
        "message": "Инициализация репозитория для релизов RULITE",
        "content": base64.b64encode(
            (text or INIT_README).encode("utf-8")
        ).decode("ascii"),
    }
    if branch:
        payload["branch"] = branch

    response = await client.put(
        f"{_api(target)}/repos/{target['repo']}/contents/README.md", json=payload
    )
    if response.status_code >= 400:
        raise PublishError(
            f"{title}: не удалось создать первый коммит — {_detail(response)}. "
            "Добавьте в репозиторий любой файл вручную и повторите."
        )
    note(f"{title}: README.md добавлен")


async def write_readme(
    client: httpx.AsyncClient,
    target: dict[str, Any],
    text: str,
    branch: str | None,
    tag: str,
    note: Callable[[str], None],
) -> bool:
    """Создаёт или обновляет README.md в корне репозитория.

    Если содержимое не изменилось, коммит не делается — чтобы история
    не засорялась одинаковыми правками при каждом релизе.
    """
    title = provider_title(target["provider"])
    url = f"{_api(target)}/repos/{target['repo']}/contents/README.md"
    params = {"ref": branch} if branch else {}

    sha = None
    existing = await client.get(url, params=params, follow_redirects=True)
    if existing.status_code < 400:
        try:
            data = existing.json()
        except ValueError:
            data = {}
        # Некоторые сервисы отвечают списком файлов, а не одним объектом.
        if isinstance(data, list):
            data = next(
                (item for item in data
                 if isinstance(item, dict) and item.get("name") == "README.md"),
                {},
            )
        if not isinstance(data, dict):
            data = {}
        sha = data.get("sha")
        raw = data.get("content")
        if raw:
            try:
                current = base64.b64decode(raw).decode("utf-8")
            except Exception:  # noqa: BLE001
                current = ""
            if current.strip() == text.strip():
                note(f"{title}: README.md не изменился")
                return False

    payload: dict[str, Any] = {
        "message": f"README: релиз {tag}",
        "content": base64.b64encode(text.encode("utf-8")).decode("ascii"),
    }
    if branch:
        payload["branch"] = branch
    if sha:
        payload["sha"] = sha

    response = await client.put(url, json=payload)
    if response.status_code >= 400:
        note(f"{title}: не удалось обновить README.md — {_detail(response)}")
        return False
    note(f"{title}: README.md обновлён")
    return True


async def _prepare_repo(
    client: httpx.AsyncClient,
    target: dict[str, Any],
    note: Callable[[str], None],
    readme: str = "",
) -> tuple[str | None, bool]:
    info = await _repo_info(client, target)
    branch = info.get("default_branch") or None
    created = False
    if await _is_empty(client, target, info):
        await _create_first_commit(client, target, branch, note, readme)
        created = True
        # Сервису нужно время, чтобы ветка появилась, иначе релиз не создать.
        await asyncio.sleep(2)
    return branch, created


# --------------------------------------------------------------------------
# Подбор свободного тега
# --------------------------------------------------------------------------

async def _resolve_tag(
    client: httpx.AsyncClient,
    target: dict[str, Any],
    tag: str,
    note: Callable[[str], None],
) -> str:
    """Возвращает свободный тег. Пустой релиз от прошлой неудачи переиспользует."""
    title = provider_title(target["provider"])
    base = f"{_api(target)}/repos/{target['repo']}"

    for attempt in range(1, MAX_TAG_ATTEMPTS + 1):
        candidate = tag if attempt == 1 else f"{tag}-{attempt}"
        response = await client.get(
            f"{base}/releases/tags/{candidate}", follow_redirects=True
        )

        if response.status_code == 404:
            return candidate
        if response.status_code >= 400:
            return candidate  # выяснить не вышло — пробуем как есть

        try:
            existing = response.json()
        except ValueError:
            return candidate

        if not existing.get("assets"):
            # Релиз без файлов остался от прошлой неудачной попытки — убираем.
            note(f"{title}: удаляю пустой релиз {candidate} от прошлой попытки")
            await client.delete(f"{base}/releases/{existing['id']}")
            return candidate

        if attempt == 1:
            note(f"{title}: релиз {candidate} уже есть, подбираю свободный тег")

    raise PublishError(
        f"{title}: не нашлось свободного тега для {tag} — "
        f"проверено {MAX_TAG_ATTEMPTS} вариантов"
    )


# --------------------------------------------------------------------------
# Проверка доступа
# --------------------------------------------------------------------------

async def check_target(target: dict[str, Any]) -> dict[str, Any]:
    validate_target(target)
    title = provider_title(target["provider"])

    async with httpx.AsyncClient(headers=_headers(target), timeout=30) as client:
        info = await _repo_info(client, target)
        if target["provider"] == "github" and not info.get("permissions", {}).get("push"):
            raise PublishError(
                f"{title}: у токена нет прав на запись (Contents: Read and write)"
            )
        empty = await _is_empty(client, target, info)

    return {
        "provider": target["provider"],
        "title": title,
        "repo": info.get("full_name") or target["repo"],
        "private": bool(info.get("private")),
        "empty": empty,
    }


# --------------------------------------------------------------------------
# Публикация
# --------------------------------------------------------------------------

async def publish_release(
    target: dict[str, Any],
    tag: str,
    files: list[dict[str, Any]],
    on_log: Callable[[str], None] | None = None,
    template: str = "",
    source_url: str = "",
    readme: str = "",
) -> dict[str, Any]:
    validate_target(target)
    title = provider_title(target["provider"])
    base = f"{_api(target)}/repos/{target['repo']}"

    def note(message: str) -> None:
        log.info(message)
        if on_log:
            on_log(message)

    async with httpx.AsyncClient(headers=_headers(target), timeout=300) as client:
        readme_text = (
            render_body(readme, target, tag, files, source_url) if readme else ""
        )
        branch, created = await _prepare_repo(client, target, note, readme_text)
        if readme_text and not created:
            try:
                await write_readme(client, target, readme_text, branch, tag, note)
            except Exception as exc:  # noqa: BLE001
                note(f"{title}: README.md не обновлён — {exc}")

        body = render_body(template, target, tag, files, source_url)
        release, tag = await _create_release(
            client, target, tag, branch, body, note
        )

        upload_url = (release.get("upload_url") or "").split("{")[0]
        if not upload_url:
            upload_url = f"{base}/releases/{release['id']}/assets"

        uploaded: list[str] = []
        real_links: dict[str, str] = {}
        try:
            for item in files:
                path = Path(item["path"])
                size = item["size"]
                human = (
                    f"{size / 1048576:.2f} МБ" if size >= 1048576 else f"{size / 1024:.1f} КБ"
                )
                note(f"{title}: загружаю {path.name} ({human})")
                data = path.read_bytes()
                asset = await _upload_asset(
                    client, target, upload_url, path.name, data, note
                )
                del data
                uploaded.append(path.name)
                try:
                    info = asset.json()
                except ValueError:
                    info = {}
                link = info.get("browser_download_url") or info.get("url")
                if link:
                    real_links[item["kind"]] = link
        except Exception as exc:
            note(f"{title}: ошибка загрузки, удаляю незавершённый релиз")
            try:
                await client.delete(f"{base}/releases/{release['id']}")
            except Exception:  # pragma: no cover
                log.exception("Не удалось удалить релиз %s", release.get("id"))
            if isinstance(exc, PublishError):
                raise
            raise PublishError(f"{title}: не удалось загрузить файлы — {exc}") from exc

        # У GitHub ссылка «latest/download» и так всегда ведёт на свежий файл.
        # Для остальных подставляем настоящие адреса, полученные при загрузке.
        if target["provider"] != "github" and len(real_links) == len(files):
            try:
                updated = render_body(
                    template, target, tag, files, source_url,
                    urls=real_links, latest=False,
                )
                await client.patch(
                    f"{base}/releases/{release['id']}", json={"body": updated}
                )
            except Exception:  # noqa: BLE001
                log.warning("Не удалось обновить текст релиза настоящими ссылками")

    note(f"{title}: релиз {tag} опубликован")
    return {
        "provider": target["provider"],
        "title": title,
        "repo": target["repo"],
        "tag": tag,
        "id": release.get("id"),
        "url": _release_url(target, release, tag),
        "assets": uploaded,
    }


ASSET_RETRY_CODES = {400, 404, 405, 413, 415, 422, 500, 502, 503, 504}


def _asset_variants(
    target: dict[str, Any], name: str, data: bytes
) -> list[tuple[str, dict[str, Any]]]:
    """Способы передать файл, от самого вероятного к запасным.

    GitHub принимает сырое тело. Для Gitea-совместимых сервисов, к которым
    относится GitVerse, точный формат в документации не описан, поэтому
    перебираем известные сочетания поля формы, параметра имени и заголовка
    Accept.
    """
    auth_only = {
        "Authorization": _headers(target)["Authorization"],
        "User-Agent": "RULITE",
    }
    raw_headers = {**_headers(target), "Content-Type": "application/octet-stream"}
    part = (name, data, "application/octet-stream")

    if target["provider"] == "github":
        return [("сырое тело", {
            "params": {"name": name}, "content": data, "headers": raw_headers,
        })]

    return [
        ("multipart attachment", {
            "params": {"name": name}, "files": {"attachment": part},
        }),
        ("multipart attachment, обычный Accept", {
            "params": {"name": name}, "files": {"attachment": part},
            "headers": {**auth_only, "Accept": "application/json"},
        }),
        ("multipart attachment без параметра", {"files": {"attachment": part}}),
        ("multipart file", {"params": {"name": name}, "files": {"file": part}}),
        ("сырое тело", {
            "params": {"name": name}, "content": data, "headers": raw_headers,
        }),
        ("сырое тело, обычный Accept", {
            "params": {"name": name}, "content": data,
            "headers": {
                **auth_only,
                "Accept": "application/json",
                "Content-Type": "application/octet-stream",
            },
        }),
    ]


async def _probe_asset(
    client: httpx.AsyncClient, target: dict[str, Any], upload_url: str
) -> str | None:
    """Пробует крошечный файл, чтобы отличить отказ по формату от отказа по размеру."""
    name = "rulite-probe.txt"
    try:
        response = await client.post(
            upload_url,
            params={"name": name},
            files={"attachment": (name, b"rulite", "text/plain")},
        )
    except Exception:  # noqa: BLE001
        return None

    if response.status_code >= 400:
        return None

    # Убираем за собой пробный файл.
    try:
        asset_id = (response.json() or {}).get("id")
        if asset_id:
            await client.delete(f"{upload_url.rstrip('/')}/{asset_id}")
    except Exception:  # noqa: BLE001
        pass
    return (
        "пробный файл в несколько байт сервис принял — похоже, дело не в формате "
        "запроса, а в размере файла или во временном сбое на их стороне"
    )


async def _upload_asset(
    client: httpx.AsyncClient,
    target: dict[str, Any],
    upload_url: str,
    name: str,
    data: bytes,
    note: Callable[[str], None],
) -> httpx.Response:
    """Загружает файл в релиз, подбирая формат и повторяя временные сбои."""
    title = provider_title(target["provider"])
    variants = _asset_variants(target, name, data)

    preferred = _ASSET_FORMAT.get(target["provider"])
    if preferred:
        variants.sort(key=lambda item: item[0] != preferred)

    last: httpx.Response | None = None
    for label, kwargs in variants:
        for attempt in (1, 2):
            try:
                response = await client.post(upload_url, **kwargs)
            except httpx.HTTPError as exc:
                note(f"{title}: обрыв связи при загрузке {name} — {exc}")
                last = None
                break

            if response.status_code < 400:
                if _ASSET_FORMAT.get(target["provider"]) != label:
                    _ASSET_FORMAT[target["provider"]] = label
                    note(f"{title}: файлы принимаются как «{label}»")
                return response

            last = response
            # Ошибка сервера бывает разовой — повторяем тем же способом.
            if response.status_code >= 500 and attempt == 1:
                note(f"{title}: сервис ответил {response.status_code}, повторяю")
                await asyncio.sleep(3)
                continue
            break

        if last is not None and last.status_code not in ASSET_RETRY_CODES:
            break  # отказ по правам или авторизации — перебор не поможет

    hint = ""
    if last is not None and last.status_code >= 500:
        probe = await _probe_asset(client, target, upload_url)
        if probe:
            hint = f". {probe}"

    raise PublishError(
        f"{title}: файл {name} не принят — "
        f"{_detail(last) if last is not None else 'нет ответа'}{hint}"
    )


async def _create_release(
    client: httpx.AsyncClient,
    target: dict[str, Any],
    tag: str,
    branch: str | None,
    body: str,
    note: Callable[[str], None],
) -> tuple[dict[str, Any], str]:
    """Создаёт релиз.

    Временные ошибки сервиса (5xx) повторяются: GitHub периодически отвечает
    500, успев при этом создать релиз, поэтому перед повтором проверяем, не
    появился ли он. Конфликт тега разрешается следующим свободным номером.
    """
    title = provider_title(target["provider"])
    base = f"{_api(target)}/repos/{target['repo']}"
    candidate = await _resolve_tag(client, target, tag, note)
    delay = 2

    for attempt in range(1, MAX_TAG_ATTEMPTS + 1):
        payload: dict[str, Any] = {
            "tag_name": candidate,
            "name": candidate,
            "body": body,
            "draft": False,
            "prerelease": False,
        }
        if branch:
            payload["target_commitish"] = branch

        note(f"{title} ({target['repo']}): создаю релиз {candidate}")
        try:
            response = await client.post(f"{base}/releases", json=payload)
        except httpx.HTTPError as exc:
            if attempt > 3:
                raise PublishError(f"{title}: сеть недоступна — {exc}") from exc
            note(f"{title}: сбой связи, повтор через {delay} с")
            await asyncio.sleep(delay)
            delay *= 2
            continue

        if response.status_code < 400:
            return response.json(), candidate

        # Сервис мог создать релиз и всё равно ответить ошибкой.
        existing = await _find_release(client, base, candidate)
        if existing:
            note(f"{title}: релиз всё же создан, продолжаю")
            return existing, candidate

        if response.status_code >= 500 and attempt <= 3:
            note(f"{title}: сервис ответил {response.status_code}, повтор через {delay} с")
            await asyncio.sleep(delay)
            delay *= 2
            continue

        detail = _detail(response)
        if response.status_code in (409, 422):
            if "already_exists" in detail or "already exists" in detail.lower():
                candidate = f"{tag}-{attempt + 1}"
                note(f"{title}: тег занят, пробую {candidate}")
                continue
            raise PublishError(
                f"{title}: {detail}. Проверьте, что в репозитории есть хотя бы "
                "один коммит и у токена достаточно прав."
            )

        if response.status_code in (401, 403):
            raise PublishError(f"{title}: нет прав на создание релиза — {detail}")
        raise PublishError(f"{title}: {detail}")

    raise PublishError(f"{title}: не удалось подобрать свободный тег для {tag}")


async def _find_release(
    client: httpx.AsyncClient, base: str, tag: str
) -> dict[str, Any] | None:
    try:
        response = await client.get(f"{base}/releases/tags/{tag}", follow_redirects=True)
    except httpx.HTTPError:
        return None
    if response.status_code != 200:
        return None
    try:
        data = response.json()
    except ValueError:
        return None
    return data if isinstance(data, dict) and data.get("id") else None


def _release_url(target: dict[str, Any], release: dict[str, Any], tag: str) -> str:
    html = release.get("html_url")
    if html and target["provider"] == "github":
        return html
    web = PROVIDERS[target["provider"]]["web"]
    return f"{web}/{target['repo']}/releases/tag/{tag}"


async def publish_all(
    targets: list[dict[str, Any]],
    tag: str,
    files: list[dict[str, Any]],
    on_log: Callable[[str], None] | None = None,
    template: str = "",
    source_url: str = "",
    readme: str = "",
) -> tuple[list[dict[str, Any]], list[str]]:
    """Публикует во все цели. Сбой одной не отменяет остальные."""
    published: list[dict[str, Any]] = []
    errors: list[str] = []
    for target in targets:
        try:
            published.append(
                await publish_release(
                    target, tag, files, on_log, template, source_url, readme
                )
            )
        except PublishError as exc:
            errors.append(str(exc))
            if on_log:
                on_log(str(exc))
        except Exception as exc:  # noqa: BLE001
            message = f"{provider_title(target.get('provider', ''))}: {exc}"
            errors.append(message)
            if on_log:
                on_log(message)
    return published, errors
