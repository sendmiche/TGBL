"""Публикация релизов в GitHub и GitVerse.

Модуль сам приводит репозиторий в пригодное состояние: создаёт первый коммит
в пустом репозитории и подбирает свободный тег, если занят. Ошибки площадок
показываются дословно, а не угадываются по коду ответа.
"""

from __future__ import annotations

import asyncio
import base64
import logging
from pathlib import Path
from typing import Any, Callable

import httpx

from . import notes


log = logging.getLogger("rulite.publish")

MAX_TAG_ATTEMPTS = 20

# Какой формат загрузки ассетов сработал у сервиса в этом запуске.
_ASSET_FORMAT: dict[str, str] = {}

# Расширение, под которым сервис соглашается принять файл. GitVerse отвергает
# .dat при любом типе содержимого, поэтому файлы уходят туда под другим именем.
_ASSET_EXT: dict[str, str] = {}

# Чем пробуем заменить неподходящее расширение, от нейтрального к частному.
EXT_CANDIDATES = (".bin", ".txt", ".db", ".json", ".gz", ".zip")

INIT_README = """# ❤️ RULITE

Репозиторий для автоматических релизов. Содержимое будет заполнено
после первой публикации.
"""


class PublishError(RuntimeError):
    pass


PROVIDERS: dict[str, dict[str, str]] = {
    "github": {
        "title": "GitHub",
        "api": "https://api.github.com",
        "accept": "application/vnd.github+json",
        "web": "https://github.com",
    },
    "gitverse": {
        "title": "GitVerse",
        "api": "https://api.gitverse.ru",
        "accept": "application/vnd.gitverse.object+json; version=1",
        "web": "https://gitverse.ru",
    },
}


HOSTS = {
    "github.com": "github",
    "www.github.com": "github",
    "gitverse.ru": "gitverse",
    "www.gitverse.ru": "gitverse",
}


def parse_repo(value: str) -> tuple[str | None, str]:
    """Приводит любую форму записи репозитория к виду ``user/repo``.

    Принимает ссылку из адресной строки, адрес для clone и короткую запись:
    ``https://github.com/user/repo``, ``git@github.com:user/repo.git``,
    ``github.com/user/repo/releases``, ``user/repo``. Если по адресу видно
    площадку, она возвращается первым элементом.
    """
    value = (value or "").strip()
    if not value:
        return None, ""

    if value.startswith("git@"):
        value = value[4:].replace(":", "/", 1)
    if "://" in value:
        value = value.split("://", 1)[1]
    value = value.split("?", 1)[0].split("#", 1)[0]

    parts = [part for part in value.split("/") if part]
    if not parts:
        return None, ""

    provider = HOSTS.get(parts[0].lower())
    if provider or ("." in parts[0] and len(parts) > 2):
        parts = parts[1:]

    parts = parts[:2]
    repo = "/".join(parts)
    if repo.endswith(".git"):
        repo = repo[:-4]
    return provider, repo


def provider_title(provider: str) -> str:
    return PROVIDERS.get(provider, {}).get("title", provider)


def _headers(target: dict[str, Any]) -> dict[str, str]:
    provider = PROVIDERS[target["provider"]]
    headers = {
        "Authorization": f"Bearer {target['token']}",
        "Accept": provider["accept"],
        "User-Agent": "RULITE",
    }
    if target["provider"] == "github":
        headers["X-GitHub-Api-Version"] = "2022-11-28"
    return headers


def _api(target: dict[str, Any]) -> str:
    return PROVIDERS[target["provider"]]["api"]


def _detail(response: httpx.Response) -> str:
    """Достаёт человекочитаемое пояснение из ответа площадки."""
    try:
        data = response.json()
    except ValueError:
        text = (response.text or "").strip()
        return text[:200] if text else f"код {response.status_code}"

    if isinstance(data, dict):
        parts = []
        message = data.get("message") or data.get("error") or data.get("detail")
        if message:
            parts.append(str(message))
        for item in data.get("errors") or []:
            if isinstance(item, dict):
                text = item.get("message") or item.get("code") or item.get("field")
                if text:
                    parts.append(str(text))
            elif item:
                parts.append(str(item))
        if parts:
            return f"{' — '.join(dict.fromkeys(parts))} (код {response.status_code})"
    if isinstance(data, list) and data:
        return f"{str(data[0])[:160]} (код {response.status_code})"
    return f"код {response.status_code}"


def asset_links(
    target: dict[str, Any], tag: str, default_branch: str | None = None
) -> tuple[dict[str, str], bool]:
    """Ссылки на файлы и признак «ссылка всегда ведёт на последнюю версию»."""
    web = PROVIDERS[target["provider"]]["web"]
    repo = target["repo"]

    if target.get("mirror"):
        # Файлы лежат в ветке репозитория — ссылка на неё всегда актуальна.
        branch = mirror_branch(target, default_branch)
        return {
            "geosite": file_url(target, branch, "geosite.dat"),
            "geoip": file_url(target, branch, "geoip.dat"),
        }, True

    if target["provider"] == "github":
        base = f"{web}/{repo}/releases/latest/download"
        return {"geosite": f"{base}/geosite.dat", "geoip": f"{base}/geoip.dat"}, True
    page = f"{web}/{repo}/releases/tag/{tag}"
    return {"geosite": page, "geoip": page}, False


def render_body(
    template: str,
    target: dict[str, Any],
    tag: str,
    files: list[dict[str, Any]],
    source_url: str = "",
    urls: dict[str, str] | None = None,
    latest: bool | None = None,
    default_branch: str | None = None,
) -> str:
    default_urls, default_latest = asset_links(target, tag, default_branch)
    context = notes.build_context(
        tag,
        files,
        urls if urls is not None else default_urls,
        repo=target["repo"],
        service=provider_title(target["provider"]),
        release_url=f"{PROVIDERS[target['provider']]['web']}/{target['repo']}"
                    f"/releases/tag/{tag}",
        latest_links=default_latest if latest is None else latest,
        source_url=source_url,
    )
    body, _unknown = notes.render(template or notes.DEFAULT_TEXT, context)
    return body


def validate_target(target: dict[str, Any]) -> None:
    if target.get("provider") not in PROVIDERS:
        raise PublishError("Неизвестный сервис публикации")
    repo = (target.get("repo") or "").strip()
    if repo.count("/") != 1 or not all(repo.split("/")):
        raise PublishError("Репозиторий указывается как user/repo")
    if not target.get("token"):
        raise PublishError("Не указан токен")


# --------------------------------------------------------------------------
# Подготовка репозитория
# --------------------------------------------------------------------------

async def _repo_info(
    client: httpx.AsyncClient, target: dict[str, Any]
) -> dict[str, Any]:
    title = provider_title(target["provider"])
    response = await client.get(
        f"{_api(target)}/repos/{target['repo']}", follow_redirects=True
    )
    if response.status_code in (401, 403):
        raise PublishError(f"{title}: токен недействителен или не даёт доступа")
    if response.status_code == 404:
        raise PublishError(f"{title}: репозиторий не найден либо токен его не видит")
    if response.status_code >= 400:
        raise PublishError(f"{title}: {_detail(response)}")
    return response.json()


async def _is_empty(
    client: httpx.AsyncClient,
    target: dict[str, Any],
    info: dict[str, Any] | None = None,
) -> bool:
    """Есть ли в репозитории хотя бы один коммит.

    Сначала смотрим поле самого репозитория: у Gitea-совместимых сервисов,
    к которым относится GitVerse, оно есть и не врёт. Список коммитов —
    запасной путь для GitHub.
    """
    if info and isinstance(info.get("empty"), bool):
        return info["empty"]

    response = await client.get(
        f"{_api(target)}/repos/{target['repo']}/commits",
        params={"per_page": 1},
        follow_redirects=True,
    )
    if response.status_code in (404, 409):
        return True
    if response.status_code >= 400:
        return False  # не смогли выяснить — не мешаем публикации
    try:
        data = response.json()
    except ValueError:
        return False
    return isinstance(data, list) and not data


async def _create_first_commit(
    client: httpx.AsyncClient,
    target: dict[str, Any],
    branch: str | None,
    note: Callable[[str], None],
    text: str = "",
) -> None:
    title = provider_title(target["provider"])
    note(f"{title}: репозиторий пуст, создаю первый коммит")

    payload: dict[str, Any] = {
        "message": "Инициализация репозитория для релизов RULITE",
        "content": base64.b64encode(
            (text or INIT_README).encode("utf-8")
        ).decode("ascii"),
    }
    if branch:
        payload["branch"] = branch

    response = await client.put(
        f"{_api(target)}/repos/{target['repo']}/contents/README.md", json=payload
    )
    if response.status_code >= 400:
        raise PublishError(
            f"{title}: не удалось создать первый коммит — {_detail(response)}. "
            "Добавьте в репозиторий любой файл вручную и повторите."
        )
    note(f"{title}: README.md добавлен")


async def write_readme(
    client: httpx.AsyncClient,
    target: dict[str, Any],
    text: str,
    branch: str | None,
    tag: str,
    note: Callable[[str], None],
) -> bool:
    """Создаёт или обновляет README.md в корне репозитория.

    Если содержимое не изменилось, коммит не делается — чтобы история
    не засорялась одинаковыми правками при каждом релизе.
    """
    title = provider_title(target["provider"])
    url = f"{_api(target)}/repos/{target['repo']}/contents/README.md"
    params = {"ref": branch} if branch else {}

    sha = None
    existing = await client.get(url, params=params, follow_redirects=True)
    if existing.status_code < 400:
        try:
            data = existing.json()
        except ValueError:
            data = {}
        # Некоторые сервисы отвечают списком файлов, а не одним объектом.
        if isinstance(data, list):
            data = next(
                (item for item in data
                 if isinstance(item, dict) and item.get("name") == "README.md"),
                {},
            )
        if not isinstance(data, dict):
            data = {}
        sha = data.get("sha")
        raw = data.get("content")
        if raw:
            try:
                current = base64.b64decode(raw).decode("utf-8")
            except Exception:  # noqa: BLE001
                current = ""
            if current.strip() == text.strip():
                note(f"{title}: README.md не изменился")
                return False

    payload: dict[str, Any] = {
        "message": f"README: релиз {tag}",
        "content": base64.b64encode(text.encode("utf-8")).decode("ascii"),
    }
    if branch:
        payload["branch"] = branch
    if sha:
        payload["sha"] = sha

    response = await client.put(url, json=payload)
    if response.status_code >= 400:
        note(f"{title}: не удалось обновить README.md — {_detail(response)}")
        return False
    note(f"{title}: README.md обновлён")
    return True


async def _prepare_repo(
    client: httpx.AsyncClient,
    target: dict[str, Any],
    note: Callable[[str], None],
    readme: str = "",
) -> tuple[str | None, bool]:
    info = await _repo_info(client, target)
    branch = info.get("default_branch") or None
    created = False
    if await _is_empty(client, target, info):
        await _create_first_commit(client, target, branch, note, readme)
        created = True
        # Сервису нужно время, чтобы ветка появилась, иначе релиз не создать.
        await asyncio.sleep(2)
    return branch, created


# --------------------------------------------------------------------------
# Подбор свободного тега
# --------------------------------------------------------------------------

async def _resolve_tag(
    client: httpx.AsyncClient,
    target: dict[str, Any],
    tag: str,
    note: Callable[[str], None],
) -> str:
    """Возвращает свободный тег. Пустой релиз от прошлой неудачи переиспользует."""
    title = provider_title(target["provider"])
    base = f"{_api(target)}/repos/{target['repo']}"

    for attempt in range(1, MAX_TAG_ATTEMPTS + 1):
        candidate = tag if attempt == 1 else f"{tag}-{attempt}"
        response = await client.get(
            f"{base}/releases/tags/{candidate}", follow_redirects=True
        )

        if response.status_code == 404:
            return candidate
        if response.status_code >= 400:
            return candidate  # выяснить не вышло — пробуем как есть

        try:
            existing = response.json()
        except ValueError:
            return candidate

        if not existing.get("assets"):
            # Релиз без файлов остался от прошлой неудачной попытки — убираем.
            note(f"{title}: удаляю пустой релиз {candidate} от прошлой попытки")
            await client.delete(f"{base}/releases/{existing['id']}")
            return candidate

        if attempt == 1:
            note(f"{title}: релиз {candidate} уже есть, подбираю свободный тег")

    raise PublishError(
        f"{title}: не нашлось свободного тега для {tag} — "
        f"проверено {MAX_TAG_ATTEMPTS} вариантов"
    )


# --------------------------------------------------------------------------
# Проверка доступа
# --------------------------------------------------------------------------

async def check_target(target: dict[str, Any]) -> dict[str, Any]:
    validate_target(target)
    title = provider_title(target["provider"])

    async with httpx.AsyncClient(headers=_headers(target), timeout=30) as client:
        info = await _repo_info(client, target)
        if target["provider"] == "github" and not info.get("permissions", {}).get("push"):
            raise PublishError(
                f"{title}: у токена нет прав на запись (Contents: Read and write)"
            )
        empty = await _is_empty(client, target, info)

    return {
        "provider": target["provider"],
        "title": title,
        "repo": info.get("full_name") or target["repo"],
        "private": bool(info.get("private")),
        "empty": empty,
    }


# --------------------------------------------------------------------------
# Публикация
# --------------------------------------------------------------------------

async def publish_release(
    target: dict[str, Any],
    tag: str,
    files: list[dict[str, Any]],
    on_log: Callable[[str], None] | None = None,
    template: str = "",
    source_url: str = "",
    readme: str = "",
) -> dict[str, Any]:
    validate_target(target)
    title = provider_title(target["provider"])
    base = f"{_api(target)}/repos/{target['repo']}"

    def note(message: str) -> None:
        log.info(message)
        if on_log:
            on_log(message)

    async with httpx.AsyncClient(headers=_headers(target), timeout=300) as client:
        # README рендерим дважды: до подготовки репозитория ветка ещё неизвестна,
        # а после — ссылки становятся точными.
        readme_text = (
            render_body(readme, target, tag, files, source_url) if readme else ""
        )
        branch, created = await _prepare_repo(client, target, note, readme_text)
        if readme:
            readme_text = render_body(
                readme, target, tag, files, source_url, default_branch=branch
            )
        if readme_text and not created:
            try:
                await write_readme(client, target, readme_text, branch, tag, note)
            except Exception as exc:  # noqa: BLE001
                note(f"{title}: README.md не обновлён — {exc}")

        body = render_body(
            template, target, tag, files, source_url, default_branch=branch
        )
        release, tag = await _create_release(
            client, target, tag, branch, body, note
        )

        upload_url = assets_url(target, release)
        if target["provider"] != "github":
            await _check_assets_endpoint(client, upload_url, note, title)

        if target["provider"] == "gitverse":
            _check_limits(files, note, title)

        uploaded: list[str] = []
        real_links: dict[str, str] = {}
        mirrored: list[str] = []
        asset_error: str | None = None
        mirror = bool(target.get("mirror"))
        try:
            for item in files:
                path = Path(item["path"])
                size = item["size"]
                human = (
                    f"{size / 1048576:.2f} МБ" if size >= 1048576 else f"{size / 1024:.1f} КБ"
                )
                note(f"{title}: загружаю {path.name} ({human})")
                data = path.read_bytes()
                # Имя может отличаться от исходного: сервис бывает
                # разборчив к расширениям.
                asset, stored_name = await _upload_asset(
                    client, target, upload_url, path.name, data, note
                )
                del data
                uploaded.append(stored_name)
                try:
                    info = asset.json()
                except ValueError:
                    info = {}
                link = info.get("browser_download_url") or info.get("url")
                if link:
                    real_links[item["kind"]] = link
        except Exception as exc:
            if not mirror:
                note(f"{title}: ошибка загрузки, удаляю незавершённый релиз")
                try:
                    await client.delete(f"{base}/releases/{release['id']}")
                except Exception:  # pragma: no cover
                    log.exception("Не удалось удалить релиз %s", release.get("id"))
                if isinstance(exc, PublishError):
                    raise
                raise PublishError(f"{title}: не удалось загрузить файлы — {exc}") from exc

            # Файлы всё равно попадут в репозиторий — релиз оставляем.
            asset_error = str(exc)
            note(f"{title}: вложения не приняты, кладу файлы в репозиторий")

        if mirror:
            mirrored = await mirror_to_repo(
                client, target, files, branch, tag, note
            )

        # У GitHub ссылка «latest/download» и так всегда ведёт на свежий файл.
        # Для остальных подставляем настоящие адреса, полученные при загрузке.
        if (not mirror and target["provider"] != "github"
                and len(real_links) == len(files)):
            try:
                updated = render_body(
                    template, target, tag, files, source_url,
                    urls=real_links, latest=False,
                )
                await client.patch(
                    f"{base}/releases/{release['id']}", json={"body": updated}
                )
            except Exception:  # noqa: BLE001
                log.warning("Не удалось обновить текст релиза настоящими ссылками")

    if asset_error:
        note(f"{title}: релиз {tag} создан, файлы лежат в репозитории")
    else:
        note(f"{title}: релиз {tag} опубликован")

    return {
        "provider": target["provider"],
        "title": title,
        "repo": target["repo"],
        "tag": tag,
        "id": release.get("id"),
        "url": _release_url(target, release, tag),
        "assets": uploaded,
        "mirrored": mirrored,
        "assetError": asset_error,
    }


ASSET_STOP_CODES = {401, 403}

# Лимиты релизов GitVerse из документации.
GITVERSE_MAX_ASSET = 100 * 1024 * 1024
GITVERSE_MAX_ASSETS = 5
GITVERSE_MAX_BATCH = 500 * 1024 * 1024


def _check_limits(
    files: list[dict[str, Any]], note: Callable[[str], None], title: str
) -> None:
    """Сверяет файлы с документированными лимитами релизов GitVerse."""
    total = sum(item["size"] for item in files)
    for item in files:
        if item["size"] > GITVERSE_MAX_ASSET:
            note(
                f"{title}: {Path(item['path']).name} — "
                f"{item['size'] / 1048576:.0f} МБ, предел "
                f"{GITVERSE_MAX_ASSET // 1048576} МБ"
            )
    if len(files) > GITVERSE_MAX_ASSETS:
        note(f"{title}: файлов {len(files)}, за раз принимается {GITVERSE_MAX_ASSETS}")
    if total > GITVERSE_MAX_BATCH:
        note(
            f"{title}: суммарно {total / 1048576:.0f} МБ, предел "
            f"{GITVERSE_MAX_BATCH // 1048576} МБ за раз"
        )


def assets_url(target: dict[str, Any], release: dict[str, Any]) -> str:
    """Адрес загрузки ассетов.

    У GitHub файлы принимает отдельный хост uploads.github.com — он приходит
    в поле upload_url, а api.github.com на этот путь отвечает 404. У GitVerse
    хост тот же, что и у остального API, поэтому там надёжнее собрать
    документированный путь: в upload_url встречается шаблонный хвост.
    """
    template = (release.get("upload_url") or "").split("{")[0]
    release_id = release.get("id")

    if target["provider"] == "github":
        if template:
            return template
        return (
            "https://uploads.github.com/repos/"
            f"{target['repo']}/releases/{release_id}/assets"
        )

    if release_id:
        return f"{_api(target)}/repos/{target['repo']}/releases/{release_id}/assets"
    return template


async def _check_assets_endpoint(
    client: httpx.AsyncClient, url: str, note: Callable[[str], None], title: str
) -> None:
    """Список ассетов: проверяем, что путь и идентификатор релиза верны.

    Если чтение проходит, а запись нет — дело точно в теле запроса, а не в
    адресе или правах.
    """
    try:
        response = await client.get(url, follow_redirects=True)
    except Exception as exc:  # noqa: BLE001
        note(f"{title}: список ассетов недоступен ({exc})")
        return
    if response.status_code < 400:
        note(f"{title}: адрес загрузки подтверждён (список ассетов читается)")
    else:
        note(f"{title}: список ассетов не читается — {_detail(response)}")


def _asset_variants(
    target: dict[str, Any], name: str, data: bytes
) -> list[tuple[str, dict[str, Any]]]:
    """Способы передать файл.

    Заголовок Accept с версией API документация называет обязательным, и опыт
    это подтверждает: без него сервис отвечает «Invalid request», а с ним —
    «Invalid request parameters», то есть запрос доходит до разбора полей.
    Поэтому Accept присутствует везде, а перебираем только состав тела.
    """
    part = (name, data, "application/octet-stream")
    raw_headers = {**_headers(target), "Content-Type": "application/octet-stream"}

    if target["provider"] == "github":
        return [("сырое тело", {
            "params": {"name": name}, "content": data, "headers": raw_headers,
        })]

    # В документации GitVerse встречаются три написания заголовка версии —
    # перебираем их вместе с составом тела.
    accepts = [
        ("", None),
        ("latest", "application/vnd.gitverse.object+json;version=latest"),
        ("без object", "application/vnd.gitverse+json;version=1"),
    ]

    variants: list[tuple[str, dict[str, Any]]] = []
    for suffix, accept in accepts:
        extra = {"headers": {"Accept": accept}} if accept else {}
        tail = f", Accept {suffix}" if suffix else ""
        variants.append((f"attachment + name в адресе{tail}", {
            "params": {"name": name}, "files": {"attachment": part}, **extra,
        }))

    variants += [
        ("attachment, тип text/plain", {
            "params": {"name": name},
            "files": {"attachment": (name, data, "text/plain")},
        }),
        ("attachment, тип не указан", {
            "params": {"name": name}, "files": {"attachment": (name, data)},
        }),
        ("attachment + name в теле", {
            "files": {"attachment": part}, "data": {"name": name},
        }),
        ("attachment + name в адресе и в теле", {
            "params": {"name": name},
            "files": {"attachment": part},
            "data": {"name": name},
        }),
        ("attachment без имени", {"files": {"attachment": part}}),
        ("file + name в адресе", {
            "params": {"name": name}, "files": {"file": part},
        }),
        ("сырое тело", {
            "params": {"name": name}, "content": data, "headers": raw_headers,
        }),
    ]
    return variants


async def _probe_asset(
    client: httpx.AsyncClient, target: dict[str, Any], upload_url: str, name: str
) -> tuple[str, str | None]:
    """Выясняет, что именно мешает: размер, расширение или тип содержимого.

    Рабочий файл и пробный отличались сразу тремя признаками, поэтому здесь
    они разделяются: шлём несколько крошечных файлов, меняя по одному
    признаку за раз, и смотрим, какой из них перестаёт приниматься.
    """
    suffix = Path(name).suffix or ".dat"
    probes = [
        (f"rulite-probe{suffix}", "application/octet-stream",
         f"то же расширение {suffix}, тип octet-stream"),
        (f"rulite-probe{suffix}", "text/plain",
         f"то же расширение {suffix}, тип text/plain"),
        ("rulite-probe.txt", "text/plain", "расширение .txt, тип text/plain"),
    ]

    lines: list[str] = []
    accepted: list[str] = []
    good_suffix: str | None = None
    for probe_name, content_type, label in probes:
        try:
            response = await client.post(
                upload_url,
                params={"name": probe_name},
                files={"attachment": (probe_name, b"rulite", content_type)},
            )
        except Exception as exc:  # noqa: BLE001
            lines.append(f"{label}: не ушёл ({exc})")
            continue

        if response.status_code < 400:
            accepted.append(label)
            if good_suffix is None:
                good_suffix = Path(probe_name).suffix
            lines.append(f"{label}: принят")
            try:
                asset_id = (response.json() or {}).get("id")
                if asset_id:
                    await client.delete(f"{upload_url.rstrip('/')}/{asset_id}")
            except Exception:  # noqa: BLE001
                pass
        else:
            lines.append(f"{label}: {_detail(response)}")

    verdict = "; ".join(lines)
    if accepted and accepted[0].startswith("то же расширение"):
        return (
            f"шесть байт с тем же именем и типом сервис принимает ({verdict}) — "
            "значит дело в размере файла, хотя документированный предел "
            f"{GITVERSE_MAX_ASSET // 1048576} МБ не превышен",
            None,
        )
    if accepted:
        return (
            f"принимается только часть проб ({verdict}) — дело в расширении "
            "файла или типе содержимого, а не в размере",
            good_suffix,
        )
    return f"ни одна проба не прошла ({verdict}) — дело в самом запросе", None


async def _find_extension(
    client: httpx.AsyncClient,
    target: dict[str, Any],
    upload_url: str,
    name: str,
    note: Callable[[str], None],
) -> str | None:
    """Ищет расширение, которое сервис согласен принять.

    Пробуем крошечные файлы: если проходит, например, .bin, значит настоящий
    файл можно залить под тем же именем с этим расширением — содержимое от
    этого не меняется, а ссылка в релизе ведёт на реальный адрес.
    """
    title = provider_title(target["provider"])

    for ext in EXT_CANDIDATES:
        probe = f"rulite-probe{ext}"
        try:
            response = await client.post(
                upload_url,
                params={"name": probe},
                files={"attachment": (probe, b"rulite", "application/octet-stream")},
            )
        except Exception:  # noqa: BLE001
            continue

        if response.status_code >= 400:
            continue

        try:
            asset_id = (response.json() or {}).get("id")
            if asset_id:
                await client.delete(f"{upload_url.rstrip('/')}/{asset_id}")
        except Exception:  # noqa: BLE001
            pass

        note(f"{title}: расширение {Path(name).suffix} не принимается, "
             f"файлы уйдут как {name}{ext}")
        return ext

    return None


async def _upload_asset(
    client: httpx.AsyncClient,
    target: dict[str, Any],
    upload_url: str,
    name: str,
    data: bytes,
    note: Callable[[str], None],
) -> tuple[httpx.Response, str]:
    """Загружает файл в релиз, подбирая состав тела и, если нужно, имя."""
    title = provider_title(target["provider"])

    # Если на прошлом файле выяснилось, что расширение не принимают,
    # сразу используем подобранное.
    known_ext = _ASSET_EXT.get(target["provider"])
    if known_ext and not name.endswith(known_ext):
        name = f"{name}{known_ext}"

    variants = _asset_variants(target, name, data)

    preferred = _ASSET_FORMAT.get(target["provider"])
    if preferred:
        variants.sort(key=lambda item: item[0] != preferred)

    last: httpx.Response | None = None
    for index, (label, kwargs) in enumerate(variants):
        attempts = 2 if index < 2 else 1
        for attempt in range(1, attempts + 1):
            try:
                response = await client.post(upload_url, **kwargs)
            except httpx.HTTPError as exc:
                note(f"{title}: «{label}» — обрыв связи ({exc})")
                last = None
                break

            if response.status_code < 400:
                if _ASSET_FORMAT.get(target["provider"]) != label:
                    _ASSET_FORMAT[target["provider"]] = label
                    note(f"{title}: файлы принимаются как «{label}»")
                return response, name

            last = response
            note(f"{title}: «{label}» — {_detail(response)}")
            if response.status_code >= 500 and attempt < attempts:
                await asyncio.sleep(3)
                continue
            break

        if last is not None and last.status_code in ASSET_STOP_CODES:
            break

    # Ни один способ не прошёл. Возможно, дело в расширении — подбираем другое
    # и пробуем ещё раз документированным способом.
    if target["provider"] != "github":
        ext = await _find_extension(client, target, upload_url, name, note)
        if ext:
            renamed = f"{name}{ext}"
            response = await client.post(
                upload_url,
                params={"name": renamed},
                files={"attachment": (renamed, data, "application/octet-stream")},
            )
            if response.status_code < 400:
                _ASSET_EXT[target["provider"]] = ext
                _ASSET_FORMAT[target["provider"]] = "attachment + name в адресе"
                note(f"{title}: {renamed} загружен")
                return response, renamed
            note(f"{title}: {renamed} тоже не принят — {_detail(response)}")

    hint, _suffix = await _probe_asset(client, target, upload_url, name)

    raise PublishError(
        f"{title}: файл {name} ({len(data) / 1024:.0f} КБ) не принят ни одним из "
        f"{len(variants)} способов. {hint}"
    )


def mirror_branch(target: dict[str, Any], default_branch: str | None) -> str:
    return (target.get("mirror_branch") or "").strip() or default_branch or "main"


def file_url(target: dict[str, Any], branch: str, name: str) -> str:
    """Прямая ссылка на файл в ветке репозитория."""
    web = PROVIDERS[target["provider"]]["web"]
    if target["provider"] == "github":
        return f"{web}/{target['repo']}/raw/{branch}/{name}"
    return f"{web}/{target['repo']}/raw/branch/{branch}/{name}"


async def _reset_branch(
    client: httpx.AsyncClient,
    target: dict[str, Any],
    branch: str,
    base: str | None,
    note: Callable[[str], None],
) -> bool:
    """Пересоздаёт ветку с файлами от вершины основной.

    Так в ветке остаётся пара свежих коммитов, а прошлые версии файлов
    становятся недостижимыми и вычищаются сборщиком мусора на стороне
    сервиса. Иначе каждый релиз добавлял бы к репозиторию полтора мегабайта
    навсегда.
    """
    if not base or branch == base:
        return False

    api = f"{_api(target)}/repos/{target['repo']}"
    try:
        head = await client.get(f"{api}/git/ref/heads/{base}", follow_redirects=True)
        if head.status_code >= 400:
            return False
        sha = ((head.json() or {}).get("object") or {}).get("sha")
        if not sha:
            return False

        await client.delete(f"{api}/git/refs/heads/{branch}")
        created = await client.post(
            f"{api}/git/refs", json={"ref": f"refs/heads/{branch}", "sha": sha}
        )
        if created.status_code >= 400:
            note(f"{provider_title(target['provider'])}: ветку {branch} "
                 f"пересоздать не вышло — {_detail(created)}")
            return False
    except Exception as exc:  # noqa: BLE001
        note(f"{provider_title(target['provider'])}: ветку {branch} не тронул ({exc})")
        return False

    note(f"{provider_title(target['provider'])}: ветка {branch} пересоздана")
    return True


async def mirror_to_repo(
    client: httpx.AsyncClient,
    target: dict[str, Any],
    files: list[dict[str, Any]],
    default_branch: str | None,
    tag: str,
    note: Callable[[str], None],
) -> list[str]:
    """Кладёт собранные файлы прямо в репозиторий и возвращает ссылки на них."""
    title = provider_title(target["provider"])
    branch = mirror_branch(target, default_branch)
    api = f"{_api(target)}/repos/{target['repo']}"

    await _reset_branch(client, target, branch, default_branch, note)

    links: list[str] = []
    for item in files:
        path = Path(item["path"])
        url = f"{api}/contents/{path.name}"
        note(f"{title}: кладу {path.name} в ветку {branch}")

        sha = None
        existing = await client.get(url, params={"ref": branch}, follow_redirects=True)
        if existing.status_code < 400:
            try:
                data = existing.json()
            except ValueError:
                data = {}
            if isinstance(data, list):
                data = next((i for i in data
                             if isinstance(i, dict) and i.get("name") == path.name), {})
            if isinstance(data, dict):
                sha = data.get("sha")

        payload: dict[str, Any] = {
            "message": f"{path.name}: релиз {tag}",
            "content": base64.b64encode(path.read_bytes()).decode("ascii"),
            "branch": branch,
        }
        if sha:
            payload["sha"] = sha

        response = await client.put(url, json=payload)
        if response.status_code >= 400:
            raise PublishError(
                f"{title}: не удалось записать {path.name} в репозиторий — "
                f"{_detail(response)}"
            )
        links.append(file_url(target, branch, path.name))

    note(f"{title}: файлы доступны в ветке {branch}")
    return links


async def _ensure_tag(
    client: httpx.AsyncClient,
    target: dict[str, Any],
    tag: str,
    branch: str | None,
    note: Callable[[str], None],
) -> bool:
    """Создаёт git-тег, если его ещё нет.

    GitHub заводит тег сам при создании релиза, а GitVerse требует, чтобы тег
    уже существовал. Релиз без настоящего тега создаётся, но оказывается
    неполноценным — и загрузка файлов в него не проходит.
    """
    title = provider_title(target["provider"])
    api = f"{_api(target)}/repos/{target['repo']}"

    try:
        existing = await client.get(f"{api}/git/ref/tags/{tag}", follow_redirects=True)
        if existing.status_code < 400:
            return True

        head_ref = f"heads/{branch}" if branch else "heads/master"
        head = await client.get(f"{api}/git/ref/{head_ref}", follow_redirects=True)
        if head.status_code >= 400:
            note(f"{title}: не нашёл вершину ветки для тега — {_detail(head)}")
            return False

        sha = ((head.json() or {}).get("object") or {}).get("sha")
        if not sha:
            return False

        created = await client.post(
            f"{api}/git/refs", json={"ref": f"refs/tags/{tag}", "sha": sha}
        )
        if created.status_code >= 400:
            note(f"{title}: тег {tag} создать не вышло — {_detail(created)}")
            return False
    except Exception as exc:  # noqa: BLE001
        note(f"{title}: тег {tag} не создан ({exc})")
        return False

    note(f"{title}: тег {tag} создан")
    return True


async def _create_release(
    client: httpx.AsyncClient,
    target: dict[str, Any],
    tag: str,
    branch: str | None,
    body: str,
    note: Callable[[str], None],
) -> tuple[dict[str, Any], str]:
    """Создаёт релиз.

    Временные ошибки сервиса (5xx) повторяются: GitHub периодически отвечает
    500, успев при этом создать релиз, поэтому перед повтором проверяем, не
    появился ли он. Конфликт тега разрешается следующим свободным номером.
    """
    title = provider_title(target["provider"])
    base = f"{_api(target)}/repos/{target['repo']}"
    candidate = await _resolve_tag(client, target, tag, note)
    delay = 2
    tagged: set[str] = set()

    for attempt in range(1, MAX_TAG_ATTEMPTS + 1):
        payload: dict[str, Any] = {
            "tag_name": candidate,
            "name": candidate,
            "body": body,
            "draft": False,
            "prerelease": False,
        }
        if branch:
            payload["target_commitish"] = branch

        if target["provider"] != "github" and candidate not in tagged:
            tagged.add(candidate)
            await _ensure_tag(client, target, candidate, branch, note)

        note(f"{title} ({target['repo']}): создаю релиз {candidate}")
        try:
            response = await client.post(f"{base}/releases", json=payload)
        except httpx.HTTPError as exc:
            if attempt > 3:
                raise PublishError(f"{title}: сеть недоступна — {exc}") from exc
            note(f"{title}: сбой связи, повтор через {delay} с")
            await asyncio.sleep(delay)
            delay *= 2
            continue

        if response.status_code < 400:
            return response.json(), candidate

        # Сервис мог создать релиз и всё равно ответить ошибкой.
        existing = await _find_release(client, base, candidate)
        if existing:
            note(f"{title}: релиз всё же создан, продолжаю")
            return existing, candidate

        if response.status_code >= 500 and attempt <= 3:
            note(f"{title}: сервис ответил {response.status_code}, повтор через {delay} с")
            await asyncio.sleep(delay)
            delay *= 2
            continue

        detail = _detail(response)
        if response.status_code in (409, 422):
            occupied = "already_exists" in detail or "already exists" in detail.lower()
            # Сюда мы попадаем только если релиза с таким тегом нет: его
            # наличие проверяется выше. Значит «уже существует» относится к
            # самому тегу, который мы и создали минуту назад, — переименовывать
            # релиз из-за этого неправильно. У GitHub тег и релиз неразделимы,
            # там перебор имени остаётся.
            if occupied and target["provider"] == "github":
                candidate = f"{tag}-{attempt + 1}"
                note(f"{title}: тег занят, пробую {candidate}")
                continue
            if occupied:
                raise PublishError(
                    f"{title}: {detail}. Тег {candidate} уже есть, а релиза на "
                    "нём нет — удалите тег в репозитории или дождитесь "
                    "следующей минуты."
                )
            raise PublishError(
                f"{title}: {detail}. Проверьте, что в репозитории есть хотя бы "
                "один коммит и у токена достаточно прав."
            )

        if response.status_code in (401, 403):
            raise PublishError(f"{title}: нет прав на создание релиза — {detail}")
        raise PublishError(f"{title}: {detail}")

    raise PublishError(f"{title}: не удалось подобрать свободный тег для {tag}")


async def _find_release(
    client: httpx.AsyncClient, base: str, tag: str
) -> dict[str, Any] | None:
    try:
        response = await client.get(f"{base}/releases/tags/{tag}", follow_redirects=True)
    except httpx.HTTPError:
        return None
    if response.status_code != 200:
        return None
    try:
        data = response.json()
    except ValueError:
        return None
    return data if isinstance(data, dict) and data.get("id") else None


def _release_url(target: dict[str, Any], release: dict[str, Any], tag: str) -> str:
    html = release.get("html_url")
    if html and target["provider"] == "github":
        return html
    web = PROVIDERS[target["provider"]]["web"]
    return f"{web}/{target['repo']}/releases/tag/{tag}"


async def publish_all(
    targets: list[dict[str, Any]],
    tag: str,
    files: list[dict[str, Any]],
    on_log: Callable[[str], None] | None = None,
    template: str = "",
    source_url: str = "",
    readme: str = "",
) -> tuple[list[dict[str, Any]], list[str]]:
    """Публикует во все цели. Сбой одной не отменяет остальные."""
    published: list[dict[str, Any]] = []
    errors: list[str] = []
    for target in targets:
        try:
            published.append(
                await publish_release(
                    target, tag, files, on_log, template, source_url, readme
                )
            )
        except PublishError as exc:
            errors.append(str(exc))
            if on_log:
                on_log(str(exc))
        except Exception as exc:  # noqa: BLE001
            message = f"{provider_title(target.get('provider', ''))}: {exc}"
            errors.append(message)
            if on_log:
                on_log(message)
    return published, errors
