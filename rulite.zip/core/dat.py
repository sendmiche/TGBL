"""Прямая работа с .dat-файлами через mmap, без разбора в память.

Формат geoip.dat и geosite.dat — это protobuf-сообщение вида
``repeated Entry entry = 1``, то есть просто последовательность блоков
«тег 0x0A + длина + содержимое». Внутри блока поле 1 — код категории,
поле 2 — повторяющиеся записи (домены или подсети).

Разбирать такой файл целиком дорого: 3,15 млн объектов занимают больше
гигабайта. Поэтому здесь файл только индексируется — по одному кортежу на
категорию, — а читается и пересобирается покусочно прямо из mmap. Расход
памяти не зависит от размера файла: страницы mmap отдаёт операционная
система и забирает обратно, когда ей нужна память.

Сборка выходного файла для категорий без исключений — побайтовое копирование
исходного блока, поэтому результат совпадает с тем, что выдал бы protobuf.
"""

from __future__ import annotations

import hashlib
import ipaddress
import json
import mmap
import os
import shutil
from pathlib import Path
from typing import Any, Callable, Iterator, NamedTuple

TYPE_KEYS = ("plain", "regex", "root", "full")
TYPE_KEY_BYTES = (b"plain", b"regex", b"root", b"full")
TYPE_LABELS = ("Plain", "Regex", "RootDomain", "Full")

INDEX_VERSION = 1


class DatError(RuntimeError):
    pass


class Category(NamedTuple):
    code: str
    count: int
    start: int    # начало блока, считая тег
    size: int     # длина блока целиком
    payload: int  # начало содержимого блока
    length: int   # длина содержимого


# --------------------------------------------------------------------------
# Примитивы формата
# --------------------------------------------------------------------------

def encode_varint(value: int) -> bytes:
    out = bytearray()
    while True:
        chunk = value & 0x7F
        value >>= 7
        out.append(chunk | (0x80 if value else 0))
        if not value:
            return bytes(out)


def varint_size(value: int) -> int:
    return max(1, (value.bit_length() + 6) // 7)


def encode_domain(type_index: int, value: bytes) -> bytes:
    """Запись Domain: поле 1 — тип, поле 2 — значение."""
    out = b""
    if type_index:  # proto3 не пишет нулевое значение
        out += b"\x08" + encode_varint(type_index)
    return out + b"\x12" + encode_varint(len(value)) + value


def encode_cidr(ip: bytes, prefix: int) -> bytes:
    """Запись CIDR: поле 1 — адрес, поле 2 — длина префикса."""
    out = b"\x0a" + encode_varint(len(ip)) + ip
    if prefix:
        out += b"\x10" + encode_varint(prefix)
    return out


def frame_record(payload: bytes) -> bytes:
    """Запись внутри категории — поле 2."""
    return b"\x12" + encode_varint(len(payload)) + payload


def frame_entry(code: str, records: bytes) -> bytes:
    """Готовый блок категории — поле 1 верхнего уровня."""
    raw = code.encode("utf-8")
    payload = b"\x0a" + encode_varint(len(raw)) + raw + records
    return b"\x0a" + encode_varint(len(payload)) + payload


def read_varint(buf, pos: int) -> tuple[int, int]:
    try:
        return _read_varint(buf, pos)
    except IndexError:
        raise DatError("Файл обрезан или повреждён") from None


def _read_varint(buf, pos: int) -> tuple[int, int]:
    result = buf[pos]
    pos += 1
    if result < 0x80:
        return result, pos
    result &= 0x7F
    shift = 7
    while True:
        byte = buf[pos]
        pos += 1
        result |= (byte & 0x7F) << shift
        if byte < 0x80:
            return result, pos
        shift += 7
        if shift > 63:
            raise DatError("Повреждённый varint")


def _skip_field(buf, pos: int, wire: int) -> int:
    if wire == 0:
        _, pos = read_varint(buf, pos)
        return pos
    if wire == 2:
        length, pos = read_varint(buf, pos)
        return pos + length
    if wire == 5:
        return pos + 4
    if wire == 1:
        return pos + 8
    raise DatError(f"Неизвестный тип поля: {wire}")


# --------------------------------------------------------------------------
# Файл
# --------------------------------------------------------------------------

class DatFile:
    def __init__(self, path: Path, kind: str) -> None:
        self.path = Path(path)
        self.kind = kind
        self._file = None
        self._mm: mmap.mmap | None = None
        self.categories: list[Category] = []
        self.by_code: dict[str, list[Category]] = {}
        self.total_entries = 0
        self._compose_cache: dict[tuple, tuple[int, int]] = {}
        self._filter_cache: dict[tuple, tuple[int, int]] = {}

    # --- жизненный цикл ---------------------------------------------------

    def open(self, on_progress: Callable[[int], None] | None = None) -> "DatFile":
        if not self.path.exists() or self.path.stat().st_size == 0:
            raise DatError(f"Файл {self.path.name} отсутствует или пуст")

        self._file = open(self.path, "rb")
        self._mm = mmap.mmap(self._file.fileno(), 0, access=mmap.ACCESS_READ)

        cached = self._load_index()
        if cached is None:
            self.categories = self._scan(on_progress)
            self._save_index()
        else:
            self.categories = cached

        self.by_code = {}
        for cat in self.categories:
            self.by_code.setdefault(cat.code, []).append(cat)
        self.total_entries = sum(c.count for c in self.categories)
        return self

    def close(self) -> None:
        if self._mm is not None:
            self._mm.close()
            self._mm = None
        if self._file is not None:
            self._file.close()
            self._file = None

    def __enter__(self) -> "DatFile":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    @property
    def mm(self) -> mmap.mmap:
        if self._mm is None:
            raise DatError("Файл не открыт")
        return self._mm

    @property
    def size(self) -> int:
        return self.path.stat().st_size

    # --- индекс -----------------------------------------------------------

    @property
    def index_path(self) -> Path:
        return self.path.with_suffix(".idx.json")

    def _stamp(self) -> dict[str, Any]:
        stat = self.path.stat()
        return {"size": stat.st_size, "mtime": int(stat.st_mtime_ns)}

    def _load_index(self) -> list[Category] | None:
        try:
            with open(self.index_path, encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, json.JSONDecodeError):
            return None
        if data.get("version") != INDEX_VERSION:
            return None
        if data.get("stamp") != self._stamp():
            return None
        try:
            return [Category(*row) for row in data["categories"]]
        except (KeyError, TypeError):
            return None

    def _save_index(self) -> None:
        payload = {
            "version": INDEX_VERSION,
            "kind": self.kind,
            "stamp": self._stamp(),
            "categories": [list(c) for c in self.categories],
        }
        tmp = self.index_path.with_suffix(".tmp")
        try:
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(payload, fh)
            os.replace(tmp, self.index_path)
        except OSError:
            pass  # индекс — только кэш, без него всё работает

    def _scan(self, on_progress: Callable[[int], None] | None = None) -> list[Category]:
        """Один проход по файлу: код категории и число записей в каждой."""
        buf = self.mm
        total = len(buf)
        pos = 0
        result: list[Category] = []
        next_report = total // 20 or total

        while pos < total:
            block_start = pos
            tag, pos = read_varint(buf, pos)
            if tag != 0x0A:
                raise DatError(
                    f"{self.path.name}: неожиданный тег {tag:#x} — "
                    "файл не похож на geoip.dat/geosite.dat"
                )
            length, pos = read_varint(buf, pos)
            payload = pos
            end = payload + length
            if end > total:
                raise DatError(f"{self.path.name}: файл обрезан")

            code, count = self._scan_entry(buf, payload, end)
            result.append(
                Category(code, count, block_start, end - block_start, payload, length)
            )
            pos = end

            if on_progress and pos >= next_report:
                on_progress(int(pos * 100 / total))
                next_report = pos + (total // 20 or total)

        return result

    @staticmethod
    def _scan_entry(buf, pos: int, end: int) -> tuple[str, int]:
        code = ""
        count = 0
        while pos < end:
            tag, pos = read_varint(buf, pos)
            field, wire = tag >> 3, tag & 7
            if wire == 2:
                length, pos = read_varint(buf, pos)
                if field == 2:
                    count += 1
                elif field == 1 and not code:
                    code = bytes(buf[pos : pos + length]).decode("utf-8", "replace")
                pos += length
            else:
                pos = _skip_field(buf, pos, wire)
        return code, count

    # --- чтение записей ---------------------------------------------------

    def _records(self, cat: Category) -> Iterator[tuple[int, int]]:
        """Смещения и длины записей (поле 2) внутри категории."""
        buf = self.mm
        pos, end = cat.payload, cat.payload + cat.length
        while pos < end:
            tag, pos = read_varint(buf, pos)
            field, wire = tag >> 3, tag & 7
            if wire == 2:
                length, pos = read_varint(buf, pos)
                if field == 2:
                    yield pos, length
                pos += length
            else:
                pos = _skip_field(buf, pos, wire)

    def _other_spans(self, cat: Category) -> list[tuple[int, int]]:
        """Всё, что не является записью, — копируем в новый блок как есть."""
        buf = self.mm
        spans: list[tuple[int, int]] = []
        pos, end = cat.payload, cat.payload + cat.length
        while pos < end:
            item_start = pos
            tag, pos = read_varint(buf, pos)
            field, wire = tag >> 3, tag & 7
            if wire == 2:
                length, pos = read_varint(buf, pos)
                pos += length
                if field != 2:
                    spans.append((item_start, pos))
            else:
                pos = _skip_field(buf, pos, wire)
                spans.append((item_start, pos))
        return spans

    def _decode_value(self, start: int, length: int) -> tuple[int, bytes]:
        """Возвращает (тип, значение) записи в сыром виде."""
        buf = self.mm
        pos, end = start, start + length
        kind_value = 0
        raw = b""
        while pos < end:
            tag, pos = read_varint(buf, pos)
            field, wire = tag >> 3, tag & 7
            if self.kind == "geosite":
                if field == 1 and wire == 0:
                    kind_value, pos = read_varint(buf, pos)
                    continue
                if field == 2 and wire == 2:
                    size, pos = read_varint(buf, pos)
                    raw = bytes(buf[pos : pos + size])
                    pos += size
                    continue
            else:
                if field == 1 and wire == 2:
                    size, pos = read_varint(buf, pos)
                    raw = bytes(buf[pos : pos + size])
                    pos += size
                    continue
                if field == 2 and wire == 0:
                    kind_value, pos = read_varint(buf, pos)
                    continue
            pos = _skip_field(buf, pos, wire)
        return kind_value, raw

    def _decode_fast(self, start: int, length: int) -> tuple[int, bytes] | None:
        """Разбор записи обычной формы одним махом.

        Подавляющее большинство записей закодировано канонически: у домена
        это «тип + значение», у подсети «адрес + префикс». Для них общий
        разбор по циклу избыточен. Всё, что не укладывается в эту форму
        (например, домены с атрибутами), уходит в полный разбор.
        """
        buf = self.mm
        end = start + length
        pos = start

        if self.kind == "geosite":
            type_index = 0
            if buf[pos] == 0x08:
                type_index = buf[pos + 1]
                if type_index > 0x7F:
                    return None
                pos += 2
            if pos < end and buf[pos] == 0x12:
                size = buf[pos + 1]
                if size < 0x80 and pos + 2 + size == end:
                    return type_index, bytes(buf[pos + 2 : end])
            return None

        if buf[pos] == 0x0A:
            size = buf[pos + 1]
            if size < 0x80:
                ip_end = pos + 2 + size
                if ip_end == end:
                    return 0, bytes(buf[pos + 2 : ip_end])
                if ip_end + 2 == end and buf[ip_end] == 0x10:
                    prefix = buf[ip_end + 1]
                    if prefix < 0x80:
                        return prefix, bytes(buf[pos + 2 : ip_end])
        return None

    def key_bytes(self, start: int, length: int) -> bytes:
        """Ключ записи в сыром виде.

        Сравнение и фильтрация идут по байтам: на файлах в миллионы записей
        создание строки для каждой из них съедает больше времени, чем сам
        разбор.
        """
        decoded = self._decode_fast(start, length) or self._decode_value(start, length)
        kind_value, raw = decoded
        if self.kind == "geosite":
            label = (
                TYPE_KEY_BYTES[kind_value]
                if kind_value < len(TYPE_KEY_BYTES)
                else b"plain"
            )
            return label + b":" + raw
        return cidr_bytes(raw, kind_value)

    def record_key(self, start: int, length: int) -> str:
        return self.key_bytes(start, length).decode("utf-8", "replace")

    def _match_bytes(self, start: int, length: int) -> bytes:
        """То, по чему ищем внутри категории: домен или адрес подсети."""
        kind_value, raw = (
            self._decode_fast(start, length) or self._decode_value(start, length)
        )
        if self.kind == "geosite":
            return raw
        return cidr_bytes(raw, kind_value)

    def record_view(self, start: int, length: int) -> dict[str, Any]:
        kind_value, raw = (
            self._decode_fast(start, length) or self._decode_value(start, length)
        )
        if self.kind == "geosite":
            index = kind_value if kind_value < len(TYPE_KEYS) else 0
            value = raw.decode("utf-8", "replace")
            return {
                "key": f"{TYPE_KEYS[index]}:{value}",
                "value": value,
                "type": TYPE_LABELS[index],
                "typeClass": TYPE_KEYS[index],
            }
        value = format_cidr(raw, kind_value)
        is_v6 = ":" in value
        return {
            "key": value,
            "value": value,
            "type": "IPv6" if is_v6 else "IPv4",
            "typeClass": "regex" if is_v6 else "plain",
        }

    # --- выдача в интерфейс ----------------------------------------------

    def count(self, code: str) -> int:
        return sum(c.count for c in self.by_code.get(code, ()))

    def entries(
        self, code: str, query: str = "", offset: int = 0, limit: int = 200
    ) -> tuple[list[dict[str, Any]], int]:
        cats = self.by_code.get(code)
        if not cats:
            return [], 0

        # Категорию могли найти по её названию — тогда фильтровать записи
        # тем же запросом неверно: показываем содержимое целиком.
        if query and query.lower() in code.lower():
            query = ""

        if not query:
            total = sum(c.count for c in cats)
            items: list[dict[str, Any]] = []
            skipped = 0
            for cat in cats:
                if skipped + cat.count <= offset:
                    skipped += cat.count
                    continue
                for start, length in self._records(cat):
                    if skipped < offset:
                        skipped += 1
                        continue
                    items.append(self.record_view(start, length))
                    if len(items) >= limit:
                        return items, total
            return items, total

        needle = query.lower().encode("utf-8", "replace")
        matched: list[dict[str, Any]] = []
        total = 0
        window = range(offset, offset + limit)
        for cat in cats:
            for start, length in self._records(cat):
                if needle not in self._match_bytes(start, length).lower():
                    continue
                if total in window:
                    matched.append(self.record_view(start, length))
                total += 1
        return matched, total

    def search(self, query: str) -> list[str]:
        """Категории, где встречается подстрока. Поиск идёт по сырым байтам."""
        if not query:
            return [c.code for c in self.categories]

        needle = query.lower().encode("utf-8", "replace")
        alt = query.encode("utf-8", "replace")
        buf = self.mm
        found: list[str] = []
        seen: set[str] = set()

        for cat in self.categories:
            if cat.code in seen:
                continue
            end = cat.payload + cat.length
            if query.lower() in cat.code.lower():
                found.append(cat.code)
                seen.add(cat.code)
                continue
            hit = buf.find(needle, cat.payload, end)
            if hit < 0 and alt != needle:
                hit = buf.find(alt, cat.payload, end)
            if hit >= 0:
                found.append(cat.code)
                seen.add(cat.code)
        return found

    # --- свои категории ---------------------------------------------------

    def compose(
        self,
        code: str,
        sources: list[str],
        manual: list[tuple[str, bytes]],
        excluded: dict[str, set[str]] | None = None,
    ) -> tuple[bytes, int]:
        """Собирает блок своей категории из чужих записей и собственных.

        Повторы убираются: одна и та же запись, встретившаяся в нескольких
        объединяемых категориях, попадёт в файл один раз.
        """
        excluded = {
            code: self._drop_bytes(keys) for code, keys in (excluded or {}).items()
        }
        buf = self.mm
        seen: set[bytes] = set()
        parts: list[bytes] = []

        for source in sources:
            drop = excluded.get(source) or set()
            for cat in self.by_code.get(source, ()):
                for start, length in self._records(cat):
                    key = self.key_bytes(start, length)
                    if key in drop or key in seen:
                        continue
                    seen.add(key)
                    parts.append(
                        b"\x12" + encode_varint(length) + bytes(buf[start : start + length])
                    )

        for key, payload in manual:
            raw_key = key.encode("utf-8") if isinstance(key, str) else key
            if raw_key in seen:
                continue
            seen.add(raw_key)
            parts.append(frame_record(payload))

        if not parts:
            return b"", 0
        return frame_entry(code, b"".join(parts)), len(parts)

    def compose_size(
        self,
        code: str,
        sources: list[str],
        manual: list[tuple[str, bytes]],
        excluded: dict[str, set[str]] | None = None,
    ) -> tuple[int, int]:
        """Размер и число записей без удержания собранных байтов в памяти."""
        signature = (
            code,
            tuple(sources),
            tuple(key for key, _ in manual),
            tuple(sorted((c, len(k)) for c, k in (excluded or {}).items() if c in sources)),
        )
        cached = self._compose_cache.get(signature)
        if cached is not None:
            return cached

        block, count = self.compose(code, sources, manual, excluded)
        result = (len(block), count)
        del block
        if len(self._compose_cache) > 8:
            self._compose_cache.clear()
        self._compose_cache[signature] = result
        return result

    def locate(self, key: str) -> list[str]:
        """В каких ещё категориях встречается ровно эта запись.

        Сначала грубый отсев: ищем байты записи в диапазоне категории
        средствами mmap — это работает на скорости memchr. Полный разбор
        достаётся только категориям-кандидатам.
        """
        if self.kind == "geosite":
            probe = (key.split(":", 1)[1] if ":" in key else key).encode("utf-8")
        else:
            address, _, prefix = key.partition("/")
            try:
                packed = ipaddress.ip_address(address).packed
            except ValueError:
                return []
            probe = encode_cidr(packed, int(prefix or 0))

        target = key.encode("utf-8")
        buf = self.mm
        found: list[str] = []
        seen: set[str] = set()

        for cat in self.categories:
            if cat.code in seen:
                continue
            if buf.find(probe, cat.payload, cat.payload + cat.length) < 0:
                continue
            for start, length in self._records(cat):
                if self.key_bytes(start, length) == target:
                    found.append(cat.code)
                    seen.add(cat.code)
                    break
        return found

    def overlap(self, code: str, limit: int = 60) -> dict[str, Any]:
        """Сколько записей выбранной категории встречается в каждой другой.

        Один проход по файлу: ключи выбранной категории держим в множестве,
        остальные записи сверяем с ним по байтам. Ответ показывает, какие
        категории вложены друг в друга, — по нему видно, что можно объединять
        без роста файла.
        """
        cats = self.by_code.get(code)
        if not cats:
            return {"code": code, "count": 0, "items": []}

        target = {
            self.key_bytes(start, length)
            for cat in cats
            for start, length in self._records(cat)
        }
        if not target:
            return {"code": code, "count": 0, "items": []}

        shared: dict[str, int] = {}
        totals: dict[str, int] = {}
        for cat in self.categories:
            if cat.code == code:
                continue
            totals[cat.code] = totals.get(cat.code, 0) + cat.count
            hits = 0
            for start, length in self._records(cat):
                if self.key_bytes(start, length) in target:
                    hits += 1
            if hits:
                shared[cat.code] = shared.get(cat.code, 0) + hits

        size = len(target)
        items = [
            {
                "code": other,
                "shared": hits,
                "count": totals.get(other, 0),
                # Доля выбранной категории, покрытая этой, и наоборот.
                "ofTarget": round(hits * 100 / size, 1),
                "ofOther": round(hits * 100 / totals[other], 1) if totals.get(other) else 0.0,
            }
            for other, hits in shared.items()
        ]
        items.sort(key=lambda item: (-item["shared"], item["code"]))
        return {"code": code, "count": size, "items": items[:limit]}

    # --- оценка и сборка --------------------------------------------------

    def plan(
        self,
        disabled: set[str],
        excluded: dict[str, set[str]],
        custom: list[dict[str, Any]] | None = None,
    ) -> dict[str, int]:
        """Точный размер будущего файла без его записи."""
        excluded = {code: self._drop_bytes(keys) for code, keys in excluded.items()}
        total_bytes = 0
        kept_entries = 0
        kept_categories = 0
        seen: set[str] = set()

        for cat in self.categories:
            if cat.code in disabled:
                continue
            drop = excluded.get(cat.code)
            if not drop:
                total_bytes += cat.size
                kept_entries += cat.count
                if cat.code not in seen:
                    kept_categories += 1
                    seen.add(cat.code)
                continue

            payload_len, count = self._filtered_size(cat, drop)
            if count == 0:
                continue
            total_bytes += 1 + varint_size(payload_len) + payload_len
            kept_entries += count
            if cat.code not in seen:
                kept_categories += 1
                seen.add(cat.code)

        custom_entries = 0
        custom_categories = 0
        for item in custom or []:
            size, count = self.compose_size(
                item["code"], item["sources"], item["records"], excluded
            )
            if count:
                total_bytes += size
                kept_entries += count
                kept_categories += 1
                custom_entries += count
                custom_categories += 1

        return {
            "bytes": total_bytes,
            "entries": kept_entries,
            "categories": kept_categories,
            # Свои категории считаем отдельно: они добавляют записи, а не
            # отбирают, и мешать их с отбором из источника нельзя.
            "customEntries": custom_entries,
            "customCategories": custom_categories,
        }

    @staticmethod
    def _drop_bytes(drop) -> set[bytes]:
        return {k.encode("utf-8") if isinstance(k, str) else k for k in drop}

    def _filtered_size(self, cat: Category, drop: set[bytes]) -> tuple[int, int]:
        signature = (cat.start, len(drop), hash(frozenset(drop)))
        cached = self._filter_cache.get(signature)
        if cached is not None:
            return cached
        if len(self._filter_cache) > 64:
            self._filter_cache.clear()

        payload_len = sum(end - start for start, end in self._other_spans(cat))
        count = 0
        for start, length in self._records(cat):
            if self.key_bytes(start, length) in drop:
                continue
            payload_len += 1 + varint_size(length) + length
            count += 1

        self._filter_cache[signature] = (payload_len, count)
        return payload_len, count

    def build(
        self,
        out_path: Path,
        disabled: set[str],
        excluded: dict[str, set[str]],
        on_progress: Callable[[int], None] | None = None,
        custom: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """Пишет отфильтрованный файл, копируя нетронутые категории как есть."""
        buf = self.mm
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = out_path.with_suffix(".part")

        excluded = {code: self._drop_bytes(keys) for code, keys in excluded.items()}
        digest = hashlib.sha256()
        written = 0
        kept_entries = 0
        codes: set[str] = set()
        total = len(self.categories) or 1

        with open(tmp, "wb") as fh:
            for number, cat in enumerate(self.categories, 1):
                if cat.code in disabled:
                    continue
                drop = excluded.get(cat.code)

                if not drop:
                    block = buf[cat.start : cat.start + cat.size]
                    kept = cat.count
                else:
                    parts = [
                        bytes(buf[start:end]) for start, end in self._other_spans(cat)
                    ]
                    kept = 0
                    for start, length in self._records(cat):
                        if self.key_bytes(start, length) in drop:
                            continue
                        parts.append(
                            b"\x12" + encode_varint(length) + bytes(buf[start : start + length])
                        )
                        kept += 1
                    if kept == 0:
                        # Пустая категория ломает загрузку правил в Xray.
                        continue
                    payload = b"".join(parts)
                    block = b"\x0a" + encode_varint(len(payload)) + payload
                    del parts, payload

                fh.write(block)
                digest.update(block)
                written += len(block)
                kept_entries += kept
                codes.add(cat.code)
                del block

                if on_progress and number % 50 == 0:
                    on_progress(int(number * 100 / total))

            for item in custom or []:
                block, count = self.compose(
                    item["code"], item["sources"], item["records"], excluded
                )
                if not count:
                    continue
                fh.write(block)
                digest.update(block)
                written += len(block)
                kept_entries += count
                codes.add(item["code"])
                del block

        shutil.move(str(tmp), str(out_path))
        return {
            "kind": self.kind,
            "path": str(out_path),
            "size": written,
            "sha256": digest.hexdigest(),
            "categories": len(codes),
            "entries": kept_entries,
            "codes": sorted(codes),
        }


# --------------------------------------------------------------------------

def cidr_bytes(raw: bytes, prefix: int) -> bytes:
    """IPv4 собираем вручную: ipaddress на миллионе записей заметно дороже."""
    if len(raw) == 4:
        return b"%d.%d.%d.%d/%d" % (raw[0], raw[1], raw[2], raw[3], prefix)
    return format_cidr(raw, prefix).encode("utf-8")


def format_cidr(raw: bytes, prefix: int) -> str:
    if len(raw) == 4:
        return f"{raw[0]}.{raw[1]}.{raw[2]}.{raw[3]}/{prefix}"
    try:
        return f"{ipaddress.ip_address(raw)}/{prefix}"
    except ValueError:
        return f"{raw.hex()}/{prefix}"


def verify(path: Path) -> int:
    """Быстрая проверка целостности: проходит только по верхним блокам."""
    path = Path(path)
    if not path.exists() or path.stat().st_size == 0:
        raise DatError("Файл пуст")
    with open(path, "rb") as fh:
        with mmap.mmap(fh.fileno(), 0, access=mmap.ACCESS_READ) as buf:
            total = len(buf)
            pos = 0
            blocks = 0
            while pos < total:
                tag, pos = read_varint(buf, pos)
                if tag != 0x0A:
                    raise DatError(f"Неожиданный тег {tag:#x}")
                length, pos = read_varint(buf, pos)
                pos += length
                if pos > total:
                    raise DatError("Файл обрезан")
                blocks += 1
    return blocks
