"""Уведомления в Telegram через Bot API.

Отправка намеренно «мягкая»: любая ошибка telegram пишется в лог, но никогда
не роняет сборку и не отменяет публикацию.
"""

from __future__ import annotations

import html
import logging
from typing import Any

import httpx

from .config import NOTIFY_EVENTS, store

log = logging.getLogger("rulite.notify")

API = "https://api.telegram.org"
TIMEOUT = 20


class NotifyError(RuntimeError):
    pass


def escape(text: Any) -> str:
    return html.escape(str(text), quote=False)


def _settings() -> dict[str, Any]:
    return store.telegram()


def enabled_for(event: str) -> bool:
    block = _settings()
    if not block.get("enabled") or not block.get("token") or not block.get("chat_id"):
        return False
    return bool((block.get("events") or {}).get(event, False))


async def _send(token: str, chat_id: str, text: str, silent: bool = False) -> dict[str, Any]:
    payload = {
        "chat_id": chat_id,
        "text": text,
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
        "disable_notification": silent,
    }
    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        response = await client.post(f"{API}/bot{token}/sendMessage", json=payload)

    try:
        data = response.json()
    except ValueError:
        raise NotifyError(f"Telegram ответил кодом {response.status_code}") from None

    if not data.get("ok"):
        description = data.get("description") or f"код {response.status_code}"
        raise NotifyError(f"Telegram: {description}")
    return data


async def notify(event: str, title: str, lines: list[str] | None = None) -> None:
    """Отправляет уведомление, если событие включено в настройках."""
    if not enabled_for(event):
        return
    block = _settings()
    body = [f"<b>{escape(title)}</b>"]
    if lines:
        body.append("")
        body.extend(escape(line) for line in lines)
    try:
        await _send(
            block["token"],
            str(block["chat_id"]),
            "\n".join(body),
            silent=event in ("no_updates", "startup"),
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("Не удалось отправить уведомление (%s): %s", event, exc)


async def send_test(token: str, chat_id: str) -> dict[str, Any]:
    """Проверка настроек: отправляет пробное сообщение и возвращает имя чата."""
    if not token or not chat_id:
        raise NotifyError("Заполните токен бота и идентификатор чата")

    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        me = await client.get(f"{API}/bot{token}/getMe")
    try:
        me_data = me.json()
    except ValueError:
        raise NotifyError(f"Telegram ответил кодом {me.status_code}") from None
    if not me_data.get("ok"):
        raise NotifyError(
            f"Токен бота отклонён: {me_data.get('description') or me.status_code}"
        )

    result = await _send(
        token,
        str(chat_id),
        "<b>❤️ RULITE</b>\n\nУведомления настроены — это проверочное сообщение.",
    )
    chat = (result.get("result") or {}).get("chat") or {}
    return {
        "bot": (me_data.get("result") or {}).get("username") or "bot",
        "chat": chat.get("title") or chat.get("username") or chat.get("first_name") or chat_id,
    }


def event_titles() -> dict[str, str]:
    return dict(NOTIFY_EVENTS)
