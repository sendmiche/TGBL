"""Фоновый воркер: проверка обновлений, сборка и публикация."""

from __future__ import annotations

import asyncio
import gc
import logging
import uuid
from collections import deque
from datetime import datetime, timezone
from typing import Any

from apscheduler.schedulers.asyncio import AsyncIOScheduler

from . import geodata, notes, notify, publish
from .config import KINDS, store

try:
    from zoneinfo import ZoneInfo
except ImportError:  # pragma: no cover
    ZoneInfo = None  # type: ignore

log = logging.getLogger("rulite.worker")

LOG_BUFFER: deque[dict[str, str]] = deque(maxlen=200)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def human_size(size: int) -> str:
    if size >= 1048576:
        return f"{size / 1048576:.2f} МБ"
    if size >= 1024:
        return f"{size / 1024:.1f} КБ"
    return f"{size} Б"


def add_log(message: str, level: str = "info") -> None:
    LOG_BUFFER.append({"time": _now(), "level": level, "message": message})
    log.log(logging.ERROR if level == "error" else logging.INFO, message)


class Job:
    def __init__(self, title: str) -> None:
        self.id = uuid.uuid4().hex[:12]
        self.title = title
        self.status = "running"  # running | done | error
        self.progress = 0
        self.step = "Запуск"
        self.error: str | None = None
        self.result: dict[str, Any] = {}
        self.lines: list[dict[str, str]] = []
        self.started_at = _now()

    def log(self, message: str, level: str = "info") -> None:
        add_log(message, level)
        self.lines.append(LOG_BUFFER[-1])
        del self.lines[:-100]

    def advance(self, progress: int, step: str) -> None:
        self.progress = progress
        self.step = step
        self.log(step)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "status": self.status,
            "progress": self.progress,
            "step": self.step,
            "error": self.error,
            "result": self.result,
            "lines": self.lines,
            "startedAt": self.started_at,
        }


class Pipeline:
    """Единая точка запуска: одновременно выполняется одна задача."""

    def __init__(self) -> None:
        self.jobs: dict[str, Job] = {}
        self.current: Job | None = None
        self.last: Job | None = None
        self._lock = asyncio.Lock()
        self.scheduler: AsyncIOScheduler | None = None
        self._interval: int | None = None

    def get(self, job_id: str) -> Job | None:
        return self.jobs.get(job_id)

    @property
    def busy(self) -> bool:
        return self._lock.locked()

    def _remember(self, job: Job) -> None:
        self.jobs[job.id] = job
        if len(self.jobs) > 20:
            oldest = sorted(self.jobs.values(), key=lambda j: j.started_at)[0]
            self.jobs.pop(oldest.id, None)

    def _tz(self):
        name = (store.config.get("publish") or {}).get("timezone") or "UTC"
        if ZoneInfo is None:
            return timezone.utc
        try:
            return ZoneInfo(name)
        except Exception:
            return timezone.utc

    def release_tag(self) -> str:
        return datetime.now(self._tz()).strftime("%d%m%Y%H%M")

    # --- запуск ----------------------------------------------------------

    def start(
        self,
        title: str,
        *,
        force_download: bool = False,
        build: bool = True,
        publish_release: bool = False,
        only_if_changed: bool = False,
    ) -> Job:
        job = Job(title)
        self._remember(job)
        asyncio.create_task(
            self._guarded(
                job,
                force_download=force_download,
                build=build,
                publish_release=publish_release,
                only_if_changed=only_if_changed,
            )
        )
        return job

    async def _guarded(self, job: Job, **kwargs) -> None:
        if self.busy:
            job.log("Ожидаю завершения предыдущей задачи")
        async with self._lock:
            self.current = job
            try:
                await self._run(job, **kwargs)
                job.status = "done"
                job.progress = 100
                if job.step == "Запуск":
                    job.step = "Готово"
            except Exception as exc:  # noqa: BLE001
                job.status = "error"
                job.error = str(exc)
                job.log(f"Ошибка: {exc}", level="error")
                log.exception("Задача %s завершилась с ошибкой", job.id)
                await notify.notify(
                    "errors", "⚠️ RULITE: задача завершилась с ошибкой",
                    [job.title, str(exc)],
                )
            finally:
                self.current = None
                self.last = job
                gc.collect()
                store.record_run(
                    {
                        "at": job.started_at,
                        "title": job.title,
                        "status": job.status,
                        "error": job.error,
                        "result": job.result,
                    }
                )

    async def _run(
        self,
        job: Job,
        *,
        force_download: bool,
        build: bool,
        publish_release: bool,
        only_if_changed: bool,
    ) -> None:
        job.advance(3, "Проверяю обновления исходных файлов")
        changed: list[str] = []
        # Каждому файлу — свой отрезок шкалы: проверка, скачивание, индексация.
        span = 60 // max(1, len(KINDS))

        async with geodata.make_client() as client:
            for number, kind in enumerate(KINDS):
                base = 5 + number * span

                if not geodata.geo.loaded(kind) and geodata.cache_path(kind).exists():
                    job.advance(base, f"{kind}.dat: читаю из кэша")
                    await asyncio.to_thread(geodata.geo.load, kind)

                try:
                    meta = await geodata.check_source(kind, client)
                except Exception as exc:  # noqa: BLE001
                    # У части ошибок httpx пустой текст — показываем хотя бы тип.
                    reason = str(exc) or type(exc).__name__
                    job.log(f"{kind}.dat: источник недоступен — {reason}", level="error")
                    if not geodata.geo.loaded(kind):
                        raise
                    continue

                needs = (
                    force_download
                    or not geodata.geo.loaded(kind)
                    or geodata.source_changed(kind, meta)
                )
                if not needs:
                    job.advance(base + span, f"{kind}.dat: без изменений")
                    store.state["sources"].setdefault(kind, {})["checked_at"] = _now()
                    continue

                def download_progress(done: int, total: int, percent: int, _k=kind,
                                      _base=base, _span=span) -> None:
                    job.progress = _base + int(_span * 0.6 * percent / 100)
                    job.step = (
                        f"{_k}.dat: скачиваю {done / 1048576:.1f} "
                        f"из {total / 1048576:.1f} МБ"
                    )

                job.advance(base, f"{kind}.dat: скачиваю")
                downloaded = await geodata.download_source(
                    kind, client, download_progress
                )
                known = store.state["sources"].get(kind) or {}
                job.log(f"{kind}.dat: получено {human_size(downloaded['size'])}")

                if downloaded["sha256"] == known.get("sha256") and geodata.cache_path(kind).exists():
                    job.log(f"{kind}.dat: содержимое не изменилось")
                else:
                    changed.append(kind)

                def index_progress(percent: int, _k=kind, _base=base, _span=span) -> None:
                    job.progress = _base + int(_span * 0.6) + int(_span * 0.4 * percent / 100)
                    job.step = f"{_k}.dat: строю индекс, {percent}%"

                job.advance(
                    base + int(span * 0.6), f"{kind}.dat: строю индекс"
                )
                await asyncio.to_thread(geodata.geo.load, kind, index_progress)
                totals = geodata.geo.totals(kind)
                job.log(
                    f"{kind}.dat готов: {totals['categories']} категорий, "
                    f"{totals['entries']} записей"
                )

                downloaded["updated_at"] = _now()
                downloaded["checked_at"] = _now()
                store.state["sources"][kind] = downloaded

        store.save_state()

        for kind in KINDS:
            fresh = await asyncio.to_thread(geodata.sync_new_categories, kind)
            if fresh:
                job.log(
                    f"{kind}: новых категорий — {len(fresh)}. "
                    "Они выключены и подсвечены в интерфейсе."
                )
                await notify.notify(
                    "new_categories", f"🆕 {kind}: новых категорий — {len(fresh)}",
                    ["Они выключены до вашего решения.", ", ".join(fresh[:30])]
                    + (["…"] if len(fresh) > 30 else []),
                )

        job.result["changed"] = changed

        if changed:
            await notify.notify(
                "sources_updated", "🔄 Исходные файлы обновились",
                [f"Обновлены: {', '.join(changed)}"]
                + [
                    f"{kind}: {geodata.geo.totals(kind)['categories']} категорий, "
                    f"{geodata.geo.totals(kind)['entries']} записей"
                    for kind in changed
                    if geodata.geo.loaded(kind)
                ],
            )

        if only_if_changed and not changed:
            job.advance(100, "Обновлений нет — пересборка не нужна")
            await notify.notify(
                "no_updates", "Плановая проверка: обновлений нет",
                ["Исходные файлы не менялись, релиз не создавался."],
            )
            return

        if not build:
            if changed:
                job.advance(
                    100,
                    f"Обновлены: {', '.join(changed)}. Нажмите «Сохранить настройки "
                    "и запустить сборку», чтобы пересобрать файлы",
                )
            else:
                job.advance(100, "Обновлений нет — исходные файлы актуальны")
            return

        if not geodata.geo.ready:
            raise RuntimeError(
                "Не все исходные файлы загружены: " + ", ".join(geodata.geo.missing())
            )

        job.advance(70, "Собираю файлы")
        built = []
        for number, kind in enumerate(KINDS):
            base = 70 + number * (20 // max(1, len(KINDS)))

            def build_progress(percent: int, _k=kind, _base=base) -> None:
                job.progress = _base + int(10 * percent / 100)
                job.step = f"{_k}.dat: собираю, {percent}%"

            info = await asyncio.to_thread(
                geodata.geo.build, kind, store.selection(kind), build_progress
            )
            built.append(info)
            job.log(
                f"{kind}.dat собран: {info['categories']} категорий, "
                f"{info['entries']} записей, {human_size(info['size'])}"
            )

        store.state["last_build"] = {"at": _now(), "files": built}
        store.save_state()
        job.result["files"] = built

        if not publish_release:
            job.advance(100, "Файлы собраны, публикация не запрашивалась")
            await notify.notify(
                "build_done", "📦 Файлы пересобраны",
                [
                    f"{item['kind']}.dat — {item['categories']} категорий, "
                    f"{item['entries']} записей, {human_size(item['size'])}"
                    for item in built
                ],
            )
            return

        targets = store.targets(only_ready=True)
        if not targets:
            job.advance(100, "Файлы собраны. Репозитории не настроены — релиз не создан")
            return

        job.advance(92, f"Публикую релиз ({len(targets)} шт.)")
        tag = self.release_tag()
        template = notes.pick(store.release_notes())
        published, errors = await publish.publish_all(
            targets,
            tag,
            built,
            job.log,
            template=template,
            source_url=notes.source_page(store.source_url("geosite")),
            readme=(
                store.readme().get("text") or notes.DEFAULT_README
                if store.readme().get("enabled", True)
                else ""
            ),
        )

        if published:
            record = {
                "at": _now(),
                "tag": tag,
                "targets": published,
                "files": [
                    {"name": f"{f['kind']}.dat", "size": f["size"], "sha256": f["sha256"]}
                    for f in built
                ],
            }
            releases = store.state.setdefault("releases", [])
            releases.insert(0, record)
            del releases[20:]
            store.save_state()
            job.result["release"] = record
            await notify.notify(
                "release", f"🚀 Релиз {tag} опубликован",
                [
                    f"{item['kind']}.dat — {item['categories']} категорий, "
                    f"{item['entries']} записей, {human_size(item['size'])}"
                    for item in built
                ]
                + [""]
                + [
                    f"{t['title']}: {t['url']}"
                    + ("".join(f"\n{link}" for link in t.get("mirrored") or []))
                    for t in published
                ]
                + ([f"Не удалось: {'; '.join(errors)}"] if errors else []),
            )

        for item in published:
            if item.get("assetError"):
                job.log(
                    f"{item['title']}: вложения релиза не приняты "
                    f"({item['assetError']}), файлы опубликованы в репозитории",
                    level="error",
                )

        if errors and not published:
            raise RuntimeError("; ".join(errors))
        if errors:
            job.advance(100, f"Опубликовано частично. Ошибки: {'; '.join(errors)}")
        else:
            job.advance(100, f"Релиз {tag} опубликован")

    # --- расписание ------------------------------------------------------

    def _interval_minutes(self) -> int:
        return max(5, int(store.config["schedule"].get("interval_minutes") or 60))

    def setup_scheduler(self) -> None:
        minutes = self._interval_minutes()
        self._interval = minutes
        self.scheduler = AsyncIOScheduler()
        self.scheduler.add_job(
            self.scheduled_cycle,
            "interval",
            minutes=minutes,
            id="rulite-check",
            max_instances=1,
            coalesce=True,
        )
        self.scheduler.start()
        add_log(f"Планировщик запущен, интервал — {minutes} мин.")

    async def scheduled_cycle(self) -> None:
        """Плановый прогон: собирает и публикует только при реальном обновлении."""
        if self.busy:
            add_log("Плановая проверка пропущена: идёт другая задача")
            return
        auto = bool((store.config.get("publish") or {}).get("auto", True))
        self.start(
            "Плановая проверка обновлений",
            build=True,
            publish_release=auto,
            force_download=False,
            only_if_changed=True,
        )

    def reschedule(self) -> None:
        minutes = self._interval_minutes()
        if not self.scheduler or minutes == self._interval:
            return
        self._interval = minutes
        self.scheduler.reschedule_job("rulite-check", trigger="interval", minutes=minutes)
        add_log(f"Интервал проверки изменён на {minutes} мин.")

    def shutdown(self) -> None:
        if self.scheduler:
            self.scheduler.shutdown(wait=False)
        geodata.geo.close_all()


pipeline = Pipeline()


async def bootstrap() -> None:
    """Открываем то, что уже лежит в кэше, и досказываем недостающее."""
    add_log("Запуск RULITE")

    for kind in KINDS:
        try:
            if await asyncio.to_thread(geodata.geo.load, kind):
                totals = geodata.geo.totals(kind)
                add_log(
                    f"{kind}.dat из кэша: {totals['categories']} категорий, "
                    f"{totals['entries']} записей"
                )
        except Exception as exc:  # noqa: BLE001
            add_log(f"Не удалось прочитать кэш {kind}.dat: {exc}", level="error")
            geodata.geo.unload(kind)

    pipeline.setup_scheduler()

    await notify.notify(
        "startup", "▶️ RULITE запущен",
        [
            f"{kind}: "
            + (
                f"{geodata.geo.totals(kind)['categories']} категорий"
                if geodata.geo.loaded(kind)
                else "нет данных, скачиваю"
            )
            for kind in KINDS
        ],
    )

    missing = geodata.geo.missing()
    if missing:
        add_log(f"Нет данных: {', '.join(missing)}. Скачиваю исходные файлы")
        pipeline.start("Первичная загрузка", build=False, publish_release=False)
