"""Загрузка исходников и доступ к ним через индексированные .dat-файлы.

Файлы не разбираются в память: вся работа идёт через core.dat поверх mmap.
Благодаря этому расход памяти не зависит от размера geosite.dat.
"""

from __future__ import annotations

import contextlib
import hashlib
import logging
import shutil
import threading
from pathlib import Path
from typing import Any, Callable, Iterable

import httpx

from . import custom as custom_mod
from . import dat
from .config import BUILD_DIR, CACHE_DIR, KINDS, store

log = logging.getLogger("rulite.geodata")

USER_AGENT = "RULITE/2.0"


def cache_path(kind: str) -> Path:
    return CACHE_DIR / f"{kind}.dat"


def build_path(kind: str) -> Path:
    return BUILD_DIR / f"{kind}.dat"


# --------------------------------------------------------------------------
# Реестр открытых файлов
# --------------------------------------------------------------------------

class GeoStore:
    def __init__(self) -> None:
        self.lock = threading.RLock()
        self.files: dict[str, dat.DatFile | None] = {kind: None for kind in KINDS}

    # --- состояние --------------------------------------------------------

    def loaded(self, kind: str) -> bool:
        return self.files.get(kind) is not None

    @property
    def ready(self) -> bool:
        return all(self.loaded(kind) for kind in KINDS)

    def missing(self) -> list[str]:
        return [kind for kind in KINDS if not self.loaded(kind)]

    def file(self, kind: str) -> dat.DatFile:
        handle = self.files.get(kind)
        if handle is None:
            raise RuntimeError(f"Файл {kind}.dat не загружен")
        return handle

    @contextlib.contextmanager
    def use(self, kind: str):
        """Держит файл открытым на время работы с ним.

        Без этого замка фоновая перекачка может закрыть mmap прямо под
        читающим запросом — это не исключение, а аварийное завершение процесса.
        """
        with self.lock:
            yield self.file(kind)

    # --- открытие ---------------------------------------------------------

    def load(
        self, kind: str, on_progress: Callable[[int], None] | None = None
    ) -> bool:
        path = cache_path(kind)
        if not path.exists() or path.stat().st_size == 0:
            return False

        handle = dat.DatFile(path, kind)
        handle.open(on_progress)

        with self.lock:
            previous = self.files.get(kind)
            self.files[kind] = handle
        if previous is not None:
            previous.close()

        log.info(
            "%s: %d категорий, %d записей, %.1f МБ",
            kind, len(handle.by_code), handle.total_entries, handle.size / 1048576,
        )
        return True

    def unload(self, kind: str) -> None:
        with self.lock:
            handle = self.files.get(kind)
            self.files[kind] = None
        if handle is not None:
            handle.close()

    def close_all(self) -> None:
        for kind in KINDS:
            self.unload(kind)

    # --- выдача в интерфейс ----------------------------------------------

    def order(self, kind: str) -> list[str]:
        """Категории по алфавиту — так их проще искать глазами.

        Порядок сборки от этого не зависит: выходной файл пишется в порядке
        исходного, чтобы результат оставался побайтово предсказуемым.
        """
        with self.use(kind) as handle:
            return sorted(handle.by_code.keys())

    def all_codes(self, kind: str) -> list[str]:
        with self.use(kind) as handle:
            return sorted(handle.by_code.keys())

    def custom_stats(self, kind: str, item: dict[str, Any]) -> dict[str, int]:
        """Сколько записей и байт даст своя категория."""
        records, _errors = custom_mod.parse_entries(kind, item.get("entries") or "")
        _disabled, excluded = self._selection(store.selection(kind))
        with self.use(kind) as handle:
            size, count = handle.compose_size(
                item.get("code") or "-", list(item.get("sources") or []), records, excluded
            )
        return {"entries": count, "bytes": size, "manual": len(records)}

    def has_category(self, kind: str, code: str) -> bool:
        with self.use(kind) as handle:
            return code in handle.by_code

    def categories(self, kind: str, query: str = "") -> list[str]:
        with self.use(kind) as handle:
            return sorted(handle.search(query.strip()))

    def count(self, kind: str, code: str) -> int:
        with self.use(kind) as handle:
            return handle.count(code)

    def totals(self, kind: str) -> dict[str, int]:
        with self.use(kind) as handle:
            return {
                "categories": len(handle.by_code),
                "entries": handle.total_entries,
                "sourceBytes": handle.size,
            }

    def overlap(self, kind: str, code: str, limit: int = 60) -> dict[str, Any]:
        with self.use(kind) as handle:
            return handle.overlap(code, limit)

    def locate(self, kind: str, key: str) -> list[str]:
        with self.use(kind) as handle:
            return handle.locate(key)

    def entries(
        self, kind: str, code: str, query: str = "", offset: int = 0, limit: int = 200
    ) -> tuple[list[dict[str, Any]], int]:
        with self.use(kind) as handle:
            return handle.entries(code, query, offset, limit)

    # --- фильтрация -------------------------------------------------------

    @staticmethod
    def _selection(selection: dict[str, Any]) -> tuple[set[str], dict[str, set[str]]]:
        disabled = set(selection.get("disabled_categories") or [])
        excluded = {
            code: set(keys)
            for code, keys in (selection.get("excluded") or {}).items()
            if keys
        }
        return disabled, excluded

    def custom_items(self, kind: str) -> list[dict[str, Any]]:
        """Свои категории в готовом для сборки виде."""
        items: list[dict[str, Any]] = []
        for raw in store.custom(kind):
            if not raw.get("enabled", True):
                continue
            records, errors = custom_mod.parse_entries(kind, raw.get("entries") or "")
            if errors:
                log.warning("%s / %s: %s", kind, raw.get("code"), "; ".join(errors))
            items.append(
                {
                    "code": raw["code"],
                    "sources": list(raw.get("sources") or []),
                    "records": records,
                    "keep_sources": bool(raw.get("keep_sources")),
                }
            )
        return items

    def _with_custom(
        self, kind: str, selection: dict[str, Any]
    ) -> tuple[set[str], dict[str, set[str]], list[dict[str, Any]]]:
        disabled, excluded = self._selection(selection)
        items = self.custom_items(kind)
        for item in items:
            if not item["keep_sources"]:
                # Исходные растворяются в новой: их записи уже перенесены,
                # отдельно публиковать их — значит дублировать данные.
                disabled |= set(item["sources"])
        return disabled, excluded, items

    def estimate(self, kind: str, selection: dict[str, Any]) -> dict[str, int]:
        disabled, excluded, items = self._with_custom(kind, selection)
        with self.use(kind) as handle:
            return handle.plan(disabled, excluded, items)

    def build(
        self,
        kind: str,
        selection: dict[str, Any],
        on_progress: Callable[[int], None] | None = None,
    ) -> dict[str, Any]:
        disabled, excluded, items = self._with_custom(kind, selection)
        with self.use(kind) as handle:
            info = handle.build(
                build_path(kind), disabled, excluded, on_progress, items
            )
        dat.verify(build_path(kind))  # быстрая проверка структуры
        return info


geo = GeoStore()


# --------------------------------------------------------------------------
# Загрузка исходников
# --------------------------------------------------------------------------

def make_client() -> httpx.AsyncClient:
    return httpx.AsyncClient(headers={"User-Agent": USER_AGENT})


async def probe_source(url: str, client: httpx.AsyncClient) -> dict[str, Any]:
    """Проверка доступности адреса: HEAD, а если не поддержан — короткий GET."""
    response = await client.head(url, follow_redirects=True, timeout=30)
    if response.status_code in (403, 405, 501):
        response = await client.get(
            url, follow_redirects=True, timeout=30, headers={"Range": "bytes=0-0"}
        )
    response.raise_for_status()
    return {
        "etag": response.headers.get("etag"),
        "last_modified": response.headers.get("last-modified"),
        "size": int(response.headers.get("content-length") or 0),
    }


async def check_source(kind: str, client: httpx.AsyncClient) -> dict[str, Any]:
    return await probe_source(store.source_url(kind), client)


def source_changed(kind: str, meta: dict[str, Any]) -> bool:
    """True, только если есть достоверный признак изменения файла."""
    known = store.state["sources"].get(kind) or {}
    if not cache_path(kind).exists():
        return True
    if not known.get("sha256"):
        return True
    if known.get("url") and known["url"] != store.source_url(kind):
        return True

    etag, known_etag = meta.get("etag"), known.get("etag")
    if etag and known_etag:
        return etag != known_etag

    modified, known_modified = meta.get("last_modified"), known.get("last_modified")
    if modified and known_modified:
        return modified != known_modified

    size, known_size = meta.get("size"), known.get("size")
    if size and known_size:
        return size != known_size

    return False


async def download_source(
    kind: str,
    client: httpx.AsyncClient,
    on_progress: Callable[[int, int, int], None] | None = None,
) -> dict[str, Any]:
    """Качает файл потоком на диск. on_progress(получено, всего, процент)."""
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    target = cache_path(kind)
    tmp = target.with_suffix(".part")
    digest = hashlib.sha256()
    size = 0
    url = store.source_url(kind)
    reported = -1

    async with client.stream("GET", url, follow_redirects=True, timeout=300) as response:
        response.raise_for_status()
        expected = int(response.headers.get("content-length") or 0)
        with open(tmp, "wb") as fh:
            async for chunk in response.aiter_bytes(1 << 18):
                fh.write(chunk)
                digest.update(chunk)
                size += len(chunk)
                if on_progress and expected:
                    percent = int(size * 100 / expected)
                    if percent >= reported + 10:
                        reported = percent
                        on_progress(size, expected, percent)
        headers = response.headers

    # mmap держит старый файл открытым — закрываем перед заменой.
    geo.unload(kind)
    target.with_suffix(".idx.json").unlink(missing_ok=True)
    shutil.move(str(tmp), str(target))

    return {
        "url": url,
        "etag": headers.get("etag"),
        "last_modified": headers.get("last-modified"),
        "size": size,
        "sha256": digest.hexdigest(),
    }


# --------------------------------------------------------------------------
# Новые категории
# --------------------------------------------------------------------------

def sync_new_categories(kind: str) -> list[str]:
    """Категории, которых раньше не было, выключаем и помечаем как новые."""
    if not geo.loaded(kind):
        return []
    current = set(geo.order(kind))
    if not current:
        return []
    known = set(store.state["known_categories"].get(kind) or [])

    if not known:
        store.state["known_categories"][kind] = sorted(current)
        store.state["new_categories"][kind] = []
        store.save_state()
        return []

    fresh = sorted(current - known)
    selection = store.selection(kind)
    if fresh:
        selection["disabled_categories"] = sorted(
            set(selection["disabled_categories"]) | set(fresh)
        )

    marked = set(store.state["new_categories"].get(kind) or []) | set(fresh)
    store.state["new_categories"][kind] = sorted(marked & current)
    store.state["known_categories"][kind] = sorted(current)

    selection["disabled_categories"] = sorted(
        set(selection["disabled_categories"]) & current
    )
    selection["excluded"] = {
        code: keys for code, keys in selection["excluded"].items() if code in current
    }
    store.save_config()
    store.save_state()
    return fresh


def clear_new_marks(kind: str, codes: Iterable[str]) -> None:
    marked = set(store.state["new_categories"].get(kind) or [])
    marked -= set(codes)
    store.state["new_categories"][kind] = sorted(marked)
    store.save_state()
