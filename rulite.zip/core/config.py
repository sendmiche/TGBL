"""Хранение настроек и состояния приложения в JSON-файлах."""

from __future__ import annotations

import json
import os
import secrets
import shutil
import threading
import uuid
from pathlib import Path
from typing import Any

BASE_DIR = Path(__file__).resolve().parent.parent

# Данные намеренно вынесены из каталога с кодом: при обновлении проект можно
# перезаписать целиком, не потеряв учётные данные, токены и выбор категорий.
LEGACY_DATA_DIR = BASE_DIR / "data"
DATA_DIR = Path(os.getenv("RULITE_DATA") or LEGACY_DATA_DIR).resolve()
CACHE_DIR = DATA_DIR / "cache"
BUILD_DIR = DATA_DIR / "build"
PROTO_DIR = BASE_DIR / "proto"
WEB_DIR = BASE_DIR / "web"

CONFIG_PATH = DATA_DIR / "config.json"
STATE_PATH = DATA_DIR / "state.json"
# Учётная запись хранится отдельно от настроек: сбросить пароль можно,
# удалив только этот файл, не потеряв ничего остального.
ADMIN_PATH = DATA_DIR / "admin.json"

# geoip идёт первым: он в разы меньше и загружается быстрее, так что панель
# оживает раньше, чем закончится разбор тяжёлого geosite.
KINDS = ("geoip", "geosite")

DEFAULT_SOURCES = {
    "geoip": "https://raw.githubusercontent.com/runetfreedom/russia-v2ray-rules-dat/release/geoip.dat",
    "geosite": "https://raw.githubusercontent.com/runetfreedom/russia-v2ray-rules-dat/release/geosite.dat",
}

PROVIDERS = ("github", "gitverse")

# Какие события можно слать в Telegram.
NOTIFY_EVENTS: dict[str, str] = {
    "release": "Релиз выложен",
    "sources_updated": "Структура исходных файлов обновлена",
    "new_categories": "Появились новые категории",
    "build_done": "Ручная сборка завершена",
    "errors": "Ошибка сборки или публикации",
    "no_updates": "Плановая проверка: обновлений нет",
    "startup": "Панель запущена или перезапущена",
}

DEFAULT_NOTIFY = {
    "release": True,
    "sources_updated": True,
    "new_categories": True,
    "build_done": False,
    "errors": True,
    "no_updates": False,
    "startup": False,
}


def _migrate_data_dir() -> None:
    """Переносит настройки из старого расположения внутри проекта."""
    if DATA_DIR == LEGACY_DATA_DIR.resolve():
        return
    if (DATA_DIR / "config.json").exists():
        return
    if not (LEGACY_DATA_DIR / "config.json").exists():
        return
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    for name in ("config.json", "state.json"):
        source = LEGACY_DATA_DIR / name
        if source.exists():
            shutil.copy2(source, DATA_DIR / name)


HOST_PROVIDERS = {
    "github.com": "github",
    "www.github.com": "github",
    "gitverse.ru": "gitverse",
    "www.gitverse.ru": "gitverse",
}


def parse_repo(value: str) -> tuple[str | None, str]:
    """Приводит любую форму записи репозитория к виду user/repo.

    Понимает полную ссылку, адрес без схемы, ssh-строку и просто user/repo.
    Возвращает также угаданный сервис, если его видно из адреса.
    """
    text = (value or "").strip()
    if not text:
        return None, ""

    provider: str | None = None

    if text.startswith("git@"):
        text = text[4:].replace(":", "/", 1)

    for scheme in ("https://", "http://", "ssh://", "git://"):
        if text.startswith(scheme):
            text = text[len(scheme) :]
            break

    text = text.split("?", 1)[0].split("#", 1)[0].strip("/")

    parts = [part for part in text.split("/") if part]
    if parts and "." in parts[0] and parts[0].lower() in HOST_PROVIDERS:
        provider = HOST_PROVIDERS[parts[0].lower()]
        parts = parts[1:]
    elif parts and "." in parts[0] and len(parts) > 2:
        parts = parts[1:]  # незнакомый хост — просто отбрасываем

    if len(parts) >= 2:
        owner, repo = parts[0], parts[1]
        if repo.endswith(".git"):
            repo = repo[:-4]
        return provider, f"{owner}/{repo}"

    return provider, "/".join(parts)


def mask_secret(secret: str) -> str:
    """Показываем только хвост — начало токена тоже часть секрета."""
    if not secret:
        return ""
    return f"••••{secret[-4:]}" if len(secret) > 8 else "••••"


def new_target(provider: str = "github") -> dict[str, Any]:
    return {
        "id": uuid.uuid4().hex[:8],
        "provider": provider,
        "repo": "",
        "token": "",
        "enabled": True,
    }


def default_admin() -> dict[str, Any]:
    return {"version": 1, "secret_key": secrets.token_hex(32), "admin": None}


def default_config() -> dict[str, Any]:
    return {
        "version": 3,
        "sources": dict(DEFAULT_SOURCES),
        "publish": {"auto": True, "timezone": "Europe/Moscow"},
        "telegram": {
            "enabled": False,
            "token": "",
            "chat_id": "",
            "events": dict(DEFAULT_NOTIFY),
        },
        "targets": [],
        "release_notes": [],
        "readme": {"enabled": True, "text": ""},
        "custom": {kind: [] for kind in KINDS},
        "schedule": {"interval_minutes": 60},
        "selection": {
            kind: {"disabled_categories": [], "excluded": {}} for kind in KINDS
        },
    }


def default_state() -> dict[str, Any]:
    return {
        "sources": {kind: {} for kind in KINDS},
        "known_categories": {kind: [] for kind in KINDS},
        "new_categories": {kind: [] for kind in KINDS},
        "last_build": None,
        "releases": [],
        "runs": [],
    }


def _atomic_write(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(json.dumps(payload, ensure_ascii=False, indent=2))
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, path)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass  # Windows и некоторые ФС не поддерживают chmod


def _merge_defaults(loaded: dict[str, Any], defaults: dict[str, Any]) -> dict[str, Any]:
    result = dict(defaults)
    for key, value in loaded.items():
        if key in defaults and isinstance(defaults[key], dict) and isinstance(value, dict):
            result[key] = _merge_defaults(value, defaults[key])
        else:
            result[key] = value
    return result


def _migrate(config: dict[str, Any]) -> dict[str, Any]:
    """Переносит настройки из формата версии 1 (один репозиторий GitHub)."""
    legacy = config.pop("github", None)
    if isinstance(legacy, dict):
        config.setdefault("publish", {})
        config["publish"]["auto"] = legacy.get("auto_publish", True)
        config["publish"]["timezone"] = legacy.get("timezone", "Europe/Moscow")
        if legacy.get("repo") or legacy.get("token"):
            target = new_target("github")
            target["repo"] = legacy.get("repo", "")
            target["token"] = legacy.get("token", "")
            config.setdefault("targets", []).append(target)
    for target in config.get("targets", []):
        target.setdefault("id", uuid.uuid4().hex[:8])
        target.setdefault("provider", "github")
        target.setdefault("enabled", True)
    # Длинное описание раньше публиковалось как текст релиза — теперь это
    # README в корне репозитория, а релиз получает короткую заметку.
    readme = config.setdefault("readme", {"enabled": True, "text": ""})
    if not readme.get("text"):
        for note in config.get("release_notes") or []:
            if "{{categories_table}}" in (note.get("text") or ""):
                readme["text"] = note["text"]
                break
    if readme.get("text"):
        config["release_notes"] = [
            note for note in (config.get("release_notes") or [])
            if "{{categories_table}}" not in (note.get("text") or "")
        ]

    config.pop("version", None)
    config["version"] = 4
    return config


class Store:
    """Потокобезопасный доступ к config.json и state.json."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        _migrate_data_dir()
        for directory in (DATA_DIR, CACHE_DIR, BUILD_DIR):
            directory.mkdir(parents=True, exist_ok=True)
        self.config = _migrate(self._load(CONFIG_PATH, default_config()))
        self.admin_data = self._load(ADMIN_PATH, default_admin())
        self.state = self._load(STATE_PATH, default_state())
        self._split_admin()
        self.save_config()
        self.save_admin()
        if not STATE_PATH.exists():
            self.save_state()

    def _split_admin(self) -> None:
        """Переносит учётную запись из config.json в admin.json."""
        legacy_admin = self.config.pop("admin", None)
        legacy_secret = self.config.pop("secret_key", None)
        if legacy_admin and not self.admin_data.get("admin"):
            self.admin_data["admin"] = legacy_admin
        if legacy_secret and not ADMIN_PATH.exists():
            self.admin_data["secret_key"] = legacy_secret

    @staticmethod
    def _load(path: Path, defaults: dict[str, Any]) -> dict[str, Any]:
        if not path.exists():
            return defaults
        try:
            with open(path, encoding="utf-8") as fh:
                loaded = json.load(fh)
        except (OSError, json.JSONDecodeError):
            try:
                os.replace(path, path.with_suffix(path.suffix + ".broken"))
            except OSError:
                pass
            return defaults
        if not isinstance(loaded, dict):
            return defaults
        return _merge_defaults(loaded, defaults)

    def save_config(self) -> None:
        with self._lock:
            _atomic_write(CONFIG_PATH, self.config)

    def save_admin(self) -> None:
        with self._lock:
            _atomic_write(ADMIN_PATH, self.admin_data)

    def save_state(self) -> None:
        with self._lock:
            _atomic_write(STATE_PATH, self.state)

    # --- удобные геттеры -------------------------------------------------

    @property
    def has_admin(self) -> bool:
        return bool(self.admin_data.get("admin"))

    @property
    def admin(self) -> dict[str, Any] | None:
        return self.admin_data.get("admin")

    @property
    def secret_key(self) -> str:
        key = self.admin_data.get("secret_key")
        if not key:
            key = secrets.token_hex(32)
            self.admin_data["secret_key"] = key
            self.save_admin()
        return key

    def custom(self, kind: str) -> list[dict[str, Any]]:
        block = self.config.setdefault("custom", {})
        return block.setdefault(kind, [])

    def readme(self) -> dict[str, Any]:
        block = self.config.setdefault("readme", {})
        block.setdefault("enabled", True)
        block.setdefault("text", "")
        return block

    def release_notes(self) -> list[dict[str, Any]]:
        return self.config.setdefault("release_notes", [])

    def source_url(self, kind: str) -> str:
        return (self.config.get("sources") or {}).get(kind) or DEFAULT_SOURCES[kind]

    def selection(self, kind: str) -> dict[str, Any]:
        sel = self.config["selection"].setdefault(
            kind, {"disabled_categories": [], "excluded": {}}
        )
        sel.setdefault("disabled_categories", [])
        sel.setdefault("excluded", {})
        return sel

    def telegram(self) -> dict[str, Any]:
        block = self.config.setdefault("telegram", {})
        block.setdefault("enabled", False)
        block.setdefault("token", "")
        block.setdefault("chat_id", "")
        events = block.setdefault("events", {})
        for key, value in DEFAULT_NOTIFY.items():
            events.setdefault(key, value)
        return block

    def targets(self, only_ready: bool = False) -> list[dict[str, Any]]:
        targets = self.config.setdefault("targets", [])
        if not only_ready:
            return targets
        return [
            t for t in targets
            if t.get("enabled") and t.get("token") and t.get("repo")
        ]

    def record_run(self, entry: dict[str, Any]) -> None:
        with self._lock:
            runs = self.state.setdefault("runs", [])
            runs.insert(0, entry)
            del runs[20:]
            self.save_state()


store = Store()
