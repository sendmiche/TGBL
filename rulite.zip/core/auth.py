"""Регистрация администратора, вход и cookie-сессии."""

from __future__ import annotations

import hashlib
import hmac
import secrets
import time
from typing import Any

from fastapi import Request
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer

from .config import store

COOKIE_NAME = "rulite_session"
SESSION_MAX_AGE = 60 * 60 * 24 * 14  # 14 дней

SCRYPT_N = 2**14
SCRYPT_R = 8
SCRYPT_P = 1

MAX_ATTEMPTS = 5
LOCKOUT_SECONDS = 300

_failed: dict[str, list[float]] = {}


def _serializer() -> URLSafeTimedSerializer:
    return URLSafeTimedSerializer(store.secret_key, salt="rulite-session")


def hash_password(password: str) -> dict[str, str]:
    salt = secrets.token_bytes(16)
    digest = hashlib.scrypt(
        password.encode("utf-8"), salt=salt, n=SCRYPT_N, r=SCRYPT_R, p=SCRYPT_P, dklen=32
    )
    return {"salt": salt.hex(), "hash": digest.hex()}


def verify_password(password: str, record: dict[str, Any]) -> bool:
    try:
        salt = bytes.fromhex(record["salt"])
        expected = bytes.fromhex(record["hash"])
    except (KeyError, ValueError):
        return False
    digest = hashlib.scrypt(
        password.encode("utf-8"), salt=salt, n=SCRYPT_N, r=SCRYPT_R, p=SCRYPT_P, dklen=32
    )
    return hmac.compare_digest(digest, expected)


def register_admin(username: str, password: str) -> None:
    record = hash_password(password)
    record["username"] = username
    store.admin_data["admin"] = record
    store.save_admin()


def change_password(old_password: str, new_password: str) -> bool:
    """Смена пароля. Секрет сессий обновляется — старые входы аннулируются."""
    admin = store.admin
    if not admin or not verify_password(old_password, admin):
        return False
    record = hash_password(new_password)
    record["username"] = admin["username"]
    store.admin_data["admin"] = record
    store.admin_data["secret_key"] = secrets.token_hex(32)
    store.save_admin()
    return True


def check_credentials(username: str, password: str) -> bool:
    admin = store.admin
    if not admin:
        return False
    stored = admin.get("username", "").encode("utf-8")
    if not hmac.compare_digest(stored, username.encode("utf-8")):
        # Всё равно считаем хэш, чтобы время ответа не выдавало наличие логина.
        verify_password(password, admin)
        return False
    return verify_password(password, admin)


def lockout_remaining(ip: str) -> int:
    now = time.time()
    attempts = [t for t in _failed.get(ip, []) if now - t < LOCKOUT_SECONDS]
    _failed[ip] = attempts
    if len(attempts) < MAX_ATTEMPTS:
        return 0
    return int(LOCKOUT_SECONDS - (now - attempts[0])) + 1


def register_failure(ip: str) -> None:
    _failed.setdefault(ip, []).append(time.time())


def clear_failures(ip: str) -> None:
    _failed.pop(ip, None)


def issue_session(username: str) -> str:
    return _serializer().dumps({"u": username})


def read_session(request: Request) -> str | None:
    token = request.cookies.get(COOKIE_NAME)
    if not token:
        return None
    try:
        payload = _serializer().loads(token, max_age=SESSION_MAX_AGE)
    except (BadSignature, SignatureExpired):
        return None
    admin = store.admin
    if not admin or payload.get("u") != admin.get("username"):
        return None
    return payload["u"]


def is_authenticated(request: Request) -> bool:
    return read_session(request) is not None
